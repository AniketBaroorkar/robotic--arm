# Fruit Sorting Robot — 6 cm Pickup / 8 cm Equal Drops v26

This is the complete Arduino App Lab project. The camera identifies the fruit and the arm starts sorting automatically; there is no pickup enable/disable button. E-STOP and Reset remain available.

## v26 tray layout

At the configured working radius of 15 cm, the calculated base directions are approximately:

```text
LEFT                                                                       RIGHT
Apple drop      Banana/Orange pickup      Apple pickup      Banana drop      Orange drop
  ~82.1°                 90.0°                ~113.1°          ~120.9°           165.0°
```

Changes:

- Apple–banana pickup spacing is reduced to **6 cm**.
- Apple and banana use the same outward drop distance: **8 cm from their own pickup points**.
- Apple drops to the left of the apple pickup.
- Banana drops to the right of the banana pickup.
- The banana is still picked horizontally, but channel 4 rotates it upright during the safe compact travel movement.
- The banana remains upright while the arm lowers and opens the gripper, so it is released vertically without another wrist flip.
- Orange keeps the proven 90° pickup direction and separate far-right drop at 165°.
- All base positions remain ordered from left to right for one long tray or box.

The base rotates in a circle, so these positions form one constant-radius **arc**, not a mathematically exact straight line. The shoulder and elbow geometry is unchanged to preserve the working pickup style. Place the long box along the tested arc.

Adjust spacing in `python/main.py`:

```python
WORKING_RADIUS_CM = 15.0
PICKUP_SPACING_CM = 6.0
APPLE_DROP_FROM_PICKUP_CM = 8.0
BANANA_DROP_FROM_PICKUP_CM = 8.0
ORANGE_DROP_BASE = 165.0
```

## Banana movement

Pickup:

```text
CH3 wrist pitch = 10°
CH4 wrist rotation = 0°
```

Safe travel and vertical drop:

```text
CH4 wrist rotation = 90°
```

The rotation from 0° to 90° happens while the arm is compact and lifted. Both `banana_above` and `banana_drop` keep channel 4 at 90°, so the wrist does not rotate while descending or releasing.

## Automatic operation

- The robot starts in automatic mode when the app launches.
- Stable fruit detection starts the cycle without pressing a web button.
- E-STOP pauses automatic sorting.
- Reset E-STOP automatically resumes sorting.

## Servo order

```text
CH0 base
CH1 shoulder
CH2 elbow
CH3 wrist pitch
CH4 wrist/claw rotation
CH5 gripper open/close
```

Test all base directions without fruit first and keep the E-STOP ready.
