# Fruit Sorting Robot — Apple Far / Banana Previous Drop v23

This is the complete Arduino App Lab project. The camera identifies the fruit and the arm starts sorting automatically; there is no pickup enable/disable button. E-STOP and Reset remain available.

## v23 tray layout

At the configured working radius of 15 cm, the calculated base directions are approximately:

```text
LEFT                                                                      RIGHT
Apple drop      Banana/Orange pickup      Apple pickup   Banana drop      Orange drop
  ~60.9°                 90.0°                ~120.9°        ~128.9°          165.0°
```

Changes:

- Apple–banana pickup spacing increased from **5 cm to 8 cm**.
- Apple drop moved to approximately **15 cm from the apple pickup**.
- Banana drop is restored to its previous distance: approximately **10 cm from the banana pickup**.
- Orange uses the proven 90° pickup direction and has a separate far-right drop at 165°.
- All base positions are ordered from left to right for one long tray or box.

The base rotates in a circle, so these positions form one constant-radius **arc**, not a mathematically exact straight line. The shoulder and elbow geometry is intentionally unchanged to preserve the working pickup style. A long box should be placed along this arc. Exact straight-line correction would require measuring the arm link lengths and separately calibrating shoulder/elbow reach for every location.

Adjust spacing in `python/main.py`:

```python
WORKING_RADIUS_CM = 15.0
PICKUP_SPACING_CM = 8.0
APPLE_DROP_FROM_PICKUP_CM = 15.0
BANANA_DROP_FROM_PICKUP_CM = 10.0
ORANGE_DROP_BASE = 165.0
```

## Automatic operation

- The robot starts in automatic mode when the app launches.
- Stable fruit detection starts the cycle without pressing a web button.
- E-STOP pauses automatic sorting.
- Reset E-STOP automatically resumes sorting.

## Banana pickup retained

- Channel 4 rotates the claw to `0°`.
- Channel 3 bends fully downward to `10°` before extending.
- The approach, grip, lift, and raised drop pose remain unchanged.

## Servo order

```text
CH0 base
CH1 shoulder
CH2 elbow
CH3 wrist pitch
CH4 wrist/claw rotation
CH5 gripper open/close
```

Apple remains at the current 15 cm drop distance; only the banana drop was restored to 10 cm. Test the base directions without fruit first and keep the E-STOP ready.
