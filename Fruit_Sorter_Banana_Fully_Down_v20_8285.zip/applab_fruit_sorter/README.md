# Fruit Sorting Robot — Horizontal Banana + Safer Drop v18

The camera identifies the fruit only. Pickup and drop locations remain fixed servo poses.

## Changes in v18

- Banana pickup location remains unchanged at base `90°`.
- When banana is detected, channel 4 rotates the complete claw/wrist to `0°` while the arm is still safely above the table.
- The banana remains at `0°` during descent, gripping, lifting, travel and release, preventing the horizontal fruit from twisting.
- Channel 5 is still used only to open and close the gripper; it is not commanded to `0°`.
- The banana drop pose is raised to prevent the gripper or fruit from banging against the table.
- Apple and orange pickup/drop behaviour remains unchanged.

## Banana wrist rotation

Edit `python/main.py` and find:

```python
BANANA_WRIST_ROTATE = 0.0
```

This controls channel 4. If the claw turns in the wrong direction on the physical arm, try a safe intermediate value such as `180.0` only after testing with the arm raised and no fruit.

## Raised banana drop pose

The banana release pose is now:

```python
"banana_drop": (BANANA_DROP_BASE, 50.0, 134.0, 36.0, 0.0)
```

Servo order is:

```text
(base, shoulder, elbow, wrist_pitch, wrist_rotate)
```

The previous elbow angle was `140°`. Reducing it to `134°` raises the drop position. To raise it further, reduce it in small steps:

```python
132.0  # slightly higher
130.0  # higher again
```

Do not make large changes at once. Test without fruit first and keep the E-STOP ready.

## Current sideways locations

- Banana pickup: base `90°`
- Apple pickup: base `105°`
- Apple drop: base `75°`
- Banana drop: base `120°`

The nearby drop offset remains:

```python
SIDE_DROP_OFFSET_DEG = 30.0
```

## v19 banana pickup correction

For a horizontal banana, channel 4 remains at `0°`. Channel 3 now pitches the claw `10°` farther downward during banana pickup so the open claw does not hit and push the banana backward.

Adjust this in `python/main.py`:

```python
BANANA_PICKUP_WRIST_PITCH_OFFSET_DEG = -10.0
```

Use `-12.0` or `-14.0` for slightly farther down. Use `-8.0` or `-6.0` if it goes too low. If your channel 3 direction is physically reversed, use a positive value.


## v20 banana full-down wrist preparation

For banana pickup, channel 3 now moves to `10°` (its configured safe minimum) while the arm is still compact and away from the fruit. Channel 4 simultaneously rotates to `0°`. Only after this preparation does the arm extend toward the banana. This prevents the front of the claw from hitting and pushing the banana backward.

Adjust only if required:

```python
BANANA_PICKUP_WRIST_PITCH_DEG = 10.0
```

Do not set it below `10°` unless the channel 3 mechanical range and servo limits are changed safely.
