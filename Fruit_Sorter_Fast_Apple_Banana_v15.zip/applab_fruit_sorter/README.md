# Fruit Sorting Robot — Fixed Pickup v14

This version uses **one marked pickup position only**. The camera identifies the fruit; it does not calculate arm coordinates.

## Motion sequence

1. Detect a stable apple, banana, or orange.
2. Move through a compact travel pose.
3. Extend to the fixed pickup mark.
4. Descend slowly through five small waypoints.
5. Lock servos 0–4 and close only servo 5 (gripper).
6. Lift by reversing the exact descent path.
7. Rotate only after the fruit is safely raised.
8. Move to the fruit's fixed box, lower, lock the arm, and release.
9. Return home and wait until the camera view is clear.

This removes the earlier backward movement before gripping and forward movement after gripping.

## Important calibration

Edit only the `POSES` values near the top of `python/main.py`:

- `pickup_ready`: points toward the pickup mark while high.
- `pickup_above`: claw centered above the fruit.
- `pickup_grip`: lowest pickup pose. Tune this carefully.
- `pickup_lift`: secure raised pose before base rotation.
- `apple_*`, `banana_*`, `orange_*`: fixed box poses.

Keep the pickup mark approximately 15 cm or more from the arm base. Exact reach depends on the physical link lengths, servo horn mounting, and fruit size, so final angle calibration must be done on the real arm.

## Servo channels

- CH0: Base
- CH1: Shoulder
- CH2: Elbow
- CH3: Wrist pitch
- CH4: Wrist rotate
- CH5: Gripper

All six servos are used. Wrist rotation stays neutral for banana to avoid twisting a long fruit; apple and orange use a small presentation rotation during placement.

## First test

1. Keep servo power OFF and confirm wiring.
2. Power the arm with no fruit and open the dashboard.
3. Enable the arm.
4. Run **Test Cycle** and keep a hand near the E-STOP.
5. Adjust `pickup_grip` in 2–3 degree steps until the gripper reaches the fruit without pressing hard into the table.
6. Test with a light fruit before using heavier objects.

## v15 fruit-specific fast pickup
- Banana pickup base: `BANANA_PICKUP_BASE = 90.0`.
- Apple pickup base: banana base + `APPLE_PICKUP_OFFSET_DEG = 15.0`.
- Orange currently uses the banana pickup base.
- The old `WAITING_FOR_CLEAR` gate was removed.
- Detection now confirms using 4 of the last 5 frames and uses a 1-second cycle cooldown.
- Motion pauses and descent waypoints were shortened for faster operation.
- If “right” is reversed on your physical arm, set `APPLE_PICKUP_OFFSET_DEG = -15.0`.
