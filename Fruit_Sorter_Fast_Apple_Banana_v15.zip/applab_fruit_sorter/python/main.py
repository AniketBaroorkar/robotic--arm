"""
main.py — Fruit Sorting Robot v13 (Arduino App Lab) — FIXED STATION
====================================================================
DESIGN CHANGE: the camera NO LONGER controls the arm's position.
There is one physically MARKED pickup spot. The user places one fruit
on it; the camera only answers "WHICH fruit is it?" (anywhere in view);
the arm always runs the SAME calibrated pose sequence:

  HOME -> detect (stable, anywhere in view) -> lock class -> transition ->
  above pickup -> lower -> grip -> lift -> transition -> fruit's box ->
  lower -> release -> lift -> transition -> HOME -> wait until the
  pickup spot is EMPTY -> ready for the next fruit.

No pixels-to-angles math exists anywhere in this file.

CALIBRATION = edit the POSES block below (one pickup set + three drop
sets). That's the whole calibration now — no coordinates anywhere.
"""

import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v15-fruit-specific-fast"

# ======================================================================
# CONFIGURATION — everything adjustable lives here
# Servo order everywhere: [base(0), shoulder(1), elbow(2),
#                          wrist_pitch(3), wrist_rotate(4)]
# (gripper ch5 is commanded separately, never inside a pose)
# ======================================================================
GRIPPER_CH = 5
GRIPPER_OPEN = 90.0
GRIPPER_CLOSED = 172.0   # 172 avoids the post-close torque lurch;
                          # raise toward 180 if the grip is weak

# --- FIXED POSES (calibrate these on YOUR arm) ------------------------
# On this arm: shoulder/elbow forward-down = angles per your notebook;
# elbow "down" = toward 180. All values clamped by SERVO_LIMITS below.
# Banana uses the currently calibrated pickup direction.
# Apple pickup is 15 degrees to the RIGHT of banana. If your arm's base
# direction is physically reversed, change APPLE_PICKUP_OFFSET_DEG to -15.0.
BANANA_PICKUP_BASE = 90.0
APPLE_PICKUP_OFFSET_DEG = 15.0
APPLE_PICKUP_BASE = BANANA_PICKUP_BASE + APPLE_PICKUP_OFFSET_DEG
ORANGE_PICKUP_BASE = BANANA_PICKUP_BASE

POSES = {
    # name:            (base,        shoulder, elbow, wrist_p, wrist_r)
    "home":            (90.0,        90.0,     90.0,  90.0,    90.0),
    "transition":      (None,        72.0,     102.0, 58.0,    90.0),  # compact safe travel pose
    "pickup_ready":    (BANANA_PICKUP_BASE, 62.0,     112.0, 48.0,    90.0),  # points toward fixed mark
    "pickup_above":    (BANANA_PICKUP_BASE, 48.0,     122.0, 36.0,    90.0),  # claw directly above fruit
    "pickup_grip":     (BANANA_PICKUP_BASE, 54.0,     146.0, 29.0,    90.0),  # final low pose; tune only this
    "pickup_lift":     (BANANA_PICKUP_BASE, 58.0,     112.0, 48.0,    90.0),  # secure lift before base rotation
    "apple_above":     (30.0,        60.0,     105.0, 45.0,    90.0),
    "apple_drop":      (30.0,        68.0,     140.0, 45.0,    90.0),
    "banana_above":    (60.0,        60.0,     105.0, 45.0,    90.0),
    "banana_drop":     (60.0,        68.0,     145.0, 45.0,    90.0),  # bananas release a bit lower
    "orange_above":    (150.0,       60.0,     105.0, 45.0,    90.0),
    "orange_drop":     (150.0,       68.0,     140.0, 45.0,    90.0),
}
LOWER_STEPS = 3           # more, smaller waypoints for a controlled descent

# Pickup is deliberately split into stages. This prevents the claw from
# swinging backward before closing and then forward after closing.
# The arm first reaches a fixed pre-pick pose, settles, descends using only
# the joints needed for height, locks all arm channels, closes the gripper,
# and lifts by reversing the exact same waypoints.
PICK_SETTLE_S = 0.25
POST_GRIP_HOLD_S = 0.35
USE_WRIST_PRESENTATION = True

SERVO_LIMITS = {          # clamped before EVERY command; warning logged
    0: (10.0, 170.0),     # base
    1: (20.0, 160.0),     # shoulder
    2: (60.0, 150.0),     # elbow (the ch2 window that proved safe)
    3: (10.0, 170.0),     # wrist pitch
    4: (0.0, 180.0),      # wrist rotate
    5: (80.0, 180.0),     # gripper
}

# --- SPEEDS (deg per 20 ms MCU tick; MCU adds ease-in/out ramps) ------
TRAVEL_STEP_DEG = 1.8     # rotations, home, box travel
PRECISE_STEP_DEG = 0.70   # lowering, gripping, releasing
APPROACH_PAUSE_S = 0.25
GRIP_SETTLE_S = 0.30

# --- DETECTION (identification ONLY — never position) -----------------
CONFIDENCE_MIN = 0.35         # brick threshold (what shows on the page)
DETECT_CONFIDENCE = 0.40      # required to accept the fruit
STABLE_WINDOW = 5            # look at the last N frames...
STABLE_REQUIRED = 4           # ...same fruit in at least this many
COOLDOWN_S = 1.0

# Toy-fruit compatibility (COCO model). Set False once a custom
# apple/banana/orange model is trained.
TOY_FRUIT_COMPAT = True
_BASE_MAP = {"apple": "apple", "banana": "banana", "orange": "orange"}
_COMPAT_MAP = {"sports ball": "apple", "frisbee": "apple",
               "mouse": "banana", "bird": "banana"}
LABEL_MAP = dict(_BASE_MAP, **(_COMPAT_MAP if TOY_FRUIT_COMPAT else {}))
FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}

MOVE_TIMEOUT_S = 25.0
POLL_S = 0.1

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_state = "INITIALIZING"
_counts = {"apple": 0, "banana": 0, "orange": 0}
_frame_history = deque(maxlen=STABLE_WINDOW)  # mapped class in view or None
_waiting_for_clear = False  # retained only for API compatibility; no clear-view gate
_last_cycle_done = 0.0
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_log_lines = deque(maxlen=40)
_ui_items = []
_ui_items_ts = 0.0
_cur_base = 90.0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


def set_state(s: str) -> None:
    global _state
    _state = s


# ======================================================================
# MOTION (Bridge RPC to sketch.ino — the ONLY hardware path)
# ======================================================================
def clamp(ch: int, angle: float) -> float:
    lo, hi = SERVO_LIMITS[ch]
    c = min(max(angle, lo), hi)
    if c != angle:
        log(f"[CLAMP] ch{ch} {angle:.0f} -> {c:.0f} (limits {lo:.0f}-{hi:.0f})")
    return c


def wait_motion(timeout: float = MOVE_TIMEOUT_S) -> None:
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > timeout:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def move_pose(pose, grip: float) -> None:
    """pose = (base, shoulder, elbow, wrist_pitch, wrist_rotate)."""
    global _cur_base
    b, sh, el, wp, wr = pose
    vals = [clamp(0, b), clamp(1, sh), clamp(2, el), clamp(3, wp),
            clamp(4, wr), clamp(5, grip)]
    if not Bridge.call("move_all", *[float(v) for v in vals]):
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    wait_motion()
    _cur_base = float(vals[0])


def gripper_only(angle: float) -> None:
    """ONLY the gripper channel — no arm joint receives any command."""
    if not Bridge.call("move_servo", GRIPPER_CH, float(clamp(5, angle))):
        raise RuntimeError("MCU rejected gripper move (E-STOP active?)")
    wait_motion()


def single_servo(ch: int, angle: float) -> None:
    if not Bridge.call("move_servo", ch, float(clamp(ch, angle))):
        raise RuntimeError(f"MCU rejected move on ch {ch}")
    wait_motion()


def set_speed(deg_per_tick: float) -> None:
    try:
        Bridge.call("set_speed", float(deg_per_tick))
    except Exception as exc:  # noqa: BLE001
        log(f"[WARN] set_speed failed: {exc}")


def go_travel(target_base: float, grip: float) -> None:
    """Movement rule: NEVER rotate while lowered. ch3 tucks first, then
    the crouch, then the base rotates in the crouch."""
    _, ts, te, tw, twr = POSES["transition"]
    single_servo(3, tw)
    move_pose((_cur_base, ts, te, tw, twr), grip)
    if abs(target_base - _cur_base) > 0.5:
        move_pose((target_base, ts, te, tw, twr), grip)


def lower_between(p_from, p_to, grip: float) -> None:
    """Straight, slow, interpolated lowering (or its reverse for lift)."""
    for i in range(1, LOWER_STEPS + 1):
        f = i / LOWER_STEPS
        step = tuple(a + f * (b - a) for a, b in zip(p_from, p_to))
        move_pose(step, grip)


def hold_arm_and_move_gripper(angle: float) -> None:
    """Freeze channels 0..4 at their present software targets and move ch5 only.

    The MCU also supports this atomically, so no shoulder/elbow/wrist target can
    change while the claw closes. This directly removes the post-close lurch.
    """
    if not Bridge.call("lock_arm_and_grip", float(clamp(5, angle))):
        raise RuntimeError("MCU rejected locked gripper move")
    wait_motion()


def present_fruit_for_drop(fruit: str, pose, grip: float) -> None:
    """Use wrist rotation gently so all six servos participate naturally."""
    if not USE_WRIST_PRESENTATION:
        move_pose(pose, grip)
        return
    b, sh, el, wp, wr = pose
    # Banana stays neutral to avoid twisting a long/vertical fruit.
    target_wr = 90.0 if fruit == "banana" else (78.0 if fruit == "apple" else 102.0)
    move_pose((b, sh, el, wp, target_wr), grip)


# ======================================================================
# FRUIT-SPECIFIC FIXED PICKUP DIRECTIONS
# ======================================================================
def pickup_base_for(fruit: str) -> float:
    if fruit == "apple":
        return APPLE_PICKUP_BASE
    if fruit == "banana":
        return BANANA_PICKUP_BASE
    return ORANGE_PICKUP_BASE


def pose_with_base(pose, base_angle: float):
    """Keep the calibrated arm shape and change only base direction."""
    _, sh, el, wp, wr = pose
    return (base_angle, sh, el, wp, wr)


# ======================================================================
# THE FIXED CYCLE (identical every time; only the box differs)
# ======================================================================
def run_cycle(fruit: str) -> None:
    global _waiting_for_clear, _last_cycle_done
    try:
        pickup_base = pickup_base_for(fruit)
        ready = pose_with_base(POSES["pickup_ready"], pickup_base)
        above = pose_with_base(POSES["pickup_above"], pickup_base)
        grip_pose = pose_with_base(POSES["pickup_grip"], pickup_base)
        lift_pose = pose_with_base(POSES["pickup_lift"], pickup_base)
        box_above = POSES[f"{fruit}_above"]
        box_drop = POSES[f"{fruit}_drop"]

        log(f"[CYCLE] {fruit} ({FRUIT_COLOR[fruit]}) — pickup base {pickup_base:.0f}°")
        set_speed(TRAVEL_STEP_DEG)
        set_state("MOVING_TO_FIXED_PICKUP")
        go_travel(pickup_base, GRIPPER_OPEN)

        # Stage 1: extend toward the mark while remaining safely above it.
        move_pose(ready, GRIPPER_OPEN)
        move_pose(above, GRIPPER_OPEN)
        time.sleep(PICK_SETTLE_S)

        # Stage 2: controlled descent. Base and wrist-rotate remain fixed.
        set_state("VERTICAL_DESCENT")
        set_speed(PRECISE_STEP_DEG)
        lower_between(above, grip_pose, GRIPPER_OPEN)
        time.sleep(APPROACH_PAUSE_S)

        # Stage 3: lock channels 0..4 and close only the gripper.
        set_state("GRIPPING_ARM_LOCKED")
        log("[STAGE] pickup pose locked; closing gripper only")
        hold_arm_and_move_gripper(GRIPPER_CLOSED)
        time.sleep(POST_GRIP_HOLD_S)

        # Stage 4: reverse the descent before any base movement.
        set_state("LIFTING_STRAIGHT_UP")
        lower_between(grip_pose, above, GRIPPER_CLOSED)
        move_pose(lift_pose, GRIPPER_CLOSED)
        set_speed(TRAVEL_STEP_DEG)

        # Stage 5: compact travel, rotate, then approach selected box.
        set_state("MOVING_TO_DROP")
        go_travel(90.0, GRIPPER_CLOSED)
        go_travel(box_above[0], GRIPPER_CLOSED)
        present_fruit_for_drop(fruit, box_above, GRIPPER_CLOSED)

        set_state("LOWERING_TO_BOX")
        set_speed(PRECISE_STEP_DEG)
        present_fruit_for_drop(fruit, box_drop, GRIPPER_CLOSED)
        log("[STAGE] drop pose locked; opening gripper only")
        hold_arm_and_move_gripper(GRIPPER_OPEN)
        time.sleep(GRIP_SETTLE_S)
        present_fruit_for_drop(fruit, box_above, GRIPPER_OPEN)
        set_speed(TRAVEL_STEP_DEG)

        set_state("RETURNING_HOME")
        go_travel(90.0, GRIPPER_OPEN)
        move_pose(POSES["home"], GRIPPER_OPEN)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] cycle failed: {exc}")
        set_state("ERROR")
        try:
            gripper_only(GRIPPER_OPEN)
            go_travel(90.0, GRIPPER_OPEN)
            move_pose(POSES["home"], GRIPPER_OPEN)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        set_speed(TRAVEL_STEP_DEG)
        _waiting_for_clear = False
        _frame_history.clear()
        set_state("READY" if _arm_enabled else "READY (arm disabled)")
        _last_cycle_done = time.monotonic()
        _busy.clear()
        log("[READY] cycle complete — clear-view waiting removed")


# ======================================================================
# DETECTION — identification only, ANY position in view counts
# ======================================================================
def on_detections(results) -> None:
    global _printed_sample, _frames, _last_frame_ts, _last_beat_ts
    global _ui_items, _ui_items_ts, _waiting_for_clear
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None       # (mapped, conf) — best fruit anywhere in view
        items = []
        for label, instances in (results or {}).items():
            raw = str(label).lower()
            mapped = LABEL_MAP.get(raw)
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                inside = mapped is not None   # ANY position counts — no xy anywhere
                items.append({
                    "fruit": mapped or raw, "raw": raw,
                    "target": inside,
                    "color": FRUIT_COLOR.get(mapped) if mapped else None,
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if inside and conf >= DETECT_CONFIDENCE and (
                        best is None or conf > best[1]):
                    best = (mapped, conf)

        _ui_items = items
        _ui_items_ts = now
        _frame_history.append(best[0] if best else None)

        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            seen = best[0] if best else "empty"
            log(f"[CAMERA OK] frames: {_frames} | fruit in view: {seen} | "
                f"state: {_state}")

        # No clear-view gate: motion may start again after the short cooldown.
        if _busy.is_set():
            return
        if time.monotonic() - _last_cycle_done < COOLDOWN_S:
            return

        # ---- fast 4-of-5 stability on the SAME class -------------------
        if len(_frame_history) < STABLE_WINDOW:
            return
        candidates = [f for f in _frame_history if f is not None]
        if not candidates:
            return
        top = max(set(candidates), key=candidates.count)
        if candidates.count(top) < STABLE_REQUIRED:
            return

        if not _arm_enabled:
            set_state("READY (arm disabled)")
            return

        # ---- lock the class, start the fixed cycle ---------------------
        _busy.set()
        _frame_history.clear()
        set_state("DETECTION_CONFIRMED")
        log(f"[LOCK] class locked: {top} — starting fixed cycle")
        threading.Thread(target=run_cycle, args=(top,), daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API (page = live dashboard)
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    if _arm_enabled and _state.startswith("READY"):
        set_state("READY")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        set_state("EMERGENCY_STOP")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        set_state("READY")
        log("[E-STOP] reset (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            set_speed(TRAVEL_STEP_DEG)
            go_travel(90.0, GRIPPER_OPEN)
            move_pose(POSES["home"], GRIPPER_OPEN)
            log("[HOME] done")
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested")
    return {"ok": True}


def api_test_cycle():
    """Run ONE full fixed cycle with 'apple' regardless of detection —
    the calibration dry-run (spec's 't' control). Arm must be enabled."""
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    if not _arm_enabled:
        return {"ok": False, "error": "enable the arm first"}
    _busy.set()
    log("[TEST] running one full fixed cycle with 'apple'")
    threading.Thread(target=run_cycle, args=("apple",), daemon=True).start()
    return {"ok": True}


def api_test_servos():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    _busy.set()

    def _run():
        names = ["0 = base", "1 = shoulder", "2 = elbow",
                 "3 = wrist pitch", "4 = wrist rotate", "5 = GRIPPER/claw"]
        try:
            log("[TEST] Servo sweep — watch which joint moves per channel.")
            for ch in range(6):
                log(f"[TEST] testing channel {names[ch]} ...")
                for target in (60.0, 120.0, 90.0):
                    single_servo(ch, target)
                time.sleep(0.4)
            log("[TEST] Sweep done. Returning to HOME.")
            move_pose(POSES["home"], GRIPPER_OPEN)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] servo test failed: {exc}")
        finally:
            _busy.clear()

    threading.Thread(target=_run, daemon=True).start()
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)
ui.expose_api("GET", "/api/test_cycle", api_test_cycle)
ui.expose_api("GET", "/api/test_servos", api_test_servos)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 20.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — check "
                    "lsusb, ls /dev/video*, and the App launch log.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


_stream_info = None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)
    for port, path in [(4912, "/"), (4912, "/stream"), (5050, "/")]:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            if getattr(resp, "status", 200) == 200 and _stream_info is None:
                _stream_info = {"port": port, "path": path, "content_type": ctype}
                log(f"[STREAM] raw stream at port {port}{path}")
            resp.close()
        except Exception:
            pass


threading.Thread(target=_probe_stream, daemon=True).start()

set_state("READY (arm disabled)")
log(f"Fruit sorter {VERSION} started — FIXED STATION, no xy anywhere. "
    f"Place ONE fruit on the marked spot. Enable the arm to act.")

App.run()
