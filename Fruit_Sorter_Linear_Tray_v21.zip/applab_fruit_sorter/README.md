# Fruit Sorting Robot — Linear Tray Layout v21

This is the complete Arduino App Lab fruit-sorting project. The camera identifies the fruit only; the arm uses fixed calibrated pickup and drop poses.

## v21 layout

The banana keeps its proven pickup direction and full-down wrist sequence. Only the base locations were widened:

```text
LEFT                                                         RIGHT
Apple drop       Banana pickup       Apple pickup       Banana drop
   ~70.2°             90.0°              ~109.2°             ~128.9°
```

At the configured working radius of 15 cm:

- Banana and apple pickup points are approximately **5 cm apart**.
- Apple drops approximately **10 cm outward/left from its pickup**.
- Banana drops approximately **10 cm outward/right from its pickup**.
- The four zones form one consistent row suitable for one long tray or box.

The program calculates the required base angles from centimetres:

```python
WORKING_RADIUS_CM = 15.0
PICKUP_SPACING_CM = 5.0
DROP_FROM_PICKUP_CM = 10.0
```

If the measured distance from the base pivot to the fruit is not 15 cm, change only `WORKING_RADIUS_CM`. This is important because the real centimetre spacing depends on the physical arm radius.

## Banana pickup retained

For banana pickup only:

- Channel 4 rotates the claw to `0°`.
- Channel 3 bends fully down to its safe minimum of `10°` before extending.
- The existing approach, descent, grip, lift and raised drop style are unchanged.

```python
BANANA_WRIST_ROTATE = 0.0
BANANA_PICKUP_WRIST_PITCH_DEG = 10.0
```

## Servo order

```text
CH0 base
CH1 shoulder
CH2 elbow
CH3 wrist pitch
CH4 wrist/claw rotation
CH5 gripper open/close
```

Test the new base positions without fruit first and keep the E-STOP ready. The layout follows a circular arc because it is produced by base rotation; over this short working area it forms the intended single-row tray arrangement.
