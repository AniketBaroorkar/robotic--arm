# Fruit Sorting Robot — Nearby Left/Right Drop v16

The camera identifies the fruit only. Pickup and drop locations are fixed servo poses.

## Current fruit locations

- Banana pickup: the proven pickup position at base `90°`.
- Apple pickup: `15°` to the right of the banana pickup, at base `105°`.
- Apple drop: approximately `5 cm` to the left of its own pickup point.
- Banana drop: approximately `5 cm` to the right of its own pickup point.
- Orange continues to use its original sorting-box location.

At an arm reach of roughly 15 cm, a base change of about 18° gives close to 5 cm of sideways movement. Physical link lengths can change the real distance.

## Main adjustment

Edit `python/main.py` and find:

```python
SIDE_DROP_OFFSET_DEG = 18.0
```

- Increase it if the drop needs to move farther sideways.
- Decrease it if the drop is too far away.
- Tune in steps of `1°–2°`.

The code calculates:

```python
APPLE_DROP_BASE = APPLE_PICKUP_BASE - SIDE_DROP_OFFSET_DEG
BANANA_DROP_BASE = BANANA_PICKUP_BASE + SIDE_DROP_OFFSET_DEG
```

On this calibrated arm, increasing the base angle means moving right. Therefore apple subtracts the offset to move left, and banana adds it to move right.

## Drop height

The nearby drop poses are:

```python
"apple_above":  (APPLE_DROP_BASE,  48.0, 122.0, 36.0, 90.0)
"apple_drop":   (APPLE_DROP_BASE,  52.0, 140.0, 32.0, 90.0)
"banana_above": (BANANA_DROP_BASE, 48.0, 122.0, 36.0, 90.0)
"banana_drop":  (BANANA_DROP_BASE, 52.0, 140.0, 32.0, 90.0)
```

The drop pose is intentionally slightly higher than the pickup pose, preventing the held fruit from being pushed into the table before release.

## Motion sequence

1. Confirm the fruit using 4 of 5 camera frames.
2. Move to its fixed pickup direction.
3. Descend through three controlled waypoints.
4. Lock arm servos 0–4 and close only the gripper.
5. Reverse the pickup path to lift vertically.
6. Move through the safe travel pose.
7. Rotate to the fruit-specific nearby drop position.
8. Lower, lock the arm and open only the gripper.
9. Return home.

The old `WAITING_FOR_CLEAR` gate remains removed, with a one-second cooldown between cycles.

## Safe calibration

Run the arm with no fruit first and keep the E-STOP ready. Adjust `SIDE_DROP_OFFSET_DEG` before changing the shoulder, elbow or wrist drop angles. Use a light fruit for the first complete test.
