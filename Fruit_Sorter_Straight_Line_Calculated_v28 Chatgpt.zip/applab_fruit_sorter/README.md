# Fruit Sorting Robot — Calculated Straight-Line Tray v28

This is the complete Arduino App Lab project. Fruit sorting starts automatically after App Launch. The web page keeps E-STOP, Reset E-STOP, Home and test controls; there is no pickup enable/disable button.

## Corrected straight-line layout

The older versions changed only the base angle while keeping the same arm reach. That places the marks on a circular arc, which is why the drops did not line up with the pickups.

Version 28 defines every mark as a real coordinate on one straight tray line located 15 cm in front of the base pivot:

```text
LEFT                                                                      RIGHT
Apple drop        Banana/Orange pickup        Apple pickup        Banana drop        Orange drop
x = -12 cm              x = -3 cm               x = +3 cm          x = +12 cm          x = +16 cm
```

Main pickup spacing is still 6 cm. The nearest drop-to-pickup gap is now 9 cm, so dropped fruit does not land beside a pickup mark.

Calculated base directions:

```text
Apple drop:            51.34°
Banana/Orange pickup:  78.69°
Centre:                 90.00°
Apple pickup:          101.31°
Banana drop:           128.66°
Orange drop:           136.85°
```

The pickup radius is 15.30 cm. The main drop radius is 19.21 cm, so the drop poses include shoulder, elbow and wrist reach correction instead of using only the base angle.

## Main geometry settings

Edit these only if the physical tray dimensions change:

```python
TRAY_FORWARD_CM = 15.0
PICKUP_HALF_SPACING_CM = 3.0
MAIN_DROP_SIDE_CM = 12.0
ORANGE_DROP_SIDE_CM = 16.0
```

The code calculates the base angles using:

```python
90° + atan2(sideways_distance, forward_distance)
```

## Reach correction

The calculated base angles are exact for the coordinate layout. Servo horn installation and link dimensions vary between arms, so the radial reach correction is intentionally grouped in three calibration gains:

```python
DROP_SHOULDER_DEG_PER_CM = -1.20
DROP_ELBOW_DEG_PER_CM = -1.00
DROP_WRIST_DEG_PER_CM = 0.50
```

Test the empty-arm drop movement first. If both drops are equally behind or ahead of the printed straight line, adjust only these three gains in small steps; do not change the calculated base angles.

## Banana movement

Pickup:

```text
CH3 wrist pitch = 10°
CH4 wrist rotation = 0°
```

Safe travel and vertical release:

```text
CH4 wrist rotation = 90°
```

The banana rotates upright only while the arm is compact and lifted. It remains upright during lowering and release.

## Servo order

```text
CH0 base
CH1 shoulder
CH2 elbow
CH3 wrist pitch
CH4 wrist/claw rotation
CH5 gripper open/close
```

Mark the tray from the base pivot, test every location without fruit, and keep E-STOP ready during calibration.
