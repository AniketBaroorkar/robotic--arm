# Fruit Sorting Robot — Symmetric Pickups / 8 cm Equal Drops v27

This is the complete Arduino App Lab project. The camera identifies the fruit and the arm starts sorting automatically; there is no pickup enable/disable button. E-STOP and Reset remain available.

## v27 tray layout

The apple and banana pickup marks are now balanced around the arm's 90° centre direction:

- Banana/Orange pickup: approximately **3 cm left of centre**.
- Apple pickup: approximately **3 cm right of centre**.
- Total pickup spacing: approximately **6 cm**.
- Apple and banana drops remain **8 cm outward from their own pickup points**.

At the configured 15 cm working radius, the calculated base directions are approximately:

```text
LEFT                                                                      RIGHT
Apple drop   Banana/Orange pickup   90° centre   Apple pickup   Banana drop   Orange drop
  ~70.6°             ~78.5°             90.0°        ~101.5°        ~109.4°        165.0°
```

This arrangement is more balanced than keeping one pickup at 90° and placing the other entirely to one side. The two pickup spots and the two main drop spots are symmetric around the same centre line.

The base rotates in a circle, so the physical marks lie on one constant-radius **arc**, not a mathematically straight line. Keep the shoulder and elbow reach unchanged and align the long tray along the tested arc.

Adjust spacing in `python/main.py`:

```python
WORKING_RADIUS_CM = 15.0
PICKUP_SPACING_CM = 6.0
APPLE_DROP_FROM_PICKUP_CM = 8.0
BANANA_DROP_FROM_PICKUP_CM = 8.0
PICKUP_CENTER_BASE = 90.0
ORANGE_DROP_BASE = 165.0
```

The code automatically splits `PICKUP_SPACING_CM` equally around `PICKUP_CENTER_BASE`.

## Banana movement

Pickup:

```text
CH3 wrist pitch = 10°
CH4 wrist rotation = 0°
```

Safe travel and vertical drop:

```text
CH4 wrist rotation = 90°
```

The banana rotates from horizontal to vertical only while the arm is compact and lifted. It remains vertical while lowering and releasing.

## Automatic operation

- The robot starts in automatic mode when the app launches.
- Stable fruit detection starts the cycle automatically.
- E-STOP pauses sorting.
- Reset E-STOP resumes sorting.

## Servo order

```text
CH0 base
CH1 shoulder
CH2 elbow
CH3 wrist pitch
CH4 wrist/claw rotation
CH5 gripper open/close
```

Test every base position without fruit first and keep the E-STOP ready.
