const $=id=>document.getElementById(id);

const speed=$('speed');
const mic=$('mic-button');

let listening=false;
let modelReady=false;
let pttActive=false;
let pttStopTimer=null;
let lastAck=-1;

// ============================================================
// API
// ============================================================

async function api(url,opt={}){
  const r=await fetch(
    url,
    {
      cache:'no-store',
      ...opt
    }
  );

  const d=await r.json();

  if(!r.ok){
    throw new Error(
      d.error||r.status
    );
  }

  return d;
}


function fmt(v,d=1){
  if(
    v===null||
    v===undefined
  ){
    return '--';
  }

  const n=Number(v);

  return Number.isFinite(n)
    ?n.toFixed(d)
    :'--';
}


async function cmd(command){
  try{
    await api(
      '/api/command',
      {
        method:'POST',

        headers:{
          'Content-Type':
            'application/json'
        },

        body:JSON.stringify({
          command,
          speed:Number(
            speed.value
          )
        })
      }
    );
  }
  catch(e){
    console.error(
      'Command error',
      e
    );
  }
}


// ============================================================
// CONNECTION / SPEED / VOICE
// ============================================================

$('connect').onclick=async()=>{
  const ip=$(
    'rover-ip'
  ).value.trim();

  $('connection-error').textContent=
    'Checking...';

  try{
    const r=await api(
      '/api/rover-ip',
      {
        method:'POST',

        headers:{
          'Content-Type':
            'application/json'
        },

        body:JSON.stringify({
          rover_ip:ip
        })
      }
    );

    $('connection-error').textContent=
      r.ok
        ?'Connected to Rover API'
        :'Could not connect: '+
          (r.error||'unknown error');
  }
  catch(e){
    $('connection-error').textContent=
      'Could not connect: '+
      e.message;
  }
};



$('connect-satellite').onclick=async()=>{
  const ip=$(
    'satellite-ip'
  ).value.trim();

  $('satellite-connection-error').textContent=
    'Checking...';

  try{
    const r=await api(
      '/api/satellite-ip',
      {
        method:'POST',

        headers:{
          'Content-Type':
            'application/json'
        },

        body:JSON.stringify({
          satellite_ip:ip
        })
      }
    );

    $('satellite-connection-error').textContent=
      r.ok
        ?'Satellite link established'
        :'Could not connect: '+
          (r.error||'unknown error');
  }
  catch(e){
    $('satellite-connection-error').textContent=
      'Could not connect: '+
      e.message;
  }
};


speed.oninput=async()=>{
  $('speed-value').textContent=
    speed.value;

  try{
    await api(
      '/api/speed',
      {
        method:'POST',

        headers:{
          'Content-Type':
            'application/json'
        },

        body:JSON.stringify({
          speed:Number(
            speed.value
          )
        })
      }
    );
  }
  catch(e){}
};


async function pttStart(ev){
  if(ev){
    ev.preventDefault();
  }

  if(!modelReady||pttActive){
    return;
  }

  if(pttStopTimer){
    clearTimeout(pttStopTimer);
    pttStopTimer=null;
  }

  pttActive=true;
  mic.classList.add('listening');
  $('mic-button-text').textContent='LISTENING… RELEASE TO SEND';

  try{
    const r=await api(
      '/api/voice/start',
      {
        method:'POST'
      }
    );

    if(!r.ok){
      throw new Error(
        r.error||
        'Push-to-talk failed'
      );
    }
  }
  catch(e){
    pttActive=false;
    mic.classList.remove('listening');

    $('voice-error').textContent=
      e.message;

    $('voice-error').classList.remove(
      'hidden'
    );
  }
}


function pttStop(ev){
  if(ev){
    ev.preventDefault();
  }

  if(!pttActive){
    return;
  }

  pttActive=false;
  mic.classList.remove('listening');
  $('mic-button-text').textContent='HOLD TO TALK';

  // Small release delay lets Vosk finish the final word/partial.
  pttStopTimer=setTimeout(
    async()=>{
      try{
        await api(
          '/api/voice/stop',
          {
            method:'POST'
          }
        );
      }
      catch(e){}

      pttStopTimer=null;
    },
    220
  );
}


mic.onpointerdown=pttStart;
mic.onpointerup=pttStop;
mic.onpointercancel=pttStop;
mic.onpointerleave=ev=>{
  if(
    pttActive
    && ev.buttons===0
  ){
    pttStop(ev);
  }
};

mic.oncontextmenu=ev=>{
  ev.preventDefault();
};



$('retry-model').onclick=()=>{
  api(
    '/api/model/retry',
    {
      method:'POST'
    }
  );
};


// ============================================================
// MANUAL ARROW BUTTONS
// ============================================================

let heldPointer=null;

document
  .querySelectorAll(
    '.drive'
  )
  .forEach(button=>{
    const command=
      button.dataset.command;

    if(command==='STOP'){
      button.onpointerdown=
        event=>{
          event.preventDefault();
          heldPointer=null;
          cmd('STOP');
        };

      return;
    }

    button.onpointerdown=
      event=>{
        event.preventDefault();

        heldPointer=command;

        button.classList.add(
          'active'
        );

        try{
          button.setPointerCapture(
            event.pointerId
          );
        }
        catch(_){}

        cmd(command);
      };

    const release=
      event=>{
        if(event){
          event.preventDefault();
        }

        if(
          heldPointer
          ===command
        ){
          heldPointer=null;

          button.classList.remove(
            'active'
          );

          cmd('STOP');
        }
      };

    button.onpointerup=
      release;

    button.onpointercancel=
      release;

    button.onlostpointercapture=
      release;
  });


// ============================================================
// EMERGENCY STOP
// ============================================================

$('estop').onclick=async()=>{
  heldPointer=null;
  pressedKeys.clear();

  document
    .querySelectorAll(
      '.drive'
    )
    .forEach(
      x=>x.classList.remove(
        'active'
      )
    );

  try{
    await api(
      '/api/emergency-stop',
      {
        method:'POST'
      }
    );
  }
  catch(e){
    console.error(
      'Emergency stop error',
      e
    );
  }
};


// ============================================================
// KEYBOARD MULTI-KEY CONTROL
//
// W       = FORWARD
// S       = BACKWARD
// A       = smooth LEFT
// D       = smooth RIGHT
// W + A   = FORWARD_LEFT
// W + D   = FORWARD_RIGHT
// S + A   = BACKWARD_LEFT
// S + D   = BACKWARD_RIGHT
// SPACE   = EMERGENCY STOP
// ============================================================

const pressedKeys=
  new Set();

let lastKeyboardCommand=
  'STOP';


function normalizeKey(key){
  const k=
    String(key).toLowerCase();

  if(
    k==='arrowup'
  ){
    return 'w';
  }

  if(
    k==='arrowdown'
  ){
    return 's';
  }

  if(
    k==='arrowleft'
  ){
    return 'a';
  }

  if(
    k==='arrowright'
  ){
    return 'd';
  }

  return k;
}


function keyboardCommand(){
  const w=
    pressedKeys.has('w');

  const s=
    pressedKeys.has('s');

  const a=
    pressedKeys.has('a');

  const d=
    pressedKeys.has('d');

  // Opposite direction keys cancel safely.
  if(
    (w&&s)||
    (a&&d)
  ){
    return 'STOP';
  }

  if(w&&a){
    return 'TURN_LEFT';
  }

  if(w&&d){
    return 'TURN_RIGHT';
  }

  if(s&&a){
    return 'BACKWARD_LEFT';
  }

  if(s&&d){
    return 'BACKWARD_RIGHT';
  }

  if(w){
    return 'FORWARD';
  }

  if(s){
    return 'BACKWARD';
  }

  if(a){
    return 'LEFT';
  }

  if(d){
    return 'RIGHT';
  }

  return 'STOP';
}


function updateKeyboardCommand(){
  const next=
    keyboardCommand();

  if(
    next===
    lastKeyboardCommand
  ){
    return;
  }

  lastKeyboardCommand=
    next;

  cmd(next);
}


document.addEventListener(
  'keydown',
  event=>{
    if(
      event.code===
      'Space'
    ){
      event.preventDefault();

      $('estop').click();

      return;
    }

    const key=
      normalizeKey(
        event.key
      );

    if(
      ![
        'w',
        'a',
        's',
        'd'
      ].includes(key)
    ){
      return;
    }

    event.preventDefault();

    pressedKeys.add(
      key
    );

    updateKeyboardCommand();
  }
);


document.addEventListener(
  'keyup',
  event=>{
    const key=
      normalizeKey(
        event.key
      );

    if(
      ![
        'w',
        'a',
        's',
        'd'
      ].includes(key)
    ){
      return;
    }

    event.preventDefault();

    pressedKeys.delete(
      key
    );

    updateKeyboardCommand();
  }
);


window.addEventListener(
  'blur',
  ()=>{
    pressedKeys.clear();
    lastKeyboardCommand=
      'STOP';

    cmd('STOP');
  }
);



function hist(a){$('history').innerHTML='';(a||[]).slice(0,10).forEach(x=>{const r=document.createElement('div');r.className='history-item';const t=document.createElement('span');t.className='history-time';t.textContent=x.time||'';const s=document.createElement('span');s.className='history-source';s.textContent=x.source||'';const q=document.createElement('span');q.textContent=x.text||'';r.append(t,s,q);$('history').append(r)})}

let audioEnabled=true;

$('test-speaker').onclick=async()=>{
  try{
    await api('/api/audio/test',{method:'POST'});
  }catch(e){
    console.error('Speaker test error',e);
  }
};

$('toggle-audio').onclick=async()=>{
  audioEnabled=!audioEnabled;
  try{
    const r=await api('/api/audio/enabled',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({enabled:audioEnabled})
    });
    audioEnabled=!!r.audio_enabled;
    $('toggle-audio').textContent=audioEnabled?'AUDIO ON':'AUDIO OFF';
  }catch(e){
    console.error('Audio toggle error',e);
  }
};

async function refresh(){try{const s=await api('/api/state');$('rover-pill').classList.toggle('online',!!s.rover_online);
$('satellite-pill').classList.toggle('online',!!s.satellite_online);
$('satellite-text').textContent=s.satellite_online?'SATELLITE ONLINE':'SATELLITE OFFLINE';
$('satellite-url').textContent=s.satellite_url||'IP NOT SET';
if(s.satellite_ip&&document.activeElement!==$('satellite-ip'))$('satellite-ip').value=s.satellite_ip;
$('satellite-ping').textContent=s.satellite_online?`Connected • ${s.satellite_ping_ms??'--'} ms`:'Waiting for Satellite...';
$('satellite-connection-error').textContent=s.satellite_connection_error||'';
$('satellite-command').textContent='LAST: '+(s.satellite_last_command||'STOP');
$('satellite-packets').textContent='PACKETS: '+(s.satellite_tx_counter??0);
$('rover-text').textContent=s.rover_online?'ROVER ONLINE':'ROVER OFFLINE';$('ack-pill').classList.toggle('ok',!!s.ack_ok);$('ack-text').textContent=s.ack_ok?'COMMAND ACK':'NO ACK';$('rover-url').textContent=s.rover_url||'--';if(s.rover_ip&&document.activeElement!==$('rover-ip'))$('rover-ip').value=s.rover_ip;$('ping').textContent=s.rover_online?`Connected • ${s.ping_ms??'--'} ms`:'Waiting for Rover...';$('connection-error').textContent=s.connection_error||'';
    if($('speaker-state')){
      $('speaker-state').textContent=s.speaker_talking?'SPEAKING':(s.speaker_connected?'BLUETOOTH AUDIO READY':'BLUETOOTH AUDIO NOT READY');
      $('speaker-name').textContent=s.speaker_name||'Bluetooth Speaker';
      $('speaker-device').textContent=s.speaker_device||'Wireless audio';
      $('last-announcement').textContent=s.last_announcement||'Waiting for mission events...';
      $('speaker-error').textContent=s.speaker_error||'';
      audioEnabled=s.audio_enabled!==false;
      $('toggle-audio').textContent=audioEnabled?'AUDIO ON':'AUDIO OFF';
    }const st=s.model_status||'UNKNOWN',p=Math.max(0,Math.min(100,Number(s.model_progress||0)));$('model-status').textContent=st;$('model-progress').textContent=p+'%';$('progress-bar').style.width=p+'%';modelReady=st==='READY';listening=!!s.voice_listening;const serverPtt=!!s.voice_listening;$('mic-state').textContent=serverPtt?'PTT ACTIVE':(modelReady?'READY':'MIC OFF');mic.disabled=!modelReady;if(!pttActive&&!serverPtt){$('mic-button-text').textContent=modelReady?'HOLD TO TALK':'WAITING FOR MODEL'}$('mic-connected').textContent=s.mic_connected?'CONNECTED':'DISCONNECTED';$('mic-connected').classList.toggle('connected',!!s.mic_connected);$('mic-name').textContent=s.mic_name||'Waiting...';$('mic-device').textContent=s.mic_device||'';const lv=Math.max(0,Math.min(100,Number(s.mic_level_percent||0)));$('audio-level').style.width=lv+'%';$('level-number').textContent=lv+'%';$('gain-number').textContent=Number(s.auto_gain||1).toFixed(1)+'×';$('transcription').textContent=s.last_transcription||'Say forward, backward, left, right, stop, or status.';$('partial').textContent=s.partial_transcription?'Listening: '+s.partial_transcription:'';$('voice-command').textContent=s.last_voice_command||'WAITING';$('active-command').textContent=s.active_command||'STOP';$('command-source').textContent=s.command_source||'SYSTEM';if(Number(speed.value)!==Number(s.speed)){speed.value=s.speed||100;$('speed-value').textContent=speed.value}$('temp').textContent=fmt(s.temperature_c);$('humidity').textContent=fmt(s.humidity_percent);$('pressure').textContent=fmt(s.pressure_hpa);$('distance').textContent=fmt(s.distance_cm);$('air').textContent=s.air_quality_raw??'--';$('rover-motion').textContent=s.rover_motion||'STOP';$('rover-speed').textContent=s.rover_motor_speed??0;$('dht').textContent='DHT22: '+(s.dht_ok?'OK':'NO DATA');$('dht').classList.toggle('ok',!!s.dht_ok);$('bmp').textContent='BMP280: '+(s.bmp_ok?'OK':'NO DATA');$('bmp').classList.toggle('ok',!!s.bmp_ok);
    if($('ultrasonic-status')){
      $('ultrasonic-status').textContent=
        'ULTRASONIC: '+
        (s.ultrasonic_ok?'OK':'NO ECHO');
      $('ultrasonic-status').classList.toggle(
        'ok',
        !!s.ultrasonic_ok
      );
    }
    if($('safety-status')){
      $('safety-status').textContent=
        s.safety_stop
          ?'SAFETY STOP: OBSTACLE'
          :(s.obstacle_blocked
            ?'OBSTACLE CLOSE'
            :'SAFETY: CLEAR');
      $('safety-status').classList.toggle(
        'ok',
        !s.obstacle_blocked
      );
    }$('age').textContent=s.rover_age_ms===null?'Waiting...':s.rover_age_ms+' ms ago';$('ack-command').textContent=s.ack_command||'--';$('ack-status').textContent=s.ack_status||'--';if(s.ack_counter!==lastAck){lastAck=s.ack_counter}if(s.voice_error){$('voice-error').textContent=s.voice_error;$('voice-error').classList.remove('hidden')}else $('voice-error').classList.add('hidden');$('retry-model').classList.toggle('hidden',st!=='ERROR');hist(s.history)}catch(e){console.error(e)}}setInterval(refresh,200);refresh();
window.addEventListener('blur',()=>{
  if(held||keyHeld){
    held=null;
    keyHeld=null;
    cmd('STOP');
  }
});
