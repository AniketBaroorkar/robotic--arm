The same Vosk model used by the successful voice test is downloaded automatically on first run if missing.
