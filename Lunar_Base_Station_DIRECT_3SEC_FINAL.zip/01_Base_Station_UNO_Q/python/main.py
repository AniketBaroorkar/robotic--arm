from arduino.app_bricks.web_ui import WebUI
from arduino.app_peripherals.microphone import Microphone
from arduino.app_utils import App, Logger

from fastapi import Request

from pathlib import Path
import json
import importlib
import subprocess
import sys
import numpy as np
import re
import shutil
import threading
import time
import urllib.error
import urllib.request
import zipfile


logger = Logger("LunarBaseHTTP")
ui = WebUI(api_path_prefix="/api")

# ============================================================
# BLUETOOTH / LINUX AUDIO OUTPUT
# ============================================================
#
# Pair the Bluetooth speaker with the UNO Q Linux desktop first.
# The App then plays normal WAV files through the current default
# Linux audio output. If the Bluetooth speaker is the active/default
# output, all spoken command feedback comes from it.
#
# No D10 speaker hardware is used.
# ============================================================

AUDIO_DIR = Path(__file__).resolve().parents[1] / "audio"

AUDIO_DURATIONS_MS = {
    "forward.wav": 1777,
    "backward.wav": 1777,
    "left.wav": 1777,
    "right.wav": 1777,
    "turn_left.wav": 1777,
    "turn_right.wav": 1777,
    "backward_left.wav": 1777,
    "backward_right.wav": 1777,
    "stopped.wav": 1312,
    "emergency.wav": 1473,
    "obstacle.wav": 1742,
    "voice_active.wav": 1852,
    "telemetry.wav": 1538,
    "startup.wav": 1696,
    "rover_link.wav": 1467,
    "rover_restored.wav": 1614,
    "rover_lost.wav": 1502,
    "audio_test.wav": 1702,
    "satellite_link.wav": 1693,
}

speech_generation = 0
speech_generation_lock = threading.Lock()

audio_process_lock = threading.Lock()
audio_process = None
audio_player_name = ""


# ============================================================
# ROVER NETWORK
# ============================================================

ROVER_PORT = 7000
DEFAULT_ROVER_IP = "10.61.26.81"   # Current Rover IP; editable from WebUI.
HTTP_TIMEOUT_S = 0.75
CONTROL_REFRESH_S = 0.25
TELEMETRY_PERIOD_S = 0.40
PING_PERIOD_S = 1.50

CONFIG_DIR = Path("/home/arduino/.config/lunar_base")
ROVER_IP_FILE = CONFIG_DIR / "rover_ip_http.txt"

SATELLITE_PORT = 7000
SATELLITE_HTTP_TIMEOUT_S = 0.65
SATELLITE_REFRESH_S = 0.20
SATELLITE_PING_PERIOD_S = 1.00
ROVER_START_DELAY_S = 3.0
SATELLITE_READY_ANGLE = 88
SATELLITE_READY_TIMEOUT_S = 4.50
SATELLITE_READY_POLL_S = 0.05
SATELLITE_IP_FILE = CONFIG_DIR / "satellite_ip_http.txt"

# ============================================================
# WORKING VOSK / USB MICROPHONE SETTINGS
# Same core settings as the successful FORWARD voice test.
# ============================================================

MIC_DEVICE = Microphone.USB_MIC_1
SAMPLE_RATE = Microphone.RATE_16K
CHANNELS = Microphone.CHANNELS_MONO
BUFFER_SIZE = Microphone.BUFFER_SIZE_SAFE

MODEL_NAME = "vosk-model-small-en-in-0.4"
MODEL_URL = (
    "https://alphacephei.com/vosk/models/"
    "vosk-model-small-en-in-0.4.zip"
)

VOSK_GRAMMAR = [
    "forward",
    "go forward",
    "move forward",
    "straight",
    "go straight",

    "backward",
    "go backward",
    "move backward",
    "go back",
    "reverse",

    # LEFT alone = rotate on spot
    "left",
    "go left",
    "move left",
    "lift",

    # TURN LEFT = forward curve
    "turn left",
    "turn to the left",
    "left turn",
    "curve left",
    "turn lift",

    # RIGHT alone = rotate on spot
    "right",
    "go right",
    "move right",
    "write",

    # TURN RIGHT = forward curve
    "turn right",
    "turn to the right",
    "right turn",
    "curve right",
    "turn write",

    "stop",
    "halt",
    "emergency stop",

    "status",
    "rover status",

    "[unk]",
]

TARGET_RMS = 5000.0
MAX_GAIN = 20.0
VOICE_DUPLICATE_DEBOUNCE_S = 0.55

# ============================================================
# STATE
# ============================================================

state_lock = threading.Lock()
command_lock = threading.Lock()
model_lock = threading.Lock()
command_event = threading.Event()
emergency_event = threading.Event()
satellite_command_event = threading.Event()
satellite_lock = threading.Lock()

# Mission-control D10 speech state
speaker_talking = threading.Event()
reset_recognizer_event = threading.Event()
voice_guard_until = 0.0
last_announcement_times = {}
last_announced_ack_sequence = -1
first_rover_link_announced = False
first_satellite_link_announced = False
telemetry_announced = False
last_link_online_for_audio = False
last_safety_stop_for_audio = False

voice_stop_event = threading.Event()
ptt_active_event = threading.Event()
voice_thread = None
microphone = None
vosk_model = None

active_command = "STOP"
active_speed = 100
active_source = "SYSTEM"
command_sequence = 0

last_voice_command = ""
last_voice_command_time = 0.0
last_acked_sequence = None

last_ping_time = 0.0
last_telemetry_time = 0.0
last_control_time = 0.0
last_rover_success = 0.0
last_satellite_success = 0.0
last_satellite_ping_time = 0.0
last_satellite_send_time = 0.0
relay_ready_sequence = -1

state = {
    "rover_ip": "",
    "rover_url": "",
    "rover_online": False,
    "connection_error": "",
    "ping_ms": None,

    "satellite_ip": "",
    "satellite_url": "",
    "satellite_online": False,
    "satellite_connection_error": "",
    "satellite_ping_ms": None,
    "satellite_tx_counter": 0,
    "satellite_last_command": "STOP",
    "satellite_last_sequence": -1,
    "relay_waiting": False,
    "relay_status": "IDLE",

    "temperature_c": None,
    "humidity_percent": None,
    "pressure_hpa": None,
    "distance_cm": None,
    "air_quality_raw": None,
    "rover_motion": "STOP",
    "rover_motor_speed": 0,
    "dht_ok": False,
    "bmp_ok": False,
    "ultrasonic_ok": False,
    "obstacle_blocked": False,
    "safety_stop": False,

    "active_command": "STOP",
    "command_source": "SYSTEM",
    "speed": 100,
    "sequence": 0,

    "ack_ok": False,
    "ack_command": "",
    "ack_status": "",
    "ack_sequence": None,
    "tx_counter": 0,
    "ack_counter": 0,

    "voice_listening": False,
    "ptt_active": False,
    "voice_error": "",
    "last_transcription": "",
    "partial_transcription": "",
    "last_voice_command": "",

    "mic_connected": False,
    "mic_name": "",
    "mic_device": "",
    "mic_level_percent": 0,
    "mic_rms": 0,
    "mic_peak": 0,
    "auto_gain": 1.0,

    "model_status": "STARTING",
    "model_progress": 0,
    "model_path": "",

    "speaker_connected": False,
    "speaker_name": "Bluetooth Speaker",
    "speaker_device": "Linux default audio",
    "speaker_status": "CHECKING AUDIO",
    "speaker_error": "",
    "speaker_talking": False,
    "last_announcement": "",
    "audio_enabled": True,

    "history": [
        {
            "time": time.strftime("%H:%M:%S"),
            "source": "SYSTEM",
            "text": "Base Station started",
        }
    ],
}


def set_state(**kwargs):
    with state_lock:
        state.update(kwargs)


def add_history(source, text):
    with state_lock:
        state["history"].insert(0, {
            "time": time.strftime("%H:%M:%S"),
            "source": str(source),
            "text": str(text),
        })
        state["history"] = state["history"][:15]


def valid_ipv4(value):
    try:
        parts = str(value).strip().split(".")
        return len(parts) == 4 and all(0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False


def load_rover_ip():
    try:
        if ROVER_IP_FILE.exists():
            value = ROVER_IP_FILE.read_text(encoding="utf-8").strip()
            if valid_ipv4(value):
                return value
    except Exception:
        pass
    return DEFAULT_ROVER_IP


def save_rover_ip(value):
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        ROVER_IP_FILE.write_text(value, encoding="utf-8")
    except Exception as exc:
        logger.warning(f"Could not save Rover IP: {exc}")


def set_rover_ip(value, save=True):
    value = str(value).strip()
    if not valid_ipv4(value):
        return False
    set_state(
        rover_ip=value,
        rover_url=f"http://{value}:{ROVER_PORT}",
        rover_online=False,
        connection_error="",
    )
    if save:
        save_rover_ip(value)
    add_history("LINK", f"Rover IP set to {value}")
    return True


set_rover_ip(load_rover_ip(), save=False)



def load_satellite_ip():
    try:
        if SATELLITE_IP_FILE.exists():
            value = SATELLITE_IP_FILE.read_text(
                encoding="utf-8"
            ).strip()
            if valid_ipv4(value):
                return value
    except Exception:
        pass
    return ""


def save_satellite_ip(value):
    try:
        CONFIG_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )
        SATELLITE_IP_FILE.write_text(
            value,
            encoding="utf-8",
        )
    except Exception as exc:
        logger.warning(
            f"Could not save Satellite IP: {exc}"
        )


def set_satellite_ip(value, save=True):
    value = str(value).strip()

    if value == "":
        set_state(
            satellite_ip="",
            satellite_url="",
            satellite_online=False,
            satellite_connection_error="",
            satellite_ping_ms=None,
        )
        if save:
            save_satellite_ip("")
        return True

    if not valid_ipv4(value):
        return False

    set_state(
        satellite_ip=value,
        satellite_url=f"http://{value}:{SATELLITE_PORT}",
        satellite_online=False,
        satellite_connection_error="",
    )

    if save:
        save_satellite_ip(value)

    add_history(
        "SAT",
        f"Satellite IP set to {value}",
    )

    satellite_command_event.set()
    return True


set_satellite_ip(
    load_satellite_ip(),
    save=False,
)


def _next_speech_generation():
    global speech_generation

    with speech_generation_lock:
        speech_generation += 1
        return speech_generation


def detect_audio_player():
    """
    Pick the first standard Linux WAV player available on the UNO Q.

    pw-play  -> PipeWire
    paplay   -> PulseAudio / PipeWire Pulse compatibility
    aplay    -> ALSA
    ffplay   -> fallback if installed
    """
    candidates = [
        ("pw-play", ["pw-play"]),
        ("paplay", ["paplay"]),
        ("aplay", ["aplay", "-q"]),
        (
            "ffplay",
            [
                "ffplay",
                "-nodisp",
                "-autoexit",
                "-loglevel",
                "quiet",
            ],
        ),
    ]

    for name, command in candidates:
        if shutil.which(name):
            return name, command

    return "", []


def bluetooth_status_text():
    """
    Best-effort Bluetooth status.

    The App does not hard-code a MAC address. Pairing is done once in the
    UNO Q desktop/terminal, and Linux handles reconnection/audio routing.
    """
    if not shutil.which("bluetoothctl"):
        return ""

    try:
        result = subprocess.run(
            [
                "bluetoothctl",
                "devices",
                "Connected",
            ],
            capture_output=True,
            text=True,
            timeout=2,
        )

        text = (
            result.stdout
            or ""
        ).strip()

        if text:
            return text

    except Exception:
        pass

    return ""


def stop_audio_process():
    global audio_process

    with audio_process_lock:
        process = audio_process
        audio_process = None

    if process is None:
        return

    try:
        if process.poll() is None:
            process.terminate()

            try:
                process.wait(
                    timeout=0.4
                )
            except Exception:
                process.kill()
    except Exception:
        pass


def _finish_audio_process(
    generation,
    process,
):
    global voice_guard_until
    global audio_process

    try:
        process.wait()
    except Exception:
        pass

    with speech_generation_lock:
        current_generation = (
            speech_generation
        )

    # A newer command has already replaced this audio.
    if current_generation != generation:
        return

    with audio_process_lock:
        if audio_process is process:
            audio_process = None

    speaker_talking.clear()

    voice_guard_until = max(
        voice_guard_until,
        time.monotonic() + 0.15,
    )

    reset_recognizer_event.set()

    set_state(
        speaker_talking=False,
        speaker_status="READY",
    )


def bluetooth_speaker_probe_worker():
    global audio_player_name

    while True:
        name, command = detect_audio_player()

        connected_text = (
            bluetooth_status_text()
        )

        audio_player_name = name

        if name:
            device_text = (
                connected_text
                if connected_text
                else "Default Linux audio output"
            )

            set_state(
                speaker_connected=True,
                speaker_name="Bluetooth Speaker",
                speaker_device=device_text,
                speaker_status=(
                    "SPEAKING"
                    if speaker_talking.is_set()
                    else "READY"
                ),
                speaker_error="",
            )
        else:
            set_state(
                speaker_connected=False,
                speaker_name="Bluetooth Speaker",
                speaker_device="",
                speaker_status="NO AUDIO PLAYER",
                speaker_error=(
                    "No pw-play, paplay, aplay or ffplay command found."
                ),
            )

        time.sleep(2.0)


def queue_announcement(
    filename,
    display_text,
    priority=10,
    key=None,
    cooldown=0.0,
    interrupt=False,
):
    """
    Play a normal WAV file through Linux.

    Pair/connect the Bluetooth speaker and make it the active/default
    audio output. Linux routes this WAV to the Bluetooth speaker.
    """
    global voice_guard_until
    global audio_process
    global audio_player_name

    with state_lock:
        enabled = state.get(
            "audio_enabled",
            True,
        )

    if not enabled:
        return False

    file_path = AUDIO_DIR / str(filename)

    if not file_path.exists():
        set_state(
            speaker_error=f"Missing audio file: {filename}"
        )
        return False

    now = time.monotonic()

    if key:
        previous = last_announcement_times.get(
            key,
            0.0,
        )

        if (
            cooldown > 0
            and now - previous < cooldown
        ):
            return False

        last_announcement_times[key] = now

    command_files = {
        "forward.wav",
        "backward.wav",
        "left.wav",
        "right.wav",
        "turn_left.wav",
        "turn_right.wav",
        "backward_left.wav",
        "backward_right.wav",
        "stopped.wav",
    }

    safety_files = {
        "emergency.wav",
        "obstacle.wav",
        "rover_lost.wav",
    }

    important = (
        filename in command_files
        or filename in safety_files
        or interrupt
    )

    if (
        speaker_talking.is_set()
        and not important
    ):
        return False

    name, base_command = detect_audio_player()

    if not name:
        set_state(
            speaker_connected=False,
            speaker_status="NO AUDIO PLAYER",
            speaker_error=(
                "Connect the Bluetooth speaker and ensure "
                "pw-play, paplay, aplay or ffplay is available."
            ),
        )
        return False

    audio_player_name = name

    # Movement/safety commands replace old speech immediately.
    if important:
        stop_audio_process()

    generation = _next_speech_generation()

    command = (
        base_command
        + [str(file_path)]
    )

    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as exc:
        set_state(
            speaker_connected=False,
            speaker_status="PLAYBACK ERROR",
            speaker_error=str(exc),
        )
        return False

    with audio_process_lock:
        audio_process = process

    duration_ms = int(
        AUDIO_DURATIONS_MS.get(
            filename,
            900,
        )
    )

    speaker_talking.set()

    voice_guard_until = max(
        voice_guard_until,
        time.monotonic()
        + duration_ms / 1000.0
        + 0.20,
    )

    set_state(
        speaker_connected=True,
        speaker_name="Bluetooth Speaker",
        speaker_device=(
            bluetooth_status_text()
            or f"Linux audio via {name}"
        ),
        speaker_status="SPEAKING",
        speaker_talking=True,
        last_announcement=display_text,
        speaker_error="",
    )

    add_history(
        "AUDIO",
        display_text,
    )

    threading.Thread(
        target=_finish_audio_process,
        args=(
            generation,
            process,
        ),
        daemon=True,
    ).start()

    return True


COMMAND_AUDIO = {
    "FORWARD": "forward.wav",
    "BACKWARD": "backward.wav",
    "LEFT": "left.wav",
    "RIGHT": "right.wav",
    "TURN_LEFT": "turn_left.wav",
    "TURN_RIGHT": "turn_right.wav",
    "BACKWARD_LEFT":
        "backward_left.wav",
    "BACKWARD_RIGHT":
        "backward_right.wav",
    "STOP": "stopped.wav",
}


def announce_command_ack(
    command,
    sequence,
):
    global last_announced_ack_sequence

    try:
        sequence = int(
            sequence
        )
    except Exception:
        return

    if (
        sequence
        <= last_announced_ack_sequence
    ):
        return

    last_announced_ack_sequence = (
        sequence
    )

    filename = COMMAND_AUDIO.get(
        str(command).upper()
    )

    if not filename:
        return

    # Spoken output is intentionally short and fast.
    spoken_display = {
        "FORWARD":
            "Command executed",
        "BACKWARD":
            "Command executed",
        "LEFT":
            "Command executed",
        "RIGHT":
            "Command executed",
        "TURN_LEFT":
            "Command executed",
        "TURN_RIGHT":
            "Command executed",
        "BACKWARD_LEFT":
            "Command executed",
        "BACKWARD_RIGHT":
            "Command executed",
        "STOP":
            "Lunar stopped",
    }.get(
        str(command).upper(),
        str(command),
    )

    queue_announcement(
        filename,
        spoken_display,
        priority=3,
        key=f"ack:{sequence}",
        interrupt=True,
    )


# ============================================================
# HTTP CLIENT TO ROVER WEBUI
# Arduino WebUI exposes route '/ping' as '/api/ping'.
# ============================================================


def rover_http(method, path, payload=None, timeout=HTTP_TIMEOUT_S):
    with state_lock:
        ip = state["rover_ip"]

    if not ip:
        raise RuntimeError("Rover IP is not set")

    url = f"http://{ip}:{ROVER_PORT}/api{path}"
    data = None
    headers = {"Accept": "application/json"}

    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(
        url,
        data=data,
        headers=headers,
        method=method,
    )

    started = time.monotonic()
    with urllib.request.urlopen(req, timeout=timeout) as response:
        body = response.read().decode("utf-8")
        elapsed_ms = int((time.monotonic() - started) * 1000)
        parsed = json.loads(body) if body else {}
        return parsed, elapsed_ms


def satellite_http(
    method,
    path,
    payload=None,
    timeout=SATELLITE_HTTP_TIMEOUT_S,
):
    with state_lock:
        ip = state.get(
            "satellite_ip",
            "",
        )

    if not ip:
        raise RuntimeError(
            "Satellite IP is not set"
        )

    url = (
        f"http://{ip}:{SATELLITE_PORT}"
        f"/api{path}"
    )

    data = None
    headers = {
        "Accept":
            "application/json",
    }

    if payload is not None:
        data = json.dumps(
            payload
        ).encode("utf-8")

        headers[
            "Content-Type"
        ] = "application/json"

    req = urllib.request.Request(
        url,
        data=data,
        headers=headers,
        method=method,
    )

    started = time.monotonic()

    with urllib.request.urlopen(
        req,
        timeout=timeout,
    ) as response:
        body = response.read().decode(
            "utf-8"
        )

        elapsed_ms = int(
            (
                time.monotonic()
                - started
            )
            * 1000
        )

        parsed = (
            json.loads(body)
            if body
            else {}
        )

        return parsed, elapsed_ms


def mark_satellite_success(
    ping_ms=None
):
    global last_satellite_success

    last_satellite_success = (
        time.monotonic()
    )

    values = {
        "satellite_online": True,
        "satellite_connection_error": "",
    }

    if ping_ms is not None:
        values[
            "satellite_ping_ms"
        ] = ping_ms

    set_state(
        **values
    )


def ping_satellite():
    try:
        result, elapsed = (
            satellite_http(
                "GET",
                "/ping",
            )
        )

        if (
            result.get("ok")
            and result.get("node")
            == "satellite"
        ):
            mark_satellite_success(
                elapsed
            )
            return True

        raise RuntimeError(
            "Unexpected Satellite "
            f"response: {result}"
        )

    except Exception as exc:
        if (
            last_satellite_success
            == 0.0
            or (
                time.monotonic()
                - last_satellite_success
                > 2.0
            )
        ):
            set_state(
                satellite_online=False,
                satellite_connection_error=
                    str(exc),
            )
        else:
            set_state(
                satellite_connection_error=
                    str(exc)
            )

        return False


def sync_satellite_ip_to_rover():
    """
    Tell the Rover where the Satellite is.

    This creates the direct Rover -> Satellite telemetry path.
    Failure here never blocks Rover control.
    """
    with state_lock:
        satellite_ip = state.get(
            "satellite_ip",
            "",
        )
        rover_online = bool(
            state.get(
                "rover_online",
                False,
            )
        )

    if (
        not satellite_ip
        or not rover_online
    ):
        return False

    try:
        result, _ = rover_http(
            "POST",
            "/satellite-ip",
            {
                "satellite_ip":
                    satellite_ip,
            },
            timeout=0.45,
        )

        return bool(
            result.get("ok")
        )

    except Exception as exc:
        logger.warning(
            "Could not push Satellite IP "
            f"to Rover: {exc}"
        )
        return False



def mark_rover_success(ping_ms=None):
    global last_rover_success
    last_rover_success = time.monotonic()
    kwargs = {
        "rover_online": True,
        "connection_error": "",
    }
    if ping_ms is not None:
        kwargs["ping_ms"] = ping_ms
    set_state(**kwargs)


def ping_rover():
    try:
        result, elapsed = rover_http("GET", "/ping")
        if result.get("ok") and result.get("node") == "rover":
            mark_rover_success(elapsed)
            return True
        raise RuntimeError(f"Unexpected Rover response: {result}")
    except Exception as exc:
        if (
            last_rover_success == 0.0
            or time.monotonic() - last_rover_success > 2.5
        ):
            set_state(
                rover_online=False,
                connection_error=str(exc),
            )
        else:
            set_state(connection_error=str(exc))
        return False


def fetch_telemetry():
    try:
        result, _ = rover_http("GET", "/telemetry")
        if not result.get("ok"):
            raise RuntimeError(result.get("error", "Telemetry API returned error"))

        global last_safety_stop_for_audio
        global telemetry_announced

        mark_rover_success()
        current_safety_stop = bool(result.get("safety_stop", False))
        set_state(
            temperature_c=result.get("temperature_c"),
            humidity_percent=result.get("humidity_percent"),
            pressure_hpa=result.get("pressure_hpa"),
            distance_cm=result.get("distance_cm"),
            air_quality_raw=result.get("air_quality_raw"),
            rover_motion=result.get("motion", "STOP"),
            rover_motor_speed=result.get("motor_speed", 0),
            dht_ok=bool(result.get("dht_ok", False)),
            bmp_ok=bool(result.get("bmp_ok", False)),
            ultrasonic_ok=bool(result.get("ultrasonic_ok", False)),
            obstacle_blocked=bool(result.get("obstacle_blocked", False)),
            safety_stop=current_safety_stop,
        )

        if not telemetry_announced:
            telemetry_announced = True
            queue_announcement(
                "telemetry.wav",
                "Telemetry active.",
                priority=12,
                key="telemetry-active",
                cooldown=60,
            )

        if current_safety_stop and not last_safety_stop_for_audio:
            queue_announcement(
                "obstacle.wav",
                "Object detected.",
                priority=1,
                key="obstacle-stop",
                cooldown=1.5,
                interrupt=True,
            )

        last_safety_stop_for_audio = current_safety_stop
        return True
    except Exception as exc:
        if time.monotonic() - last_rover_success > 2.5:
            set_state(rover_online=False, connection_error=str(exc))
        return False

def send_satellite_command_snapshot(
    command,
    speed,
    source,
    sequence,
):
    """
    Mirror a Base command to the Satellite.

    This is DISPLAY-ONLY. It is intentionally independent from the
    real Base -> Rover control request.
    """
    payload = {
        "command":
            str(command),
        "speed":
            0
            if command == "STOP"
            else int(speed),
        "source":
            str(source),
        "sequence":
            int(sequence),
        "emergency":
            str(source).upper()
            == "EMERGENCY",
    }

    try:
        result, _ = satellite_http(
            "POST",
            "/base-command",
            payload,
            timeout=0.45,
        )

        if result.get("ok"):
            mark_satellite_success()

            with state_lock:
                state[
                    "satellite_tx_counter"
                ] += 1

                state[
                    "satellite_last_command"
                ] = command

                state[
                    "satellite_last_sequence"
                ] = sequence

            return True

    except Exception as exc:
        if (
            last_satellite_success
            == 0.0
            or (
                time.monotonic()
                - last_satellite_success
                > 2.0
            )
        ):
            set_state(
                satellite_online=False,
                satellite_connection_error=
                    str(exc),
            )

    return False


def satellite_command_worker():
    global last_satellite_send_time

    while True:
        wait_time = max(
            0.0,
            SATELLITE_REFRESH_S
            - (
                time.monotonic()
                - last_satellite_send_time
            ),
        )

        satellite_command_event.wait(
            timeout=wait_time
        )

        satellite_command_event.clear()

        with state_lock:
            online = bool(
                state.get(
                    "satellite_online",
                    False,
                )
            )

        if not online:
            time.sleep(
                0.04
            )
            continue

        with command_lock:
            command = active_command
            speed = active_speed
            source = active_source
            sequence = command_sequence

        send_satellite_command_snapshot(
            command,
            speed,
            source,
            sequence,
        )

        last_satellite_send_time = (
            time.monotonic()
        )


def satellite_monitor_worker():
    global last_satellite_ping_time
    global first_satellite_link_announced

    last_sync_ip = ""

    while True:
        now = time.monotonic()

        if (
            now
            - last_satellite_ping_time
            >= SATELLITE_PING_PERIOD_S
        ):
            last_satellite_ping_time = (
                now
            )

            with state_lock:
                satellite_ip = state.get(
                    "satellite_ip",
                    "",
                )

            if satellite_ip:
                online = ping_satellite()

                if (
                    online
                    and not first_satellite_link_announced
                ):
                    first_satellite_link_announced = True

                    queue_announcement(
                        "satellite_link.wav",
                        "Satellite connected.",
                        priority=6,
                        key="satellite-link-first",
                        cooldown=60,
                    )

                if (
                    online
                    and satellite_ip
                    != last_sync_ip
                ):
                    if sync_satellite_ip_to_rover():
                        last_sync_ip = (
                            satellite_ip
                        )

                if online:
                    satellite_command_event.set()
            else:
                set_state(
                    satellite_online=False
                )

        time.sleep(
            0.08
        )




def get_satellite_status():
    try:
        result, _ = satellite_http(
            "GET",
            "/status",
            timeout=0.45,
        )

        if result.get("ok"):
            mark_satellite_success()
            return result

    except Exception as exc:
        set_state(
            satellite_connection_error=str(exc)
        )

    return None


def wait_for_satellite_transmit_ready(
    command,
    sequence,
):
    """
    Realistic demo gate:
    Satellite receives the movement command first and must physically
    reach approximately 90 degrees before Rover movement begins.

    STOP and Emergency STOP never wait for this gate.
    """
    global relay_ready_sequence

    deadline = (
        time.monotonic()
        + SATELLITE_READY_TIMEOUT_S
    )

    set_state(
        relay_waiting=True,
        relay_status="SATELLITE ROTATING",
        ack_ok=False,
        ack_status="waiting satellite",
    )

    while time.monotonic() < deadline:
        # If a newer command/STOP was issued, cancel this old launch.
        with command_lock:
            if (
                sequence != command_sequence
                or active_command != command
            ):
                set_state(
                    relay_waiting=False,
                    relay_status="CANCELLED",
                )
                return False

        status = get_satellite_status()

        if status is not None:
            try:
                sat_sequence = int(
                    status.get(
                        "last_base_sequence",
                        -1,
                    )
                )
            except Exception:
                sat_sequence = -1

            try:
                servo_angle = int(
                    status.get(
                        "servo_angle",
                        0,
                    )
                )
            except Exception:
                servo_angle = 0

            if (
                sat_sequence >= sequence
                and servo_angle
                >= SATELLITE_READY_ANGLE
            ):
                with command_lock:
                    # Check again immediately before releasing the Rover.
                    if (
                        sequence != command_sequence
                        or active_command != command
                    ):
                        set_state(
                            relay_waiting=False,
                            relay_status="CANCELLED",
                        )
                        return False

                    relay_ready_sequence = sequence

                set_state(
                    relay_waiting=False,
                    relay_status="SATELLITE READY",
                    ack_status="satellite ready",
                )

                return True

        time.sleep(
            SATELLITE_READY_POLL_S
        )

    set_state(
        relay_waiting=False,
        relay_status="SATELLITE TIMEOUT",
        ack_ok=False,
        ack_status="satellite not ready",
    )

    add_history(
        "SAT",
        (
            f"Command #{sequence} blocked: "
            "Satellite did not reach transmit position"
        ),
    )

    return False


def dispatch_movement_after_satellite(
    command,
    speed,
    source,
    sequence,
):
    """
    FINAL DEMO FLOW:

        Base -> Satellite immediately
        wait exactly 3 seconds
        Base -> Rover directly

    Satellite NEVER forwards the command to Rover.

    A newer command or STOP cancels the old delayed movement before
    it reaches the Rover.
    """
    global relay_ready_sequence

    set_state(
        relay_waiting=True,
        relay_status="SATELLITE FIRST",
        ack_ok=False,
        ack_status="waiting 3 seconds",
    )

    # Send to Satellite immediately.
    satellite_ok = send_satellite_command_snapshot(
        command,
        speed,
        source,
        sequence,
    )

    if satellite_ok:
        satellite_command_event.set()

    # Fixed 3-second demo delay.
    deadline = (
        time.monotonic()
        + ROVER_START_DELAY_S
    )

    while time.monotonic() < deadline:
        with command_lock:
            # If STOP or a newer command arrives during the delay,
            # cancel this delayed Rover movement.
            if (
                sequence != command_sequence
                or active_command != command
            ):
                set_state(
                    relay_waiting=False,
                    relay_status="CANCELLED",
                    ack_status="command changed",
                )
                return False

        time.sleep(
            0.03
        )

    # Check one last time before physically moving the Rover.
    with command_lock:
        if (
            sequence != command_sequence
            or active_command != command
        ):
            set_state(
                relay_waiting=False,
                relay_status="CANCELLED",
                ack_status="command changed",
            )
            return False

        relay_ready_sequence = sequence

    # Rover receives the command DIRECTLY from Base.
    ok = send_control_snapshot(
        command,
        speed,
        source,
        sequence,
    )

    if ok:
        command_event.set()

        set_state(
            relay_waiting=False,
            relay_status="ROVER ACTIVE",
            ack_status="rover started after 3 seconds",
        )
    else:
        set_state(
            relay_waiting=False,
            relay_status="ROVER SEND FAILED",
            ack_status="rover send failed",
        )

    return ok




VALID_COMMANDS = {
    "STOP",
    "FORWARD",
    "BACKWARD",

    "LEFT",
    "RIGHT",

    "TURN_LEFT",
    "TURN_RIGHT",

    "FORWARD_LEFT",
    "FORWARD_RIGHT",

    "BACKWARD_LEFT",
    "BACKWARD_RIGHT",
}


def send_control_snapshot(command, speed, source, sequence):
    payload = {
        "command": command,
        "speed": 0 if command == "STOP" else speed,
        "source": source,
        "sequence": sequence,
    }

    try:
        result, _ = rover_http(
            "POST",
            "/control",
            payload,
        )

        with state_lock:
            state["tx_counter"] += 1

        if result.get("ok"):
            mark_rover_success()

            response_sequence = result.get(
                "sequence",
                sequence,
            )

            # An old request may finish after a newer command.
            # Do not let that old response overwrite the current UI ACK.
            with command_lock:
                latest_sequence = command_sequence

            if (
                response_sequence
                >= latest_sequence
            ):
                status = result.get(
                    "status",
                    "accepted",
                )

                acknowledged_command = result.get(
                    "command",
                    command,
                )

                set_state(
                    ack_ok=True,
                    ack_command=acknowledged_command,
                    ack_status=status,
                    ack_sequence=response_sequence,
                )

                with state_lock:
                    state["ack_counter"] += 1

                if status in ("accepted", "stopped"):
                    announce_command_ack(
                        acknowledged_command,
                        response_sequence,
                    )

            return True

        raise RuntimeError(
            result.get(
                "error",
                "Rover rejected command",
            )
        )

    except Exception as exc:
        set_state(
            ack_ok=False,
            ack_status="error",
            connection_error=str(exc),
        )

        if (
            time.monotonic()
            - last_rover_success
            > 2.5
        ):
            set_state(
                rover_online=False
            )

        return False


def send_emergency_stop_snapshot(sequence):
    """
    Dedicated STOP request.

    It can run immediately even if the regular control worker
    is waiting on an older HTTP request.

    Rover-side sequence protection prevents an old movement
    request from restarting the motors after this STOP.
    """
    payload = {
        "sequence": sequence,
    }

    try:
        result, _ = rover_http(
            "POST",
            "/stop",
            payload,
            timeout=0.9,
        )

        with state_lock:
            state["tx_counter"] += 1

        if result.get("ok"):
            mark_rover_success()

            set_state(
                ack_ok=True,
                ack_command="STOP",
                ack_status=result.get(
                    "status",
                    "stopped",
                ),
                ack_sequence=result.get(
                    "sequence",
                    sequence,
                ),
            )

            with state_lock:
                state["ack_counter"] += 1

            add_history(
                "ROVER",
                f"EMERGENCY STOP #{sequence}: stopped",
            )

            return True

    except Exception as exc:
        set_state(
            ack_ok=False,
            ack_status="error",
            connection_error=str(exc),
        )

    return False


def activate_command(
    command,
    source="MANUAL",
    speed=None,
):
    global active_command
    global active_speed
    global active_source
    global command_sequence
    global relay_ready_sequence

    command = str(
        command
    ).upper().strip()

    if command not in VALID_COMMANDS:
        command = "STOP"

    with command_lock:
        if speed is not None:
            try:
                active_speed = max(
                    0,
                    min(
                        255,
                        int(speed),
                    ),
                )
            except Exception:
                pass

        active_command = command
        active_source = str(
            source
        ).upper()

        command_sequence += 1

        seq = command_sequence
        current_speed = active_speed

        # Every new command must earn relay-ready status again.
        relay_ready_sequence = -1

    set_state(
        active_command=command,
        command_source=active_source,
        speed=current_speed,
        sequence=seq,
        ack_ok=False,
        relay_waiting=(
            command != "STOP"
        ),
        relay_status=(
            "WAITING SATELLITE"
            if command != "STOP"
            else "IDLE"
        ),
    )

    add_history(
        active_source,
        f"{command} @ "
        f"{0 if command == 'STOP' else current_speed}",
    )

    # --------------------------------------------------------
    # STOP is a safety command: send to Rover immediately.
    # Do not wait for the Satellite to return to zero.
    # --------------------------------------------------------
    if command == "STOP":
        threading.Thread(
            target=send_control_snapshot,
            args=(
                "STOP",
                0,
                active_source,
                seq,
            ),
            daemon=True,
        ).start()

        threading.Thread(
            target=send_satellite_command_snapshot,
            args=(
                "STOP",
                0,
                active_source,
                seq,
            ),
            daemon=True,
        ).start()

        command_event.set()
        satellite_command_event.set()

        return command

    # --------------------------------------------------------
    # MOVEMENT:
    # Satellite receives first -> fixed 3 second delay -> Rover moves.
    # --------------------------------------------------------
    threading.Thread(
        target=dispatch_movement_after_satellite,
        args=(
            command,
            current_speed,
            active_source,
            seq,
        ),
        daemon=True,
    ).start()

    return command


def emergency_stop():
    global active_command
    global active_source
    global command_sequence
    global relay_ready_sequence

    with command_lock:
        active_command = "STOP"
        active_source = "EMERGENCY"
        command_sequence += 1

        seq = command_sequence

        relay_ready_sequence = -1

    set_state(
        active_command="STOP",
        command_source="EMERGENCY",
        sequence=seq,
        ack_ok=False,
    )

    add_history(
        "EMERGENCY",
        "STOP requested",
    )

    queue_announcement(
        "emergency.wav",
        "Emergency stop.",
        priority=0,
        key=f"emergency:{seq}",
        interrupt=True,
    )

    # Normal Rover worker will also send STOP.
    command_event.set()

    # Mirror Emergency STOP immediately.
    threading.Thread(
        target=send_satellite_command_snapshot,
        args=(
            "STOP",
            0,
            "EMERGENCY",
            seq,
        ),
        daemon=True,
    ).start()

    satellite_command_event.set()

    # But emergency stop gets its own immediate Rover request.
    threading.Thread(
        target=send_emergency_stop_snapshot,
        args=(seq,),
        daemon=True,
    ).start()

    return seq


def update_speed(value):
    global active_speed

    try:
        value = max(
            0,
            min(
                255,
                int(value),
            ),
        )
    except Exception:
        value = 100

    with command_lock:
        active_speed = value

    set_state(
        speed=value
    )

    if active_command != "STOP":
        command_event.set()
        satellite_command_event.set()

    return value


def control_worker():
    """
    Only ONE normal movement request at a time.

    This removes the race where several FORWARD/LEFT/STOP HTTP
    requests could overlap and arrive out of order.
    """
    last_sent = 0.0

    while True:
        wait_time = max(
            0.0,
            CONTROL_REFRESH_S
            - (
                time.monotonic()
                - last_sent
            ),
        )

        command_event.wait(
            timeout=wait_time
        )

        command_event.clear()

        with state_lock:
            online = state[
                "rover_online"
            ]

        if not online:
            time.sleep(0.05)
            continue

        with command_lock:
            command = active_command
            speed = active_speed
            source = active_source
            sequence = command_sequence
            ready_sequence = relay_ready_sequence

        # STOP is always allowed immediately.
        # Movement heartbeat is allowed only after Satellite reached 90°.
        if (
            command != "STOP"
            and ready_sequence != sequence
        ):
            time.sleep(0.03)
            continue

        send_control_snapshot(
            command,
            speed,
            source,
            sequence,
        )

        last_sent = time.monotonic()


def monitor_worker():
    global last_ping_time
    global last_telemetry_time
    global first_rover_link_announced
    global last_link_online_for_audio

    initial_stop_done = False

    while True:
        now = time.monotonic()

        if now - last_ping_time >= PING_PERIOD_S:
            last_ping_time = now
            reachable = ping_rover()

            with state_lock:
                online_now = bool(state["rover_online"])

            if online_now and not first_rover_link_announced:
                first_rover_link_announced = True
                queue_announcement(
                    "rover_link.wav",
                    "Rover connected.",
                    priority=6,
                    key="rover-link-first",
                    cooldown=60,
                )

            elif online_now and not last_link_online_for_audio and first_rover_link_announced:
                queue_announcement(
                    "rover_restored.wav",
                    "Rover reconnected.",
                    priority=3,
                    key="rover-link-restored",
                    cooldown=2.0,
                )

            elif not online_now and last_link_online_for_audio:
                queue_announcement(
                    "rover_lost.wav",
                    "Rover link lost.",
                    priority=2,
                    key="rover-link-lost",
                    cooldown=2.0,
                    interrupt=True,
                )

            last_link_online_for_audio = online_now

            if reachable:
                # Keep Rover informed of the currently selected Satellite.
                sync_satellite_ip_to_rover()

            if reachable and not initial_stop_done:
                initial_stop_done = True
                activate_command(
                    "STOP",
                    source="SYSTEM",
                    speed=0,
                )

        if now - last_telemetry_time >= TELEMETRY_PERIOD_S:
            last_telemetry_time = now
            fetch_telemetry()

        time.sleep(0.06)


# ============================================================
# VOSK MODEL SETUP - SAME METHOD AS WORKING TEST
# ============================================================


def ensure_vosk_module():
    """
    requirements.txt should install vosk==0.3.45.

    Some App Lab builds do not install the Python requirements reliably
    during import/startup, so use the known working exact version as a
    fallback. This is the same recovery strategy used in the earlier
    VOSK_FIXED Base package.
    """
    try:
        return importlib.import_module(
            "vosk"
        )

    except ModuleNotFoundError:
        set_state(
            model_status="INSTALLING VOSK",
            model_progress=0,
            voice_error="",
        )

        add_history(
            "VOICE",
            "Installing Vosk 0.3.45",
        )

        try:
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    "--user",
                    "vosk==0.3.45",
                ],
                check=True,
                timeout=180,
            )

            importlib.invalidate_caches()

            return importlib.import_module(
                "vosk"
            )

        except Exception as exc:
            raise RuntimeError(
                "Vosk module is missing. "
                "python/requirements.txt is present, "
                "and the automatic vosk==0.3.45 fallback also failed: "
                f"{exc}"
            )


def model_locations():
    """
    Keep the same working Vosk setup, but stop searching old Arduino App
    folders. A stale/corrupt model from an older App is the main cause of
    Vosk's 'Failed to create a model' error.

    Search order:
      1. Current Base App /models/
      2. New clean persistent cache
      3. New clean /tmp fallback
    """
    app_root = Path(
        __file__
    ).resolve().parents[1]

    yield (
        app_root
        / "models"
        / MODEL_NAME
    )

    yield (
        Path(
            "/home/arduino/.cache/lunar_vosk_models_clean_v3"
        )
        / MODEL_NAME
    )

    yield (
        Path(
            "/tmp/lunar_vosk_models_clean_v3"
        )
        / MODEL_NAME
    )


def model_folder_has_core_files(
    path
):
    """
    am/ and conf/ alone are not enough. A partially extracted folder can
    contain those directories and still make vosk.Model() fail.
    """
    try:
        path = Path(path)

        required = [
            path / "am" / "final.mdl",
            path / "conf" / "model.conf",
            path / "conf" / "mfcc.conf",
            path / "graph",
        ]

        return all(
            item.exists()
            for item in required
        )

    except Exception:
        return False


def find_existing_model():
    for path in model_locations():
        if model_folder_has_core_files(
            path
        ):
            return path

    return None


def choose_writable_parent():
    for model_path in model_locations():
        parent = model_path.parent

        try:
            parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            probe = (
                parent
                / ".write_test"
            )

            probe.write_text(
                "ok",
                encoding="utf-8",
            )

            probe.unlink(
                missing_ok=True
            )

            return parent

        except Exception:
            pass

    raise RuntimeError(
        "No writable Vosk model directory is available."
    )


def remove_bad_model(
    path
):
    if path is None:
        return

    try:
        path = Path(path)

        if path.exists():
            shutil.rmtree(
                path,
                ignore_errors=True,
            )

        add_history(
            "VOICE",
            (
                "Removed unusable Vosk model: "
                f"{path}"
            ),
        )

    except Exception:
        pass


def download_model(
    force_fresh=False
):
    """
    Same model and same official download used by the working Base.

    force_fresh=True is used only after vosk.Model() rejects an existing
    folder. The bad folder is removed first, then the model is downloaded
    again into a clean destination.
    """
    if not force_fresh:
        existing = find_existing_model()

        if existing:
            return existing

    parent = choose_writable_parent()

    destination = (
        parent
        / MODEL_NAME
    )

    archive_path = (
        parent
        / f"{MODEL_NAME}.zip"
    )

    # Never extract on top of an old model.
    if destination.exists():
        shutil.rmtree(
            destination,
            ignore_errors=True,
        )

    archive_path.unlink(
        missing_ok=True
    )

    set_state(
        model_status="DOWNLOADING",
        model_progress=0,
        model_path=str(destination),
        voice_error="",
    )

    add_history(
        "VOICE",
        (
            "Downloading clean offline Vosk model"
            if force_fresh
            else "Downloading offline Vosk model"
        ),
    )

    request = urllib.request.Request(
        MODEL_URL,
        headers={
            "User-Agent":
                "UNO-Q-Lunar-Base-Vosk/3.0"
        },
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=60,
        ) as response:

            total = int(
                response.headers.get(
                    "Content-Length",
                    "0",
                )
                or 0
            )

            downloaded = 0

            with archive_path.open(
                "wb"
            ) as output:

                while True:
                    chunk = response.read(
                        256 * 1024
                    )

                    if not chunk:
                        break

                    output.write(
                        chunk
                    )

                    downloaded += len(
                        chunk
                    )

                    if total:
                        set_state(
                            model_progress=max(
                                0,
                                min(
                                    100,
                                    int(
                                        downloaded
                                        * 100
                                        / total
                                    ),
                                ),
                            )
                        )

        set_state(
            model_status="EXTRACTING",
            model_progress=100,
        )

        with zipfile.ZipFile(
            archive_path,
            "r",
        ) as archive:
            archive.extractall(
                parent
            )

        if not model_folder_has_core_files(
            destination
        ):
            raise RuntimeError(
                "Fresh Vosk model extraction is incomplete."
            )

        return destination

    finally:
        archive_path.unlink(
            missing_ok=True
        )


def prepare_model():
    global vosk_model

    with model_lock:
        if vosk_model is not None:
            return vosk_model

        try:
            set_state(
                model_status="CHECKING",
                model_progress=0,
                voice_error="",
            )

            # Keep the same working Vosk package setup.
            vosk = ensure_vosk_module()

            model_path = download_model(
                force_fresh=False
            )

            set_state(
                model_status="LOADING",
                model_progress=100,
                model_path=str(model_path),
                voice_error="",
            )

            vosk.SetLogLevel(-1)

            try:
                # First attempt: existing/local model.
                vosk_model = vosk.Model(
                    str(model_path)
                )

            except Exception as first_exc:
                # This is the important recovery for:
                # "Failed to create a model"
                logger.warning(
                    (
                        "Existing Vosk model failed to load. "
                        "Deleting it and downloading a clean copy. "
                        f"Error: {first_exc}"
                    )
                )

                set_state(
                    model_status="RESETTING BAD MODEL",
                    model_progress=0,
                    voice_error="",
                )

                remove_bad_model(
                    model_path
                )

                fresh_path = download_model(
                    force_fresh=True
                )

                set_state(
                    model_status="LOADING FRESH MODEL",
                    model_progress=100,
                    model_path=str(fresh_path),
                    voice_error="",
                )

                # Second attempt uses ONLY the newly downloaded folder.
                vosk_model = vosk.Model(
                    str(fresh_path)
                )

                model_path = fresh_path

            set_state(
                model_status="READY",
                model_progress=100,
                model_path=str(model_path),
                voice_error="",
            )

            add_history(
                "VOICE",
                "Offline Vosk model ready",
            )

            return vosk_model

        except Exception as exc:
            message = (
                "Vosk model error: "
                f"{exc}"
            )

            set_state(
                model_status="ERROR",
                voice_error=message,
            )

            add_history(
                "VOICE",
                message,
            )

            logger.error(
                message
            )

            return None



def boost_quiet_audio(chunk):
    if chunk is None or len(chunk) == 0:
        return chunk, 0, 0, 1.0, 0

    audio = np.asarray(chunk).astype(np.int16, copy=False)
    floating = audio.astype(np.float32)

    rms = float(np.sqrt(np.mean(floating * floating))) if len(floating) else 0.0
    peak = int(np.max(np.abs(floating))) if len(floating) else 0

    if rms < 1.0:
        gain = 1.0
    else:
        gain = min(MAX_GAIN, max(1.0, TARGET_RMS / rms))

    boosted = np.clip(floating * gain, -32768, 32767).astype(np.int16)
    level_percent = min(100, int((peak / 8000.0) * 100))

    return boosted, int(rms), peak, round(gain, 1), level_percent


def text_to_command(text):
    cleaned = re.sub(
        r"[^a-zA-Z ]+",
        " ",
        str(text).lower(),
    )

    cleaned = re.sub(
        r"\s+",
        " ",
        cleaned,
    ).strip()

    # STOP always wins.
    if any(
        x in cleaned
        for x in (
            "emergency stop",
            "stop",
            "halt",
        )
    ):
        return "STOP"

    if any(
        x in cleaned
        for x in (
            "go forward",
            "move forward",
            "forward",
            "go straight",
            "straight",
        )
    ):
        return "FORWARD"

    if any(
        x in cleaned
        for x in (
            "go backward",
            "move backward",
            "backward",
            "go back",
            "reverse",
        )
    ):
        return "BACKWARD"

    # IMPORTANT:
    # Multi-word TURN phrases are checked BEFORE bare LEFT/RIGHT.
    # "turn left" = forward curve.
    if any(
        x in cleaned
        for x in (
            "turn to the left",
            "turn left",
            "left turn",
            "curve left",
            "turn lift",
        )
    ):
        return "TURN_LEFT"

    if any(
        x in cleaned
        for x in (
            "turn to the right",
            "turn right",
            "right turn",
            "curve right",
            "turn write",
        )
    ):
        return "TURN_RIGHT"

    # Bare LEFT = rotate left on the spot.
    if any(
        x in cleaned
        for x in (
            "move left",
            "go left",
            "left",
            "lift",
        )
    ):
        return "LEFT"

    # Bare RIGHT = rotate right on the spot.
    if any(
        x in cleaned
        for x in (
            "move right",
            "go right",
            "right",
            "write",
        )
    ):
        return "RIGHT"

    if any(
        x in cleaned
        for x in (
            "rover status",
            "status",
        )
    ):
        return "STATUS"

    return None


def process_voice_command(text):
    global last_voice_command, last_voice_command_time

    command = text_to_command(text)
    if command is None:
        return

    now = time.monotonic()
    if command == last_voice_command and now - last_voice_command_time < VOICE_DUPLICATE_DEBOUNCE_S:
        return

    last_voice_command = command
    last_voice_command_time = now
    set_state(last_voice_command=command)

    if command == "STATUS":
        with state_lock:
            online = state["rover_online"]
            motion = state["rover_motion"]
            distance = state["distance_cm"]
        add_history(
            "VOICE",
            f"STATUS: Rover={'ONLINE' if online else 'OFFLINE'}, motion={motion}, distance={distance}",
        )
        return

    with state_lock:
        speed = state["speed"]
    activate_command(command, "VOICE", speed)


def voice_worker():
    global microphone

    model = prepare_model()
    if model is None:
        return

    set_state(
        voice_listening=True,
        voice_error="",
        partial_transcription="",
        mic_connected=False,
    )

    try:
        vosk = ensure_vosk_module()

        recognizer = vosk.KaldiRecognizer(
            model,
            SAMPLE_RATE,
            json.dumps(VOSK_GRAMMAR),
        )

        # Same constructor/settings as the working test.
        microphone = Microphone(
            device=MIC_DEVICE,
            sample_rate=SAMPLE_RATE,
            channels=CHANNELS,
            buffer_size=BUFFER_SIZE,
            shared=True,
        )

        try:
            microphone.volume = 100
        except Exception:
            pass

        microphone.start()

        set_state(
            mic_connected=True,
            mic_name=getattr(microphone, "name", "USB Microphone"),
            mic_device=str(getattr(microphone, "device_stable_ref", MIC_DEVICE)),
        )
        add_history("MIC", f"Connected: {getattr(microphone, 'name', 'USB Microphone')}")

        partial_candidate = None
        partial_candidate_count = 0

        for chunk in microphone.stream():
            if voice_stop_event.is_set():
                break

            if (
                speaker_talking.is_set()
                or time.monotonic() < voice_guard_until
            ):
                set_state(
                    mic_level_percent=0,
                    partial_transcription="",
                )
                continue

            if reset_recognizer_event.is_set():
                try:
                    recognizer.Reset()
                except Exception:
                    pass
                reset_recognizer_event.clear()
                partial_candidate = None
                partial_candidate_count = 0
                set_state(partial_transcription="")

            boosted, rms, peak, gain, level = boost_quiet_audio(chunk)
            set_state(
                mic_level_percent=level,
                mic_rms=rms,
                mic_peak=peak,
                auto_gain=gain,
            )

            audio_bytes = boosted.tobytes()

            if recognizer.AcceptWaveform(audio_bytes):
                result = json.loads(recognizer.Result() or "{}")
                text = str(result.get("text", "") or "").strip()
                if text:
                    set_state(last_transcription=text, partial_transcription="")
                    add_history("MIC", f'Heard: "{text}"')
                    process_voice_command(text)
            else:
                partial = json.loads(recognizer.PartialResult() or "{}")
                partial_text = str(partial.get("partial", "") or "").strip()
                set_state(partial_transcription=partial_text)

                partial_command = text_to_command(
                    partial_text
                )

                # STOP remains immediate.
                if partial_command == "STOP":
                    set_state(
                        last_transcription=partial_text
                    )

                    process_voice_command(
                        partial_text
                    )

                    partial_candidate = None
                    partial_candidate_count = 0

                # "turn left" / "turn right" are multi-word and unambiguous:
                # execute as soon as the phrase appears in Vosk partial text.
                elif partial_command in (
                    "TURN_LEFT",
                    "TURN_RIGHT",
                ):
                    set_state(
                        last_transcription=partial_text
                    )

                    process_voice_command(
                        partial_text
                    )

                    partial_candidate = None
                    partial_candidate_count = 0

                # Short movement words are accepted after two matching
                # partials, reducing latency without reacting to one noisy hit.
                elif partial_command in (
                    "FORWARD",
                    "BACKWARD",
                    "LEFT",
                    "RIGHT",
                ):
                    if (
                        partial_candidate
                        == partial_command
                    ):
                        partial_candidate_count += 1
                    else:
                        partial_candidate = partial_command
                        partial_candidate_count = 1

                    if (
                        partial_candidate_count
                        >= 2
                    ):
                        set_state(
                            last_transcription=partial_text
                        )

                        process_voice_command(
                            partial_text
                        )

                        partial_candidate = None
                        partial_candidate_count = 0

                else:
                    partial_candidate = None
                    partial_candidate_count = 0

    except Exception as exc:
        message = f"Microphone/voice recognition error: {exc}"
        set_state(voice_error=message, mic_connected=False)
        add_history("VOICE", message)
        logger.error(message)

    finally:
        try:
            if microphone is not None:
                microphone.stop()
        except Exception:
            pass

        microphone = None
        set_state(
            voice_listening=False,
            mic_connected=False,
            mic_level_percent=0,
            partial_transcription="",
            auto_gain=1.0,
        )
        voice_stop_event.clear()


def start_voice():
    global voice_thread

    with state_lock:
        if state["voice_listening"]:
            return {"ok": True, "listening": True}

    if prepare_model() is None:
        with state_lock:
            error = state["voice_error"]
        return {"ok": False, "listening": False, "error": error}

    voice_stop_event.clear()
    voice_thread = threading.Thread(target=voice_worker, daemon=True)
    voice_thread.start()

    queue_announcement(
        "voice_active.wav",
        "Voice control active.",
        priority=11,
        key="voice-active",
        cooldown=1.0,
    )

    return {"ok": True, "listening": True}


def stop_voice():
    voice_stop_event.set()
    try:
        if microphone is not None:
            microphone.stop()
    except Exception:
        pass
    return {"ok": True, "listening": False}


# ============================================================
# BASE WEBUI API
# ============================================================


def state_api():
    with state_lock:
        result = dict(state)
        result["history"] = [dict(x) for x in state["history"]]

    if last_rover_success:
        result["rover_age_ms"] = int((time.monotonic() - last_rover_success) * 1000)
    else:
        result["rover_age_ms"] = None

    if last_satellite_success:
        result["satellite_age_ms"] = int(
            (
                time.monotonic()
                - last_satellite_success
            )
            * 1000
        )
    else:
        result["satellite_age_ms"] = None

    return result


async def rover_ip_api(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}

    value = str(body.get("rover_ip", "")).strip()
    if not set_rover_ip(value, save=True):
        return {"ok": False, "error": "Invalid IPv4 address"}

    ok = ping_rover()
    return {
        "ok": ok,
        "rover_ip": value,
        "error": "" if ok else state.get("connection_error", "Unable to reach Rover"),
    }

async def satellite_ip_api(
    request: Request
):
    try:
        body = await request.json()
    except Exception:
        body = {}

    value = str(
        body.get(
            "satellite_ip",
            "",
        )
    ).strip()

    if not set_satellite_ip(
        value,
        save=True,
    ):
        return {
            "ok": False,
            "error":
                "Invalid IPv4 address",
        }

    if value == "":
        # Also clear Rover's direct Satellite destination.
        try:
            rover_http(
                "POST",
                "/satellite-ip",
                {
                    "satellite_ip": "",
                },
                timeout=0.35,
            )
        except Exception:
            pass

        return {
            "ok": True,
            "satellite_ip": "",
        }

    ok = ping_satellite()

    if ok:
        sync_satellite_ip_to_rover()
        satellite_command_event.set()

    with state_lock:
        error = state.get(
            "satellite_connection_error",
            "",
        )

    return {
        "ok": ok,
        "satellite_ip": value,
        "error":
            ""
            if ok
            else (
                error
                or
                "Unable to reach Satellite"
            ),
    }




async def command_api(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}

    command = activate_command(
        body.get("command", "STOP"),
        source="MANUAL",
        speed=body.get("speed"),
    )
    return {"ok": True, "command": command}


async def speed_api(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}
    return {"ok": True, "speed": update_speed(body.get("speed", 100))}


def emergency_stop_api():
    seq = emergency_stop()
    return {
        "ok": True,
        "command": "STOP",
        "sequence": seq,
    }


def voice_start_api():
    return start_voice()


def voice_stop_api():
    return stop_voice()


def model_retry_api():
    set_state(model_status="CHECKING", model_progress=0, voice_error="")
    threading.Thread(target=prepare_model, daemon=True).start()
    return {"ok": True}


def audio_test_api():
    queued = queue_announcement(
        "audio_test.wav",
        "Speaker ready",
        priority=2,
        key="audio-test",
        cooldown=0.25,
        interrupt=True,
    )

    return {
        "ok": queued,
    }


async def audio_enabled_api(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}

    enabled = bool(body.get("enabled", True))
    set_state(audio_enabled=enabled)

    if not enabled:
        stop_audio_process()
        _next_speech_generation()
        speaker_talking.clear()

        set_state(
            speaker_talking=False,
            speaker_status="READY",
        )

    return {
        "ok": True,
        "audio_enabled": enabled,
    }


ui.expose_api("GET", "/state", state_api)
ui.expose_api("POST", "/rover-ip", rover_ip_api)
ui.expose_api("POST", "/satellite-ip", satellite_ip_api)
ui.expose_api("POST", "/command", command_api)
ui.expose_api("POST", "/speed", speed_api)
ui.expose_api("POST", "/emergency-stop", emergency_stop_api)
ui.expose_api("POST", "/voice/start", voice_start_api)
ui.expose_api("POST", "/voice/stop", voice_stop_api)
ui.expose_api("POST", "/model/retry", model_retry_api)
ui.expose_api("POST", "/audio/test", audio_test_api)
ui.expose_api("POST", "/audio/enabled", audio_enabled_api)


# Start network and voice-model preparation before App.run().
threading.Thread(target=bluetooth_speaker_probe_worker, daemon=True).start()
threading.Thread(target=control_worker, daemon=True).start()
threading.Thread(target=satellite_command_worker, daemon=True).start()
threading.Thread(target=satellite_monitor_worker, daemon=True).start()
threading.Thread(target=monitor_worker, daemon=True).start()
threading.Thread(target=prepare_model, daemon=True).start()

App.run()
