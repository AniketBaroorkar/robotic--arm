#include <Arduino.h>

// Base Station MCU sketch.
//
// Bluetooth audio and Vosk run on the UNO Q Linux side.
// No D10 speaker hardware is required.

void setup() {
}

void loop() {
  delay(100);
}
