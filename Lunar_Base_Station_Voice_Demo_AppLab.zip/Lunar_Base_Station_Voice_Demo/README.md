# Lunar Base Station Voice Demo

This is a safe Arduino App Lab Base Station demo. It does **not** transmit commands to the real rover yet.

## Required bricks

- `arduino:web_ui`
- `arduino:asr`

The current Arduino ASR brick uses the default USB microphone automatically.

## What this demo tests

- USB microphone + local ASR
- Voice commands: FORWARD, BACKWARD, LEFT, RIGHT, STOP, STATUS
- Manual touchscreen/mouse controls
- Keyboard controls
- Lunar mission-control HTML page
- Dummy rover telemetry that changes live
- Simulated command-sent and rover-ACK indicators
- Command/transcription history

## Hardware

- Arduino UNO Q / compatible Q App Lab board
- USB microphone
- Powered USB-C hub/dongle if required for the USB microphone
- Display connected to the Base Station, or another browser on the same network

## How to test

1. Connect the USB microphone to the Base Station Q.
2. Open/copy this project into Arduino App Lab.
3. Run the app.
4. Open the WebUI URL shown by App Lab, normally `http://<BOARD-IP>:7000`.
5. Confirm the dummy telemetry values are changing.
6. Test the on-screen arrows and STOP button.
7. Watch the yellow COMMAND LINK indicator and green ROVER ACK indicator.
8. Click **START VOICE CONTROL**.
9. Say one command clearly: `forward`, `backward`, `left`, `right`, `stop`, or `status`.
10. Check LAST TRANSCRIPTION, LAST COMMAND, and the mission log.

## Keyboard controls

- W / Up Arrow = Forward
- S / Down Arrow = Backward
- A / Left Arrow = Left
- D / Right Arrow = Right
- Space = Stop

## Important

This is deliberately simulation-only. Once this passes the microphone/UI test, the real project will replace the simulated `set_command()` path with Base → Rover UDP transmission and actual Rover acknowledgement packets.
