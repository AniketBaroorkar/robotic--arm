const $ = (id) => document.getElementById(id);
const speed = $('speed');
const speedValue = $('speed-value');
const micButton = $('mic-button');

let listening = false;
let lastTxCounter = -1;
let lastAckCounter = -1;
let txTimer = null;
let ackTimer = null;
let heldKeyCommand = null;

function formatNumber(v, digits = 1) {
  if (v === null || v === undefined) return '--';
  const n = Number(v);
  return Number.isFinite(n) ? n.toFixed(digits) : '--';
}

async function api(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', ...options });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
  return response.json();
}

async function sendCommand(command) {
  try {
    await api('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command, speed: Number(speed.value) }),
    });
  } catch (error) {
    console.error('Command error:', error);
  }
}

speed.addEventListener('input', () => { speedValue.textContent = speed.value; });

document.querySelectorAll('.drive').forEach((button) => {
  const command = button.dataset.command;
  button.addEventListener('pointerdown', (event) => {
    event.preventDefault();
    document.querySelectorAll('.drive').forEach((b) => b.classList.remove('active'));
    button.classList.add('active');
    sendCommand(command);
  });

  if (command !== 'STOP') {
    const stop = (event) => {
      if (event) event.preventDefault();
      button.classList.remove('active');
      sendCommand('STOP');
    };
    button.addEventListener('pointerup', stop);
    button.addEventListener('pointercancel', stop);
    button.addEventListener('lostpointercapture', stop);
  }
});

const keyMap = {
  ArrowUp: 'FORWARD', w: 'FORWARD', W: 'FORWARD',
  ArrowDown: 'BACKWARD', s: 'BACKWARD', S: 'BACKWARD',
  ArrowLeft: 'LEFT', a: 'LEFT', A: 'LEFT',
  ArrowRight: 'RIGHT', d: 'RIGHT', D: 'RIGHT',
};

document.addEventListener('keydown', (event) => {
  if (event.code === 'Space') {
    event.preventDefault();
    sendCommand('STOP');
    return;
  }
  const command = keyMap[event.key];
  if (!command || event.repeat) return;
  event.preventDefault();
  heldKeyCommand = command;
  sendCommand(command);
});

document.addEventListener('keyup', (event) => {
  const command = keyMap[event.key];
  if (!command) return;
  event.preventDefault();
  if (heldKeyCommand === command) {
    heldKeyCommand = null;
    sendCommand('STOP');
  }
});

window.addEventListener('blur', () => {
  if (heldKeyCommand) {
    heldKeyCommand = null;
    sendCommand('STOP');
  }
});

micButton.addEventListener('click', async () => {
  micButton.disabled = true;
  try {
    if (!listening) await api('/api/voice/start', { method: 'POST' });
    else await api('/api/voice/stop', { method: 'POST' });
  } catch (error) {
    $('voice-error').textContent = `Voice API error: ${error.message}`;
    $('voice-error').classList.remove('hidden');
  } finally {
    micButton.disabled = false;
  }
});

function flash(id, duration = 500) {
  const el = $(id);
  el.classList.add('active');
  setTimeout(() => el.classList.remove('active'), duration);
}

function renderHistory(items) {
  $('history').innerHTML = '';
  (items || []).slice(0, 8).forEach((item) => {
    const row = document.createElement('div');
    row.className = 'history-item';

    const t = document.createElement('span');
    t.className = 'history-time';
    t.textContent = item.time || '--:--:--';

    const s = document.createElement('span');
    s.className = 'history-source';
    s.textContent = item.source || '---';

    const text = document.createElement('span');
    text.textContent = item.text || '';

    row.append(t, s, text);
    $('history').appendChild(row);
  });
}

async function refresh() {
  try {
    const s = await api('/api/state');
    $('temp').textContent = formatNumber(s.temperature_c);
    $('humidity').textContent = formatNumber(s.humidity_percent);
    $('pressure').textContent = formatNumber(s.pressure_hpa);
    $('distance').textContent = formatNumber(s.distance_cm);
    $('air').textContent = s.air_quality_raw ?? '--';
    $('motion-badge').textContent = s.motion || 'STOP';
    $('last-command').textContent = s.last_command || 'STOP';
    $('last-source').textContent = s.command_source || '---';
    $('transcription').textContent = s.last_transcription || 'Say “forward”, “backward”, “left”, “right”, “stop”, or “status”.';
    $('partial').textContent = s.partial_transcription || '';

    listening = !!s.voice_listening;
    $('mic-state').textContent = listening ? 'LISTENING' : 'MIC OFF';
    $('mic-button-text').textContent = listening ? 'STOP VOICE CONTROL' : 'START VOICE CONTROL';
    micButton.classList.toggle('listening', listening);

    if (s.voice_error) {
      $('voice-error').textContent = s.voice_error;
      $('voice-error').classList.remove('hidden');
    } else {
      $('voice-error').classList.add('hidden');
    }

    $('rover-status').classList.toggle('online', !!s.rover_online);
    $('satellite-status').classList.toggle('online', !!s.satellite_online);

    if (lastTxCounter >= 0 && s.tx_counter !== lastTxCounter) {
      $('tx-text').textContent = `SENT #${s.tx_counter}`;
      flash('tx-light', 600);
      clearTimeout(txTimer);
      txTimer = setTimeout(() => $('tx-text').textContent = 'READY', 900);
    }
    lastTxCounter = s.tx_counter;

    if (lastAckCounter >= 0 && s.ack_counter !== lastAckCounter) {
      $('ack-text').textContent = `ACK #${s.ack_counter}`;
      flash('ack-light', 700);
      clearTimeout(ackTimer);
      ackTimer = setTimeout(() => $('ack-text').textContent = 'STANDBY', 1000);
    }
    lastAckCounter = s.ack_counter;

    renderHistory(s.history);
  } catch (error) {
    $('rover-status').classList.remove('online');
    console.error('State refresh error:', error);
  }
}

setInterval(refresh, 300);
refresh();
