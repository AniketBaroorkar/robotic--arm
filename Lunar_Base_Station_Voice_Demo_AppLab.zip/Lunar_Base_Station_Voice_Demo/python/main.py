from arduino.app_bricks.asr import AutomaticSpeechRecognition
from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Logger

from fastapi import Request
import threading
import time
import random
import re
import math

logger = Logger("LunarBaseDemo")

# Required App Lab bricks.
# AutomaticSpeechRecognition() uses the default USB microphone internally.
asr = AutomaticSpeechRecognition(language="en")
ui = WebUI()

VALID_COMMANDS = {"FORWARD", "BACKWARD", "LEFT", "RIGHT", "STOP", "STATUS"}

lock = threading.Lock()
voice_thread = None
voice_stop_requested = False

state = {
    "simulation": True,
    "rover_online": True,
    "satellite_online": True,
    "temperature_c": 24.8,
    "humidity_percent": 42.0,
    "pressure_hpa": 1008.2,
    "distance_cm": 118.0,
    "air_quality_raw": 3780,
    "motion": "STOP",
    "speed": 150,
    "last_command": "STOP",
    "command_source": "SYSTEM",
    "last_transcription": "",
    "partial_transcription": "",
    "voice_listening": False,
    "voice_error": "",
    "tx_counter": 0,
    "ack_counter": 0,
    "last_tx_ms": 0,
    "last_ack_ms": 0,
    "history": [
        {
            "time": time.strftime("%H:%M:%S"),
            "source": "SYSTEM",
            "text": "Base Station demo started",
        }
    ],
}

last_voice_command = ""
last_voice_command_time = 0.0


def add_history(source, text):
    with lock:
        state["history"].insert(
            0,
            {"time": time.strftime("%H:%M:%S"), "source": source, "text": text},
        )
        state["history"] = state["history"][:10]


def set_command(command, source="MANUAL", speed=None):
    """Update the simulated rover command. No UDP is sent in this demo."""
    command = str(command).upper().strip()
    if command not in VALID_COMMANDS:
        command = "STOP"

    with lock:
        if speed is not None:
            try:
                state["speed"] = max(0, min(255, int(speed)))
            except Exception:
                pass

        state["last_command"] = command
        state["command_source"] = source
        state["tx_counter"] += 1
        state["last_tx_ms"] = int(time.time() * 1000)

        if command != "STATUS":
            state["motion"] = command

    add_history(source, f"{command} command")

    def simulate_ack():
        time.sleep(0.18)
        with lock:
            state["ack_counter"] += 1
            state["last_ack_ms"] = int(time.time() * 1000)
        add_history("ROVER", f"ACK {command}")

    threading.Thread(target=simulate_ack, daemon=True).start()
    logger.info(f"SIM command from {source}: {command}")
    return command


def detect_command(text):
    cleaned = re.sub(r"[^a-zA-Z ]+", " ", text.lower())
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    if "stop" in cleaned or "halt" in cleaned:
        return "STOP"
    if any(p in cleaned for p in ("go forward", "move forward", "forward", "straight", "go straight")):
        return "FORWARD"
    if any(p in cleaned for p in ("go backward", "move backward", "backward", "go back", "reverse")):
        return "BACKWARD"
    if any(p in cleaned for p in ("turn left", "go left", "move left", "left")):
        return "LEFT"
    if any(p in cleaned for p in ("turn right", "go right", "move right", "right")):
        return "RIGHT"
    if any(p in cleaned for p in ("status", "report", "rover status")):
        return "STATUS"
    return None


def process_voice_text(text):
    global last_voice_command, last_voice_command_time

    command = detect_command(text)
    if not command:
        return

    now = time.monotonic()
    if command == last_voice_command and (now - last_voice_command_time) < 1.25:
        return

    last_voice_command = command
    last_voice_command_time = now
    set_command(command, source="VOICE")


def voice_worker():
    global voice_stop_requested

    with lock:
        state["voice_listening"] = True
        state["voice_error"] = ""
        state["partial_transcription"] = ""

    add_history("VOICE", "Listening started")

    try:
        with asr.transcribe_stream(duration=0) as stream:
            for chunk in stream:
                if voice_stop_requested:
                    break

                event_type = getattr(chunk, "type", "")
                text = str(getattr(chunk, "data", "") or "").strip()
                if not text:
                    continue

                with lock:
                    if event_type == "partial_text":
                        state["partial_transcription"] = text
                    elif event_type == "full_text":
                        state["last_transcription"] = text
                        state["partial_transcription"] = ""
                    else:
                        state["partial_transcription"] = text

                if event_type == "full_text":
                    logger.info(f"ASR: {text}")
                    add_history("MIC", text)
                    process_voice_text(text)

    except Exception as exc:
        logger.error(f"Voice recognition error: {exc}")
        with lock:
            state["voice_error"] = str(exc)
        add_history("VOICE", f"ERROR: {exc}")

    finally:
        with lock:
            state["voice_listening"] = False
            state["partial_transcription"] = ""
        voice_stop_requested = False
        add_history("VOICE", "Listening stopped")


def start_voice():
    global voice_thread, voice_stop_requested

    with lock:
        already_listening = state["voice_listening"]

    if already_listening:
        return {"ok": True, "listening": True}

    voice_stop_requested = False
    voice_thread = threading.Thread(target=voice_worker, daemon=True)
    voice_thread.start()
    return {"ok": True, "listening": True}


def stop_voice():
    global voice_stop_requested
    voice_stop_requested = True
    try:
        asr.cancel()
    except Exception as exc:
        logger.warning(f"ASR cancel warning: {exc}")
    return {"ok": True, "listening": False}


def state_api():
    with lock:
        result = dict(state)
        result["history"] = [dict(item) for item in state["history"]]
    return result


async def command_api(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}

    accepted = set_command(
        body.get("command", "STOP"),
        source="MANUAL",
        speed=body.get("speed", None),
    )
    return {"ok": True, "command": accepted, "simulation": True}


def voice_start_api():
    return start_voice()


def voice_stop_api():
    return stop_voice()


ui.expose_api("GET", "/api/state", state_api)
ui.expose_api("POST", "/api/command", command_api)
ui.expose_api("POST", "/api/voice/start", voice_start_api)
ui.expose_api("POST", "/api/voice/stop", voice_stop_api)

last_dummy_update = 0.0
dummy_phase = 0


def demo_loop():
    global last_dummy_update, dummy_phase

    now = time.monotonic()
    if now - last_dummy_update >= 1.0:
        last_dummy_update = now
        dummy_phase += 1

        with lock:
            state["temperature_c"] = round(
                max(22.0, min(29.0, state["temperature_c"] + random.uniform(-0.08, 0.08))), 1
            )
            state["humidity_percent"] = round(
                max(35.0, min(60.0, state["humidity_percent"] + random.uniform(-0.25, 0.25))), 1
            )
            state["pressure_hpa"] = round(
                max(998.0, min(1020.0, state["pressure_hpa"] + random.uniform(-0.08, 0.08))), 1
            )
            state["distance_cm"] = round(
                max(25.0, min(220.0, 118.0 + 15.0 * math.sin(dummy_phase / 6.0))), 1
            )
            state["air_quality_raw"] = int(
                max(2500, min(6000, state["air_quality_raw"] + random.randint(-18, 18)))
            )

    time.sleep(0.03)


App.run(user_loop=demo_loop)
