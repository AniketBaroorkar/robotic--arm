# Fruit Sorting Robot — FINAL (v8)

Arduino UNO Q + PCA9685 + 6DOF arm + Logitech C270, built with Arduino
App Lab (Video Object Detection + WebUI bricks). The arm finds a fruit
anywhere in the white box, does a slow verified top-down pick, and sorts
it into the fixed colored boxes (apple->Red 30deg, banana->Yellow 60deg,
orange->Orange 150deg). Toy fruits are handled by label mapping
(sports ball/frisbee->apple, mouse/bird->banana).

## Physical layout (see placement_diagram.svg)
All on one straight line: ARM - WHITE BOX - CAMERA.
- Arm base -> white box center: 15 cm (box spans 10-20 cm)
- White box center -> camera stand: 25 cm  (arm->camera = 40 cm)
- Camera lens 30 cm high, tilted ~45 deg down at the box
- Colored boxes at base angles 30/60/150, ~16 cm out
The code is pre-configured for THIS layout (INVERT_CAMERA_X/Y = True,
BASE_X_SCALE derived for the 40 cm view distance).

## Run
1. Open the app in App Lab, press Run (sketch flashes automatically).
2. Console must show: "Servo bridge ready" then "Fruit sorter v8-placed
   started". Open http://<board-ip>:7000 -> badge must say v8.
3. ARM STARTS DISABLED. Put a fruit in the box and read the
   "[ARM DISABLED] would pick ..." log lines:
   - fruit on the ARM'S RIGHT -> base < 90; LEFT -> base > 90
     (wrong way: flip the sign of BASE_X_SCALE in main.py)
   - fruit at the edge NEAR the arm -> shoulder ~45; far edge -> ~30
     (reversed: set INVERT_CAMERA_Y = False)
4. Press "Enable Arm". First picks: hand near servo power.

## Tuning knobs (top of python/main.py)
- PICK_NEAR_POSE / PICK_FAR_POSE .... where the claw lands (depth/reach)
- PICK_OFFSET_X_PX / _Y_PX .......... small constant aim corrections
- BASE_X_SCALE ...................... left/right accuracy (+-0.05 steps)
- ELBOW_MIN/MAX ..................... ch2 hard safety range (60-150)
- GRIPPER_CLOSED .................... 180 measured; ~170 if servo strains
- SPEEDS: TRAVEL/APPROACH/PRECISE_STEP_DEG
- STABLE_FRAMES / POSITION_TOLERANCE_PIXELS / MIN_DETECTION_CONFIDENCE
- WRIST_ROTATE_BANANA / BANANA_VERTICAL_RATIO (banana claw alignment)

## Page buttons
Enable/Disable Arm · Test Servos (identifies channel wiring) ·
Home Arm · Reset E-STOP · E-STOP. Log panel narrates every stage:
[LOCK] [STAGE] [VERIFY] [RETRY] [CLAMP] [ORIENT] [CAMERA OK].

## If detection is poor on toy fruits
Use the Video Object Detection brick's "Train new AI model" (Edge
Impulse) with photos of YOUR fruits, keep labels apple/banana/orange,
and remove the extra LABEL_MAP entries.
