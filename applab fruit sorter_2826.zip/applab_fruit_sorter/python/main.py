"""
main.py — Fruit Sorting Robot v7 (Arduino App Lab)
===================================================
v7 changes:
  1. CAMERA INVERSION: the camera and arm face each other, so image X
     is mirrored relative to the arm. INVERT_CAMERA_X / INVERT_CAMERA_Y
     flags correct the coordinates BEFORE any robot math; the raw
     coordinates are never used for base/shoulder/elbow after that.
     (The web page canvas still draws in raw image space, as it must.)
  2. STABILIZATION: the target must stay within POSITION_TOLERANCE_PIXELS
     of the running MEDIAN for STABLE_FRAMES consecutive frames before
     anything moves; the MEDIAN of those frames becomes the locked
     position for the whole pickup.
  3. DROP DEPTH = PICKUP DEPTH: the exact pickup elbow angle is saved
     when the claw grips, and the drop lowers to that same depth (slow,
     PRECISE speed) before the claw opens. No releasing from high up;
     vertical lift after release.
  4/5. CLAW FULLY ISOLATED: closing/opening commands ONLY the gripper
     channel (move_servo ch5). All arm joints are saved as locked poses
     and receive no commands while the claw operates — channel 3
     included: it is impossible for it to be re-commanded during the
     close, the grip pause, or verification.
  6. LOCKED POSES: approach/pickup/lift/drop poses are computed ONCE per
     attempt after stabilization and stored; no position math runs while
     lowering, closing, or lifting.
"""

import statistics
import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v8-placed"

# ======================================================================
# CALIBRATION
# Servo order: [base(0), shoulder(1), elbow(2), wrist_pitch(3),
#               wrist_rotate(4), gripper(5)]
# ======================================================================
GRIPPER_CH = 5
GRIPPER_OPEN = 90.0
GRIPPER_CLOSED = 180.0

FRAME_W = 640
FRAME_H = 480

# --- CAMERA AXIS INVERSION (camera and arm FACE EACH OTHER) -----------
INVERT_CAMERA_X = True    # mirrors left/right: corrected_x = W - x
INVERT_CAMERA_Y = True    # CONFIRMED for the built layout: camera faces
                           # the arm, so the box edge NEAREST the camera
                           # (bottom of image) is the FARTHEST reach for
                           # the arm. If you ever move the camera behind
                           # the arm instead, set this back to False.

# --- BASE CALIBRATION --------------------------------------------------
CAMERA_X_OFFSET = 0.0
CAMERA_Y_OFFSET = 0.0
ROBOT_X_OFFSET = 0.0
ROBOT_Y_OFFSET = 0.0
BASE_CENTER_ANGLE = 90.0
BASE_X_SCALE = -0.24      # deg per px, DERIVED from the built layout:
                           # C270 at ~40 cm sees ~41 cm across 640 px
                           # (0.065 cm/px); at 15 cm pick radius that is
                           # ~3.8 deg of base per lateral cm -> ~0.24
                           # deg/px. Fine-tune ±0.05 if picks land left/
                           # right of the fruit; FLIP THE SIGN if the
                           # whole direction is mirrored.
BASE_MIN_ANGLE = 30.0
BASE_MAX_ANGLE = 150.0

# --- CHANNEL 2 (ELBOW) SAFE LIMITS ------------------------------------
ELBOW_MIN = 60.0
ELBOW_MAX = 150.0

# --- PICK REACH (Y -> forward distance) -------------------------------
PICK_NEAR_POSE = {"shoulder": 45.0, "elbow": 148.0}
PICK_FAR_POSE  = {"shoulder": 30.0, "elbow": 135.0}
PICK_ELBOW_HOVER = 120.0

# --- PER-FRUIT WRIST ---------------------------------------------------
WRIST_PITCH_BY_FRUIT = {"apple": 30.0, "banana": 30.0, "orange": 30.0}
WRIST_ROTATE_NORMAL = 90.0
WRIST_ROTATE_BANANA = 0.0
BANANA_VERTICAL_RATIO = 1.25

CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
DROP_SHOULDER = 65.0
DROP_WRIST = 45.0
BANANA_DROP_LOWER_OFFSET = 0.0   # extra elbow lowering for banana drop.
# NOTE: v7 drops at the SAME depth as the pickup already, so this now
# defaults to 0; raise it only if bananas still release too high (the
# ch2 clamp caps the total at ELBOW_MAX either way).

# --- DETECTION LABEL MAPPING ------------------------------------------
LABEL_MAP = {
    "apple": "apple", "sports ball": "apple", "frisbee": "apple",
    "banana": "banana", "mouse": "banana", "bird": "banana",
    "orange": "orange",
}
FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}

# --- STABILIZATION / ACCURACY -----------------------------------------
PICK_OFFSET_X_PX = 0
PICK_OFFSET_Y_PX = 0
CONFIDENCE_MIN = 0.35             # brick detection threshold (display)
MIN_DETECTION_CONFIDENCE = 0.35   # required to trigger a pick
STABLE_FRAMES = 4                 # consecutive in-tolerance frames
POSITION_TOLERANCE_PIXELS = 25    # max deviation from the running median
COOLDOWN_S = 5.0

# --- STAGED MOTION / SPEEDS (deg per 20 ms MCU tick) ------------------
TRAVEL_STEP_DEG = 0.8
APPROACH_STEP_DEG = 0.5
PRECISE_STEP_DEG = 0.3
APPROACH_PAUSE_S = 0.8
GRIP_SETTLE_S = 0.6

# --- PICKUP VERIFICATION ----------------------------------------------
VERIFY_WAIT_S = 2.5
VERIFY_RADIUS_PX = 70
VERIFY_FAIL_HITS = 2
MAX_PICK_ATTEMPTS = 3

MOVE_TIMEOUT_S = 25.0
POLL_S = 0.1

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_hist = deque(maxlen=STABLE_FRAMES)   # (cx, cy, w, h) raw image coords
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0

_log_lines = deque(maxlen=40)
_ui_items = []
_ui_items_ts = 0.0

_verify_active = False
_verify_category = None
_verify_origin = (0, 0)   # RAW image coords (compared to raw detections)
_verify_frames = 0
_verify_hits = 0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


# ======================================================================
# VISION -> ROBOT MAPPING (all robot math uses CORRECTED coordinates)
# ======================================================================
def correct_camera(cx: float, cy: float):
    """Apply the face-to-face camera inversion. Everything downstream of
    this uses only the corrected values."""
    x = (FRAME_W - cx) if INVERT_CAMERA_X else cx
    y = (FRAME_H - cy) if INVERT_CAMERA_Y else cy
    return x, y


def apply_offsets(cx: float, cy: float):
    ox = min(max(cx + PICK_OFFSET_X_PX, 0), FRAME_W)
    oy = min(max(cy + PICK_OFFSET_Y_PX, 0), FRAME_H)
    return ox, oy


def camera_to_robot(cx: float, cy: float):
    rx = (cx - FRAME_W / 2.0 - CAMERA_X_OFFSET) + ROBOT_X_OFFSET
    ry = (FRAME_H - cy - CAMERA_Y_OFFSET) + ROBOT_Y_OFFSET
    return rx, ry


def base_angle_for(rx: float) -> float:
    ang = BASE_CENTER_ANGLE + rx * BASE_X_SCALE
    return min(max(ang, BASE_MIN_ANGLE), BASE_MAX_ANGLE)


def pick_pose_for(ry: float):
    t = min(max(ry / float(FRAME_H), 0.0), 1.0)
    sh = PICK_NEAR_POSE["shoulder"] + t * (PICK_FAR_POSE["shoulder"] - PICK_NEAR_POSE["shoulder"])
    el = PICK_NEAR_POSE["elbow"] + t * (PICK_FAR_POSE["elbow"] - PICK_NEAR_POSE["elbow"])
    return sh, el


def plan_pick(raw_cx: float, raw_cy: float):
    """Raw image center -> (base, shoulder, elbow_down). The ONLY place
    position math happens; called once per attempt (locked poses)."""
    ccx, ccy = correct_camera(raw_cx, raw_cy)
    ccx, ccy = apply_offsets(ccx, ccy)
    rx, ry = camera_to_robot(ccx, ccy)
    return base_angle_for(rx), *pick_pose_for(ry)


def clamp_elbow(angle: float) -> float:
    clamped = min(max(angle, ELBOW_MIN), ELBOW_MAX)
    if clamped != angle:
        log(f"[CLAMP] ch2 request {angle:.0f} -> {clamped:.0f} "
            f"(limits {ELBOW_MIN:.0f}-{ELBOW_MAX:.0f})")
    return clamped


def banana_wrist_rotate(w: float, h: float) -> float:
    if w <= 0 or h <= 0:
        return WRIST_ROTATE_BANANA
    if h >= w * BANANA_VERTICAL_RATIO:
        log(f"[ORIENT] banana box {w:.0f}x{h:.0f} -> VERTICAL -> "
            f"normal wrist {WRIST_ROTATE_NORMAL:.0f}")
        return WRIST_ROTATE_NORMAL
    log(f"[ORIENT] banana box {w:.0f}x{h:.0f} -> horizontal/tilted -> "
        f"rotate wrist {WRIST_ROTATE_BANANA:.0f}")
    return WRIST_ROTATE_BANANA


# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def wait_motion(timeout: float = MOVE_TIMEOUT_S) -> None:
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > timeout:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def move_pose(pose, grip) -> None:
    """pose = (base, shoulder, elbow, wrist_pitch, wrist_rotate)."""
    b, sh, el, wp, wr = pose
    el = clamp_elbow(el)
    ok = Bridge.call("move_all", float(b), float(sh), float(el),
                     float(wp), float(wr), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    wait_motion()


def gripper_only(angle: float) -> None:
    """ONLY the gripper channel — no arm joint (channel 3 included)
    receives any command while the claw operates."""
    if not Bridge.call("move_servo", GRIPPER_CH, float(angle)):
        raise RuntimeError("MCU rejected gripper move (E-STOP active?)")
    wait_motion()


def set_speed(deg_per_tick: float) -> None:
    try:
        Bridge.call("set_speed", float(deg_per_tick))
    except Exception as exc:  # noqa: BLE001
        log(f"[WARN] set_speed failed: {exc}")


# ======================================================================
# PICKUP VERIFICATION (raw image coords)
# ======================================================================
def verify_pickup(category: str, origin_raw) -> bool:
    global _verify_active, _verify_category, _verify_origin
    global _verify_frames, _verify_hits
    _verify_category = category
    _verify_origin = origin_raw
    _verify_frames = 0
    _verify_hits = 0
    _verify_active = True
    time.sleep(VERIFY_WAIT_S)
    _verify_active = False
    failed = _verify_hits >= VERIFY_FAIL_HITS
    log(f"[VERIFY] {_verify_frames} frames watched, {_verify_hits} still "
        f"at origin -> {'FAILED' if failed else 'PICKED OK'}")
    return not failed


def latest_target(category: str, max_age_s: float = 3.0):
    """Freshest detection -> (raw_cx, raw_cy, w, h) for retries."""
    if not _ui_items or time.monotonic() - _ui_items_ts > max_age_s:
        return None
    best = None
    for it in _ui_items:
        if it.get("target") and it.get("fruit") == category:
            if best is None or it["confidence"] > best["confidence"]:
                best = it
    if best is None:
        return None
    x1, y1, x2, y2 = best["box"]
    return best["cx"], best["cy"], (x2 - x1), (y2 - y1)


# ======================================================================
# PICK AND PLACE (locked poses; claw isolated)
# ======================================================================
def pick_and_place(fruit: str, raw_aim, dims, conf: float) -> None:
    global _state, _last_pick_done
    try:
        w, h = dims
        wp = WRIST_PITCH_BY_FRUIT.get(fruit, 30.0)
        picked = False
        pickup_pose = None

        for attempt in range(1, MAX_PICK_ATTEMPTS + 1):
            # ---- position math happens ONCE here, then poses are locked
            b, sh, ed = plan_pick(raw_aim[0], raw_aim[1])
            wr = banana_wrist_rotate(w, h) if fruit == "banana" else WRIST_ROTATE_NORMAL

            aim_pose      = (b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0)
            approach_pose = (b, sh, PICK_ELBOW_HOVER, wp, wr)
            pickup_pose   = (b, sh, ed, wp, wr)
            lift_pose     = approach_pose   # vertical lift = reverse of descend

            _state = f"picking {fruit} (attempt {attempt})"
            log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) attempt "
                f"{attempt}/{MAX_PICK_ATTEMPTS} raw={raw_aim} conf={conf:.2f}")
            log(f"[LOCK] poses saved: base {b:.0f}, shoulder {sh:.0f}, "
                f"elbow-down {ed:.0f}, wrist p{wp:.0f} r{wr:.0f}")

            set_speed(APPROACH_STEP_DEG)
            move_pose(aim_pose, GRIPPER_OPEN)        # 1. aim base upright
            move_pose(approach_pose, GRIPPER_OPEN)   # 2. above the fruit
            log("[STAGE] aligned above object — pausing")
            time.sleep(APPROACH_PAUSE_S)             # 3. pause

            set_speed(PRECISE_STEP_DEG)
            move_pose(pickup_pose, GRIPPER_OPEN)     # 4. lower vertically
            # 5. all arm joints stopped — close ONLY the claw
            log("[STAGE] arm locked — closing claw only (no joint commands)")
            gripper_only(GRIPPER_CLOSED)             # 6. close
            time.sleep(GRIP_SETTLE_S)                # 7. hold exact pose
            move_pose(lift_pose, GRIPPER_CLOSED)     # 8. lift vertically
            set_speed(TRAVEL_STEP_DEG)

            _state = f"verifying {fruit}"
            if verify_pickup(fruit, raw_aim):        # 9. verify
                picked = True
                break

            log(f"[RETRY] object still at origin — reopening claw "
                f"(attempt {attempt}/{MAX_PICK_ATTEMPTS})")
            set_speed(APPROACH_STEP_DEG)
            gripper_only(GRIPPER_OPEN)
            fresh = latest_target(fruit)
            if fresh is not None:
                raw_aim = (fresh[0], fresh[1])
                w, h = fresh[2], fresh[3]
                log(f"[RETRY] corrected alignment to fresh detection {raw_aim}")
            else:
                log("[RETRY] no fresh detection visible — retrying same spot")

        if not picked:
            log(f"[FAIL] could not pick {fruit} after "
                f"{MAX_PICK_ATTEMPTS} attempts — returning home, NOT dropping")
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
            return

        # ---- DROP: same depth as the pickup, saved from pickup_pose ----
        _state = f"placing {fruit}"
        b, sh, ed, wp, wr = pickup_pose
        box = BOX_BASE_ANGLE[fruit]
        drop_depth = ed + (BANANA_DROP_LOWER_OFFSET if fruit == "banana" else 0.0)
        carry_pose         = (b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr)
        drop_travel_pose   = (box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr)
        drop_approach_pose = (box, DROP_SHOULDER, PICK_ELBOW_HOVER, DROP_WRIST, wr)
        drop_release_pose  = (box, DROP_SHOULDER, drop_depth, DROP_WRIST, wr)
        log(f"[LOCK] drop poses: box {box:.0f}, release depth {drop_depth:.0f} "
            f"(same as pickup)")

        move_pose(carry_pose, GRIPPER_CLOSED)        # 10. carry upright
        move_pose(drop_travel_pose, GRIPPER_CLOSED)  #     rotate to box
        move_pose(drop_approach_pose, GRIPPER_CLOSED)  # 10. above the box
        set_speed(PRECISE_STEP_DEG)
        move_pose(drop_release_pose, GRIPPER_CLOSED)  # 11. lower to pickup depth
        log("[STAGE] arm locked — opening claw only")
        gripper_only(GRIPPER_OPEN)                    # 12. open ONLY the claw
        time.sleep(GRIP_SETTLE_S)
        move_pose(drop_approach_pose, GRIPPER_OPEN)   # 13. lift vertically
        set_speed(TRAVEL_STEP_DEG)
        move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)  # 14. home

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        set_speed(TRAVEL_STEP_DEG)
        _state = "idle"
        _last_pick_done = time.monotonic()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING (median + tolerance stabilization)
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log, _ui_items, _ui_items_ts, _verify_frames, _verify_hits
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = []
                for l in _last_labels:
                    mapped = LABEL_MAP.get(l)
                    if mapped is None:
                        parts.append(f"{l} (ignored)")
                    elif mapped != l:
                        parts.append(f"{l}->{mapped}")
                    else:
                        parts.append(l)
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        items = []
        for label, instances in (results or {}).items():
            raw = str(label).lower()
            mapped = LABEL_MAP.get(raw)
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                items.append({
                    "fruit": mapped or raw,
                    "raw": raw,
                    "target": mapped is not None,
                    "color": FRUIT_COLOR.get(mapped) if mapped else None,
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if mapped is not None and (best is None or conf > best[2]):
                    best = (mapped, (cx, cy, x2 - x1, y2 - y1), conf)

        _ui_items = items
        _ui_items_ts = now

        if _verify_active and _verify_category:
            _verify_frames += 1
            ox, oy = _verify_origin
            r2 = VERIFY_RADIUS_PX * VERIFY_RADIUS_PX
            for it in items:
                if it["target"] and it["fruit"] == _verify_category:
                    dx, dy = it["cx"] - ox, it["cy"] - oy
                    if dx * dx + dy * dy <= r2:
                        _verify_hits += 1
                        break

        if best is None:
            _stable_label, _stable_count = None, 0
            _hist.clear()
            return

        label, cinfo, conf = best
        if label != _stable_label:
            _stable_label, _stable_count = label, 1
            _hist.clear()
            _hist.append(cinfo)
            return

        # Tolerance check against the running MEDIAN (jitter rejection)
        med_cx = statistics.median(c[0] for c in _hist)
        med_cy = statistics.median(c[1] for c in _hist)
        if (abs(cinfo[0] - med_cx) > POSITION_TOLERANCE_PIXELS or
                abs(cinfo[1] - med_cy) > POSITION_TOLERANCE_PIXELS):
            # moved too much — restart stabilization from this sample
            _stable_count = 1
            _hist.clear()
            _hist.append(cinfo)
            return

        _stable_count += 1
        _hist.append(cinfo)

        if _stable_count < STABLE_FRAMES:
            return
        if conf < MIN_DETECTION_CONFIDENCE:
            return
        if _busy.is_set():
            return
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        # Locked position = MEDIAN of the stable window (raw coords)
        raw_aim = (int(statistics.median(c[0] for c in _hist)),
                   int(statistics.median(c[1] for c in _hist)))
        med_w = statistics.median(c[2] for c in _hist)
        med_h = statistics.median(c[3] for c in _hist)

        if not _arm_enabled:
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                bb, sh, ed = plan_pick(raw_aim[0], raw_aim[1])
                log(f"[ARM DISABLED] would pick {label} at raw {raw_aim} -> "
                    f"base {bb:.0f}, shoulder {sh:.0f}, elbow {ed:.0f}. "
                    f"Press 'Enable Arm' to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        _hist.clear()
        threading.Thread(target=pick_and_place,
                         args=(label, raw_aim, (med_w, med_h), conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested from web page")
    return {"ok": True}


def api_test_servos():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    _busy.set()

    def _run():
        names = ["0 = base", "1 = shoulder", "2 = elbow",
                 "3 = wrist pitch", "4 = wrist rotate", "5 = GRIPPER/claw"]
        try:
            log("[TEST] Servo sweep — watch which joint moves per channel.")
            for ch in range(6):
                log(f"[TEST] testing channel {names[ch]} ...")
                for target in (60.0, 120.0, 90.0):
                    if ch == 2:
                        target = clamp_elbow(target)
                    if not Bridge.call("move_servo", ch, target):
                        raise RuntimeError(f"MCU rejected move on ch {ch}")
                    wait_motion(10.0)
                time.sleep(0.4)
            log("[TEST] Sweep done. Returning to HOME.")
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] servo test failed: {exc}")
        finally:
            _busy.clear()

    threading.Thread(target=_run, daemon=True).start()
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)
ui.expose_api("GET", "/api/test_servos", api_test_servos)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 10.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


_stream_info = None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)
    candidates = [
        (4912, "/"), (4912, "/stream"), (4912, "/video"),
        (4912, "/mjpeg"), (4912, "/feed"), (5050, "/"),
    ]
    found = 0
    for port, path in candidates:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            status = getattr(resp, "status", 200)
            resp.close()
            if status == 200:
                found += 1
                log(f"[STREAM PROBE] FOUND: port {port} path {path} ({ctype})")
                if _stream_info is None:
                    _stream_info = {"port": port, "path": path,
                                    "content_type": ctype}
        except Exception:
            pass
    if found == 0:
        log("[STREAM PROBE] no raw stream found on common ports — the "
            "Live Detection View IS your live view.")
    else:
        log("[STREAM PROBE] open 'Raw camera stream' on the page to view it.")


threading.Thread(target=_probe_stream, daemon=True).start()

log(f"Fruit sorter {VERSION} started. ARM IS DISABLED — verify aiming on "
    f"the page, then press 'Enable Arm'.")

App.run()
