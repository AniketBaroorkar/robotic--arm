"""
main.py — Fruit Sorting Robot v3 (Arduino App Lab) — REST POLLING UI
=====================================================================
v3 CHANGE: the web page no longer uses Socket.IO/WebSocket at all.
The board was rejecting the browser's Socket.IO client with a protocol
version error, so the page now simply polls a plain HTTP JSON endpoint
(/api/state) once per second via the WebUI brick's expose_api. Nothing
can version-mismatch a plain HTTP GET.

SAFETY: the arm starts DISABLED. Detections show live on the page and
the log prints the exact base angle the arm WOULD aim to. Verify the
direction first (if mirrored, swap BASE_AT_LEFT_EDGE and
BASE_AT_RIGHT_EDGE), then press "Enable Arm" on the page.

Flow when enabled: fruit anywhere in view -> base aims at its
x-position, bend depth from y-position (servo 2 onwards bends; base
only rotates) -> grip -> lift -> fixed colored box for that fruit ->
release -> home -> repeat.
"""

import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v3-polling"

# ======================================================================
# CALIBRATION
# Servo order: [base, shoulder, elbow, wrist_pitch, wrist_rotate, gripper]
# ======================================================================
GRIPPER_OPEN = 30.0
GRIPPER_CLOSED = 80.0
WRIST_ROTATE = 90.0

FRAME_W = 640
FRAME_H = 480

# Base angle at LEFT edge of image vs RIGHT edge (interpolated between).
# If the arm swings the WRONG way, SWAP these two numbers.
BASE_AT_LEFT_EDGE = 150.0
BASE_AT_RIGHT_EDGE = 30.0

# Bend at BOTTOM of image (near) vs TOP (far). Start identical; make
# FAR different later to enable depth reach.
PICK_NEAR = {"shoulder": 45.0, "elbow": 135.0, "wrist": 90.0}
PICK_FAR  = {"shoulder": 45.0, "elbow": 135.0, "wrist": 90.0}

CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
DROP_SHOULDER = 60.0
DROP_ELBOW = 115.0
DROP_WRIST = 90.0

FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}
TARGET_FRUITS = set(FRUIT_COLOR)

CONFIDENCE_MIN = 0.40       # display threshold
PICK_CONFIDENCE_MIN = 0.55  # ACTION threshold (prevents false triggers)
STABLE_HITS = 3
COOLDOWN_S = 5.0
MOVE_TIMEOUT_S = 20.0
POLL_S = 0.1
GRIP_SETTLE_S = 0.4

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
# debounce_sec=0.4 keeps CPU load down; fruit is stationary so no loss.
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0

_log_lines = deque(maxlen=40)
_ui_items = []           # latest detections for the page
_ui_items_ts = 0.0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


# ======================================================================
# VISION -> ARM MAPPING
# ======================================================================
def base_angle_for_cx(cx: int) -> float:
    frac = min(max(cx / float(FRAME_W), 0.0), 1.0)
    ang = BASE_AT_LEFT_EDGE + frac * (BASE_AT_RIGHT_EDGE - BASE_AT_LEFT_EDGE)
    lo, hi = sorted((BASE_AT_LEFT_EDGE, BASE_AT_RIGHT_EDGE))
    return min(max(ang, lo), hi)


def bend_for_cy(cy: int):
    t = min(max(cy / float(FRAME_H), 0.0), 1.0)  # 0 = top/far, 1 = bottom/near

    def lerp(near_v, far_v):
        return far_v + t * (near_v - far_v)

    return (lerp(PICK_NEAR["shoulder"], PICK_FAR["shoulder"]),
            lerp(PICK_NEAR["elbow"], PICK_FAR["elbow"]),
            lerp(PICK_NEAR["wrist"], PICK_FAR["wrist"]))


# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def move_and_wait(base, shoulder, elbow, wrist, wrot, grip) -> None:
    ok = Bridge.call("move_all", float(base), float(shoulder), float(elbow),
                     float(wrist), float(wrot), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > MOVE_TIMEOUT_S:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def pick_and_place(fruit: str, coords, conf: float) -> None:
    global _state, _last_pick_done
    try:
        cx, cy = coords
        b = base_angle_for_cx(cx)
        ps, pe, pw = bend_for_cy(cy)

        _state = f"picking {fruit}"
        log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) at ({cx},{cy}), conf={conf:.2f}")
        log(f"[AIM] cx={cx} -> base {b:.0f} deg | cy={cy} -> bend "
            f"S{ps:.0f}/E{pe:.0f}/W{pw:.0f}")

        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_OPEN)
        move_and_wait(b, ps, pe, pw, WRIST_ROTATE, GRIPPER_OPEN)
        move_and_wait(b, ps, pe, pw, WRIST_ROTATE, GRIPPER_CLOSED)
        time.sleep(GRIP_SETTLE_S)
        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_CLOSED)

        _state = f"placing {fruit}"
        box = BOX_BASE_ANGLE[fruit]
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, WRIST_ROTATE, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, WRIST_ROTATE, GRIPPER_OPEN)
        time.sleep(GRIP_SETTLE_S)
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_OPEN)
        move_and_wait(*HOME)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_and_wait(*HOME)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        _state = "idle"
        _last_pick_done = time.monotonic()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log, _ui_items, _ui_items_ts
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = [l if l in TARGET_FRUITS else f"{l} (ignored)"
                         for l in _last_labels]
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        items = []
        for label, instances in (results or {}).items():
            lab = str(label).lower()
            is_target = lab in TARGET_FRUITS
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                items.append({
                    "fruit": lab,
                    "target": is_target,
                    "color": FRUIT_COLOR.get(lab),
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if is_target and (best is None or conf > best[2]):
                    best = (lab, (cx, cy), conf)

        _ui_items = items
        _ui_items_ts = now

        if best is None:
            _stable_label, _stable_count = None, 0
            return

        label, coords, conf = best
        if label == _stable_label:
            _stable_count += 1
        else:
            _stable_label, _stable_count = label, 1

        if _stable_count < STABLE_HITS:
            return
        if conf < PICK_CONFIDENCE_MIN:
            return
        if _busy.is_set():
            return
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        if not _arm_enabled:
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                b = base_angle_for_cx(coords[0])
                log(f"[ARM DISABLED] would pick {label} at "
                    f"({coords[0]},{coords[1]}) -> base {b:.0f} deg. "
                    f"Press 'Enable Arm' on the page to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        threading.Thread(target=pick_and_place, args=(label, coords, conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API (polled by the web page — no Socket.IO anywhere)
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested from web page")
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 10.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


# ----------------------------------------------------------------------
# STREAM PROBE: the raw video stream's port/path varies by brick
# version. Instead of guessing in the browser, probe common candidates
# from the board itself and report what actually responds.
# ----------------------------------------------------------------------
_stream_info = None  # {"port": int, "path": str, "content_type": str} | None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)  # let the brick containers finish starting
    candidates = [
        (4912, "/"), (4912, "/stream"), (4912, "/video"),
        (4912, "/mjpeg"), (4912, "/feed"), (5050, "/"),
    ]
    found = 0
    for port, path in candidates:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            status = getattr(resp, "status", 200)
            resp.close()
            if status == 200:
                found += 1
                log(f"[STREAM PROBE] FOUND: port {port} path {path} ({ctype})")
                if _stream_info is None:
                    _stream_info = {"port": port, "path": path,
                                    "content_type": ctype}
        except Exception:
            pass  # candidate not available — expected for most
    if found == 0:
        log("[STREAM PROBE] no raw stream found on common ports — this "
            "brick version doesn't expose one. The Live Detection View "
            "IS your live view.")
    else:
        log("[STREAM PROBE] open 'Raw camera stream' on the page to view it.")


threading.Thread(target=_probe_stream, daemon=True).start()

log(f"Fruit sorter {VERSION} started. ARM IS DISABLED — verify aiming on "
    f"the page, then press 'Enable Arm'.")

App.run()
