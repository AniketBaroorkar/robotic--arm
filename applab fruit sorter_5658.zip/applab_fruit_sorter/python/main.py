"""
main.py — Fruit Sorting Robot v6 (Arduino App Lab)
===================================================
v6 changes:
  1. BANANA ORIENTATION: wrist rotates only for horizontal/tilted
     bananas; a nearly-VERTICAL banana keeps the normal wrist angle.
     Orientation comes from the detection box shape, with a tolerance
     (BANANA_VERTICAL_RATIO) so noise doesn't flip it.
  2. BANANA DROP: lowers BANANA_DROP_LOWER_OFFSET (~50 deg on the
     elbow) further than the normal drop before opening — banana only,
     clamped to safe limits — then lifts back up before going home.
  3. APPLE CLOSE: the claw close commands ONLY the gripper channel
     (move_servo on ch5) — no other joint is commanded at all, so the
     arm physically cannot shift, back off, or re-aim while closing.
  4. BASE CALIBRATION: camera pixels -> calibrated robot coordinates ->
     base angle, with configurable offsets/scale/center, direction
     invert (sign of BASE_X_SCALE), clamping, and smooth MCU motion.
  5. X AND Y BOTH USED: X -> base rotation; Y -> forward reach, i.e.
     shoulder AND elbow interpolate between a NEAR pose and a FAR pose.
     Every object's approach is recalculated from its own center;
     coordinates are stabilized over frames and locked for the whole
     sequence.
"""

import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v6-calibrated"

# ======================================================================
# CALIBRATION
# Servo order: [base(0), shoulder(1), elbow(2), wrist_pitch(3),
#               wrist_rotate(4), gripper(5)]
# ======================================================================
GRIPPER_CH = 5
GRIPPER_OPEN = 90.0
GRIPPER_CLOSED = 180.0   # lower to ~170 if the servo strains on fruit

FRAME_W = 640
FRAME_H = 480

# --- BASE CALIBRATION (camera -> robot -> base angle) -----------------
CAMERA_X_OFFSET = 0.0     # px: shifts where the image "center" is (X)
CAMERA_Y_OFFSET = 0.0     # px: shifts where the image "center" is (Y)
ROBOT_X_OFFSET = 0.0      # robot-frame lateral trim (in px units)
ROBOT_Y_OFFSET = 0.0      # robot-frame forward trim (in px units)
BASE_CENTER_ANGLE = 90.0  # base angle when the object is at image center
BASE_X_SCALE = -0.19      # deg per px. DEFAULT reproduces the previous
                           # working direction (left edge->150, right->30).
                           # If the arm moves LEFT when the object is on
                           # the RIGHT, FLIP THE SIGN (+0.19).
BASE_MIN_ANGLE = 30.0
BASE_MAX_ANGLE = 150.0

# --- CHANNEL 2 (ELBOW) SAFE LIMITS ------------------------------------
ELBOW_MIN = 60.0
ELBOW_MAX = 150.0

# --- PICK REACH: Y controls forward distance --------------------------
# Object at BOTTOM of image (near the arm) vs TOP (far): shoulder AND
# elbow interpolate between these two poses. On this arm, smaller
# shoulder = leans further forward; elbow toward 180 = further down.
PICK_NEAR_POSE = {"shoulder": 45.0, "elbow": 148.0}   # close object
PICK_FAR_POSE  = {"shoulder": 30.0, "elbow": 135.0}   # far object
PICK_ELBOW_HOVER = 120.0   # claw height while hovering above the object

# --- PER-FRUIT WRIST ---------------------------------------------------
WRIST_PITCH_BY_FRUIT = {"apple": 30.0, "banana": 30.0, "orange": 30.0}
WRIST_ROTATE_NORMAL = 90.0     # round fruits, and VERTICAL bananas
WRIST_ROTATE_BANANA = 0.0      # horizontal / tilted bananas only
# Orientation tolerance: box height must exceed width by this factor to
# count as "vertical" (keeps small detection jitter from flipping it):
BANANA_VERTICAL_RATIO = 1.25

CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
DROP_SHOULDER = 65.0
DROP_ELBOW = 65.0
DROP_WRIST = 45.0
BANANA_DROP_LOWER_OFFSET = 50.0   # extra elbow lowering for BANANA drop
                                   # only, clamped to ELBOW limits

# --- DETECTION LABEL MAPPING ------------------------------------------
LABEL_MAP = {
    "apple": "apple", "sports ball": "apple", "frisbee": "apple",
    "banana": "banana", "mouse": "banana", "bird": "banana",
    "orange": "orange",
}
FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}

# --- ACCURACY ----------------------------------------------------------
PICK_OFFSET_X_PX = 0
PICK_OFFSET_Y_PX = 0
CONFIDENCE_MIN = 0.35
PICK_CONFIDENCE_MIN = 0.35
STABLE_HITS = 3
COOLDOWN_S = 5.0

# --- STAGED MOTION / SPEEDS (deg per 20 ms MCU tick) ------------------
TRAVEL_STEP_DEG = 0.8
APPROACH_STEP_DEG = 0.5
PRECISE_STEP_DEG = 0.3
APPROACH_PAUSE_S = 0.8
GRIP_SETTLE_S = 0.6

# --- PICKUP VERIFICATION ----------------------------------------------
VERIFY_WAIT_S = 2.5
VERIFY_RADIUS_PX = 70
VERIFY_FAIL_HITS = 2
MAX_PICK_ATTEMPTS = 3

MOVE_TIMEOUT_S = 25.0
POLL_S = 0.1

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_hist = deque(maxlen=STABLE_HITS)   # (cx, cy, w, h) per stable frame
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0

_log_lines = deque(maxlen=40)
_ui_items = []
_ui_items_ts = 0.0

_verify_active = False
_verify_category = None
_verify_origin = (0, 0)
_verify_frames = 0
_verify_hits = 0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


# ======================================================================
# VISION -> ROBOT MAPPING
# ======================================================================
def apply_offsets(cx: float, cy: float):
    ox = min(max(cx + PICK_OFFSET_X_PX, 0), FRAME_W)
    oy = min(max(cy + PICK_OFFSET_Y_PX, 0), FRAME_H)
    return int(ox), int(oy)


def camera_to_robot(cx: float, cy: float):
    """Camera pixels -> calibrated robot-plane coordinates.
    rx: lateral (px, + = right of center after calibration)
    ry: forward distance proxy (px, 0 = nearest/bottom, FRAME_H = farthest)."""
    rx = (cx - FRAME_W / 2.0 - CAMERA_X_OFFSET) + ROBOT_X_OFFSET
    ry = (FRAME_H - cy - CAMERA_Y_OFFSET) + ROBOT_Y_OFFSET
    return rx, ry


def base_angle_for(rx: float) -> float:
    ang = BASE_CENTER_ANGLE + rx * BASE_X_SCALE
    return min(max(ang, BASE_MIN_ANGLE), BASE_MAX_ANGLE)


def pick_pose_for(ry: float):
    """Y -> forward reach: interpolate shoulder AND elbow between the
    NEAR pose (ry=0, object at bottom) and FAR pose (ry=FRAME_H, top)."""
    t = min(max(ry / float(FRAME_H), 0.0), 1.0)
    sh = PICK_NEAR_POSE["shoulder"] + t * (PICK_FAR_POSE["shoulder"] - PICK_NEAR_POSE["shoulder"])
    el = PICK_NEAR_POSE["elbow"] + t * (PICK_FAR_POSE["elbow"] - PICK_NEAR_POSE["elbow"])
    return sh, el


def clamp_elbow(angle: float) -> float:
    clamped = min(max(angle, ELBOW_MIN), ELBOW_MAX)
    if clamped != angle:
        log(f"[CLAMP] ch2 request {angle:.0f} -> {clamped:.0f} "
            f"(limits {ELBOW_MIN:.0f}-{ELBOW_MAX:.0f})")
    return clamped


def banana_wrist_rotate(w: float, h: float) -> float:
    """Orientation-aware wrist: VERTICAL banana (tall box) keeps the
    normal wrist; horizontal/tilted rotates for jaw alignment."""
    if w <= 0 or h <= 0:
        return WRIST_ROTATE_BANANA
    if h >= w * BANANA_VERTICAL_RATIO:
        log(f"[ORIENT] banana box {w:.0f}x{h:.0f} -> VERTICAL -> "
            f"normal wrist {WRIST_ROTATE_NORMAL:.0f}")
        return WRIST_ROTATE_NORMAL
    log(f"[ORIENT] banana box {w:.0f}x{h:.0f} -> horizontal/tilted -> "
        f"rotate wrist {WRIST_ROTATE_BANANA:.0f}")
    return WRIST_ROTATE_BANANA


# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def wait_motion(timeout: float = MOVE_TIMEOUT_S) -> None:
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > timeout:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def move_and_wait(base, shoulder, elbow, wrist, wrot, grip) -> None:
    elbow = clamp_elbow(elbow)
    ok = Bridge.call("move_all", float(base), float(shoulder), float(elbow),
                     float(wrist), float(wrot), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    wait_motion()


def gripper_only(angle: float) -> None:
    """Command ONLY the gripper channel — no other joint receives any
    command, so the arm cannot move while the claw closes/opens."""
    if not Bridge.call("move_servo", GRIPPER_CH, float(angle)):
        raise RuntimeError("MCU rejected gripper move (E-STOP active?)")
    wait_motion()


def set_speed(deg_per_tick: float) -> None:
    try:
        Bridge.call("set_speed", float(deg_per_tick))
    except Exception as exc:  # noqa: BLE001
        log(f"[WARN] set_speed failed: {exc}")


# ======================================================================
# PICKUP VERIFICATION
# ======================================================================
def verify_pickup(category: str, origin) -> bool:
    global _verify_active, _verify_category, _verify_origin
    global _verify_frames, _verify_hits
    _verify_category = category
    _verify_origin = origin
    _verify_frames = 0
    _verify_hits = 0
    _verify_active = True
    time.sleep(VERIFY_WAIT_S)
    _verify_active = False
    failed = _verify_hits >= VERIFY_FAIL_HITS
    log(f"[VERIFY] {_verify_frames} frames watched, {_verify_hits} still "
        f"at origin -> {'FAILED' if failed else 'PICKED OK'}")
    return not failed


def latest_target(category: str, max_age_s: float = 3.0):
    """Freshest detection of the category -> (cx, cy, w, h) for retries."""
    if not _ui_items or time.monotonic() - _ui_items_ts > max_age_s:
        return None
    best = None
    for it in _ui_items:
        if it.get("target") and it.get("fruit") == category:
            if best is None or it["confidence"] > best["confidence"]:
                best = it
    if best is None:
        return None
    x1, y1, x2, y2 = best["box"]
    cx, cy = apply_offsets(best["cx"], best["cy"])
    return cx, cy, (x2 - x1), (y2 - y1)


# ======================================================================
# PICK AND PLACE (staged, verified, calibrated)
# ======================================================================
def pick_and_place(fruit: str, coords, dims, conf: float) -> None:
    global _state, _last_pick_done
    b = 90.0
    wr = WRIST_ROTATE_NORMAL
    try:
        aim = coords
        w, h = dims
        wp = WRIST_PITCH_BY_FRUIT.get(fruit, 30.0)
        picked = False

        for attempt in range(1, MAX_PICK_ATTEMPTS + 1):
            cx, cy = aim
            rx, ry = camera_to_robot(cx, cy)
            b = base_angle_for(rx)
            sh, ed = pick_pose_for(ry)
            # Orientation-aware wrist: only bananas ever rotate, and
            # only when horizontal/tilted (req. 1).
            if fruit == "banana":
                wr = banana_wrist_rotate(w, h)
            else:
                wr = WRIST_ROTATE_NORMAL

            _state = f"picking {fruit} (attempt {attempt})"
            log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) attempt "
                f"{attempt}/{MAX_PICK_ATTEMPTS} at ({cx},{cy}), conf={conf:.2f}")
            log(f"[AIM] rx={rx:.0f} ry={ry:.0f} -> base {b:.0f} | shoulder "
                f"{sh:.0f} | elbow-down {ed:.0f} | wrist p{wp:.0f} r{wr:.0f}")

            # STAGE 1: aim the base while upright
            set_speed(APPROACH_STEP_DEG)
            move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0, GRIPPER_OPEN)
            # STAGE 2: directly above the object, wrist aligned first
            move_and_wait(b, sh, PICK_ELBOW_HOVER, wp, wr, GRIPPER_OPEN)
            log("[STAGE] aligned above object — pausing before descent")
            time.sleep(APPROACH_PAUSE_S)

            # STAGE 3: lower slowly — elbow only, vertical
            set_speed(PRECISE_STEP_DEG)
            move_and_wait(b, sh, ed, wp, wr, GRIPPER_OPEN)
            # STAGE 4: close claw — GRIPPER CHANNEL ONLY, arm stationary
            log("[STAGE] holding position — closing claw only")
            gripper_only(GRIPPER_CLOSED)
            time.sleep(GRIP_SETTLE_S)
            # STAGE 5: lift vertically back to hover
            move_and_wait(b, sh, PICK_ELBOW_HOVER, wp, wr, GRIPPER_CLOSED)
            set_speed(TRAVEL_STEP_DEG)

            # STAGE 6: verify via camera
            _state = f"verifying {fruit}"
            if verify_pickup(fruit, aim):
                picked = True
                break

            log(f"[RETRY] object still at origin — reopening claw "
                f"(attempt {attempt}/{MAX_PICK_ATTEMPTS})")
            set_speed(APPROACH_STEP_DEG)
            gripper_only(GRIPPER_OPEN)
            fresh = latest_target(fruit)
            if fresh is not None:
                aim = (fresh[0], fresh[1])
                w, h = fresh[2], fresh[3]
                log(f"[RETRY] corrected alignment to fresh detection {aim}")
            else:
                log("[RETRY] no fresh detection visible — retrying same spot")

        if not picked:
            log(f"[FAIL] could not pick {fruit} after "
                f"{MAX_PICK_ATTEMPTS} attempts — returning home, NOT dropping")
            move_and_wait(*HOME)
            return

        # SUCCESS: carry and drop
        _state = f"placing {fruit}"
        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr, GRIPPER_CLOSED)
        box = BOX_BASE_ANGLE[fruit]
        drop_elbow = DROP_ELBOW + (BANANA_DROP_LOWER_OFFSET if fruit == "banana" else 0.0)
        # (clamped inside move_and_wait; a [CLAMP] log appears if limited)
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, drop_elbow, DROP_WRIST, wr, GRIPPER_CLOSED)
        gripper_only(GRIPPER_OPEN)
        time.sleep(GRIP_SETTLE_S)
        # lift back up before returning home (req. 2)
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0, GRIPPER_OPEN)
        move_and_wait(*HOME)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_and_wait(*HOME)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        set_speed(TRAVEL_STEP_DEG)
        _state = "idle"
        _last_pick_done = time.monotonic()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log, _ui_items, _ui_items_ts, _verify_frames, _verify_hits
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = []
                for l in _last_labels:
                    mapped = LABEL_MAP.get(l)
                    if mapped is None:
                        parts.append(f"{l} (ignored)")
                    elif mapped != l:
                        parts.append(f"{l}->{mapped}")
                    else:
                        parts.append(l)
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        items = []
        for label, instances in (results or {}).items():
            raw = str(label).lower()
            mapped = LABEL_MAP.get(raw)
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                items.append({
                    "fruit": mapped or raw,
                    "raw": raw,
                    "target": mapped is not None,
                    "color": FRUIT_COLOR.get(mapped) if mapped else None,
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if mapped is not None and (best is None or conf > best[2]):
                    best = (mapped, (cx, cy, x2 - x1, y2 - y1), conf)

        _ui_items = items
        _ui_items_ts = now

        if _verify_active and _verify_category:
            _verify_frames += 1
            ox, oy = _verify_origin
            r2 = VERIFY_RADIUS_PX * VERIFY_RADIUS_PX
            for it in items:
                if it["target"] and it["fruit"] == _verify_category:
                    dx, dy = it["cx"] - ox, it["cy"] - oy
                    if dx * dx + dy * dy <= r2:
                        _verify_hits += 1
                        break

        if best is None:
            _stable_label, _stable_count = None, 0
            _hist.clear()
            return

        label, cinfo, conf = best
        if label == _stable_label:
            _stable_count += 1
            _hist.append(cinfo)
        else:
            _stable_label, _stable_count = label, 1
            _hist.clear()
            _hist.append(cinfo)

        if _stable_count < STABLE_HITS:
            return
        if conf < PICK_CONFIDENCE_MIN:
            return
        if _busy.is_set():
            return
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        n = len(_hist)
        avg_cx = sum(c[0] for c in _hist) / n
        avg_cy = sum(c[1] for c in _hist) / n
        avg_w = sum(c[2] for c in _hist) / n
        avg_h = sum(c[3] for c in _hist) / n
        aim = apply_offsets(avg_cx, avg_cy)

        if not _arm_enabled:
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                rx, ry = camera_to_robot(aim[0], aim[1])
                bb = base_angle_for(rx)
                sh, ed = pick_pose_for(ry)
                log(f"[ARM DISABLED] would pick {label} at {aim} -> base "
                    f"{bb:.0f}, shoulder {sh:.0f}, elbow {ed:.0f}. "
                    f"Press 'Enable Arm' to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        _hist.clear()
        threading.Thread(target=pick_and_place,
                         args=(label, aim, (avg_w, avg_h), conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested from web page")
    return {"ok": True}


def api_test_servos():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    _busy.set()

    def _run():
        names = ["0 = base", "1 = shoulder", "2 = elbow",
                 "3 = wrist pitch", "4 = wrist rotate", "5 = GRIPPER/claw"]
        try:
            log("[TEST] Servo sweep — watch which joint moves per channel.")
            for ch in range(6):
                log(f"[TEST] testing channel {names[ch]} ...")
                for target in (60.0, 120.0, 90.0):
                    if ch == 2:
                        target = clamp_elbow(target)
                    if not Bridge.call("move_servo", ch, target):
                        raise RuntimeError(f"MCU rejected move on ch {ch}")
                    wait_motion(10.0)
                time.sleep(0.4)
            log("[TEST] Sweep done. Returning to HOME.")
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] servo test failed: {exc}")
        finally:
            _busy.clear()

    threading.Thread(target=_run, daemon=True).start()
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)
ui.expose_api("GET", "/api/test_servos", api_test_servos)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 10.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


_stream_info = None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)
    candidates = [
        (4912, "/"), (4912, "/stream"), (4912, "/video"),
        (4912, "/mjpeg"), (4912, "/feed"), (5050, "/"),
    ]
    found = 0
    for port, path in candidates:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            status = getattr(resp, "status", 200)
            resp.close()
            if status == 200:
                found += 1
                log(f"[STREAM PROBE] FOUND: port {port} path {path} ({ctype})")
                if _stream_info is None:
                    _stream_info = {"port": port, "path": path,
                                    "content_type": ctype}
        except Exception:
            pass
    if found == 0:
        log("[STREAM PROBE] no raw stream found on common ports — the "
            "Live Detection View IS your live view.")
    else:
        log("[STREAM PROBE] open 'Raw camera stream' on the page to view it.")


threading.Thread(target=_probe_stream, daemon=True).start()

log(f"Fruit sorter {VERSION} started. ARM IS DISABLED — verify aiming on "
    f"the page, then press 'Enable Arm'.")

App.run()
