// app.js — Socket.IO client for the fruit sorter dashboard.
// server -> browser: "status", "detections", "log"
// browser -> server: "arm_toggle", "estop", "estop_reset", "go_home", "hello"

const socket = io("http://" + window.location.host);
const $ = (id) => document.getElementById(id);

const FRAME_W = 640, FRAME_H = 480;
const COLOR_HEX = { Red: "#e5484d", Yellow: "#f5c518", Orange: "#f5820f" };
const VIDEO_STREAM_URL = "http://" + window.location.hostname + ":4912/";

// ---- raw video attempt (secondary; canvas below is the reliable view)
window.addEventListener("DOMContentLoaded", () => {
  const img = $("rawvid-img");
  img.src = VIDEO_STREAM_URL;
  img.onerror = () => { img.style.display = "none"; };
  $("rawvid-link").href = VIDEO_STREAM_URL;
});

// ---- connection ----------------------------------------------------
socket.on("connect", () => {
  $("conn-dot").className = "live";
  socket.emit("hello", {});           // ask server for current state
});
socket.on("disconnect", () => $("conn-dot").className = "down");

// ---- detection canvas ----------------------------------------------
const canvas = $("radar");
const ctx = canvas.getContext("2d");
let lastItems = [];
let lastItemsAt = 0;

function drawRadar() {
  ctx.fillStyle = "#0b0e12";
  ctx.fillRect(0, 0, FRAME_W, FRAME_H);

  // Faint grid so an empty view still reads as "alive"
  ctx.strokeStyle = "#1c222b";
  ctx.lineWidth = 1;
  for (let x = 0; x <= FRAME_W; x += 80) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, FRAME_H); ctx.stroke();
  }
  for (let y = 0; y <= FRAME_H; y += 80) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(FRAME_W, y); ctx.stroke();
  }

  const stale = Date.now() - lastItemsAt > 3000;
  ctx.font = "14px sans-serif";

  if (stale || !lastItems.length) {
    ctx.fillStyle = "#8b96a5";
    ctx.fillText(stale ? "waiting for detections…" : "nothing detected in view",
                 16, 26);
    return;
  }

  for (const it of lastItems) {
    const [x1, y1, x2, y2] = it.box;
    const isFruit = !!it.target;
    const color = isFruit ? (COLOR_HEX[it.color] || "#3ecf8e") : "#5a6472";

    ctx.strokeStyle = color;
    ctx.lineWidth = isFruit ? 3 : 1.5;
    ctx.setLineDash(isFruit ? [] : [6, 5]);
    ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
    ctx.setLineDash([]);

    // center marker for fruits (this is the exact point the arm aims at)
    if (isFruit) {
      ctx.beginPath();
      ctx.arc(it.cx, it.cy, 4, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
    }

    const label = it.fruit + " " + Math.round(it.confidence * 100) + "%" +
                  (isFruit ? "" : " (ignored)");
    const ty = Math.max(14, y1 - 6);
    ctx.fillStyle = color;
    ctx.fillText(label, x1 + 2, ty);
  }
}
setInterval(drawRadar, 500);
drawRadar();

// ---- status panel ---------------------------------------------------
socket.on("status", (d) => {
  const state = d.state || "idle";
  const badge = $("state");
  badge.textContent = state;
  badge.className = "badge " + (state === "idle" ? "idle" : "active");

  const armBtn = $("btn-arm");
  if (d.arm_enabled) {
    armBtn.textContent = "Arm: ENABLED — tap to disable";
    armBtn.className = "btn arm-on";
  } else {
    armBtn.textContent = "Arm: DISABLED — tap to enable";
    armBtn.className = "btn arm-off";
  }

  if (d.counts) {
    $("c-apple").textContent = d.counts.apple ?? 0;
    $("c-banana").textContent = d.counts.banana ?? 0;
    $("c-orange").textContent = d.counts.orange ?? 0;
  }
});

// ---- live per-frame detections -------------------------------------
socket.on("detections", (d) => {
  lastItems = (d && d.items) || [];
  lastItemsAt = Date.now();
  drawRadar();

  const fruits = lastItems.filter((it) => it.target);
  const list = $("det-list");
  if (!fruits.length) {
    list.innerHTML = '<li class="dim">No fruit detected</li>';
  } else {
    list.innerHTML = fruits.map((it) =>
      `<li><span class="chip" style="background:${COLOR_HEX[it.color] || "#888"}"></span>` +
      `<b>${it.fruit}</b> · ${it.color} · (${it.cx}, ${it.cy}) · ` +
      `${Math.round(it.confidence * 100)}%</li>`
    ).join("");
  }

  // Live-fill the status rows from the best fruit currently in view
  if (fruits.length) {
    const best = fruits.reduce((a, b) => (b.confidence > a.confidence ? b : a));
    $("fruit").textContent = best.fruit;
    $("color").textContent = best.color;
    $("color-chip").style.background = COLOR_HEX[best.color] || "transparent";
    $("coords").textContent = `(${best.cx}, ${best.cy})`;
    $("conf").textContent = Math.round(best.confidence * 100) + "%";
  } else {
    $("fruit").textContent = "—";
    $("color").textContent = "—";
    $("color-chip").style.background = "transparent";
    $("coords").textContent = "—";
    $("conf").textContent = "—";
  }
});

// ---- log tail -------------------------------------------------------
socket.on("log", (d) => {
  const box = $("log");
  const line = document.createElement("div");
  line.textContent = d.line;
  box.appendChild(line);
  while (box.childElementCount > 40) box.removeChild(box.firstChild);
  box.scrollTop = box.scrollHeight;
});

// ---- buttons --------------------------------------------------------
$("btn-arm").onclick = () => socket.emit("arm_toggle", {});
$("btn-estop").onclick = () => socket.emit("estop", {});
$("btn-reset").onclick = () => socket.emit("estop_reset", {});
$("btn-home").onclick = () => socket.emit("go_home", {});
