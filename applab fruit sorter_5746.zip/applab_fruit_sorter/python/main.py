"""
main.py — Fruit Sorting Robot (Arduino App Lab) — VISION-GUIDED PICK
=====================================================================
SAFETY: the arm starts DISABLED. Detections are shown live on the web
page (canvas + log, including the exact base angle the arm WOULD aim
to), but nothing moves until you press "Enable Arm" on the page. Use
the disabled mode to verify the aiming direction is correct first —
if it's mirrored, swap BASE_AT_LEFT_EDGE and BASE_AT_RIGHT_EDGE.

Flow when enabled:
  fruit anywhere in camera view -> base aims at its x-position, bend
  depth from its y-position (servo 2 onwards bends; base only rotates)
  -> grip -> lift -> fixed calibrated colored box for that fruit ->
  release -> home -> repeat.
"""

import threading
import time

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

# ======================================================================
# CALIBRATION
# Servo order: [base, shoulder, elbow, wrist_pitch, wrist_rotate, gripper]
# ======================================================================
GRIPPER_OPEN = 30.0
GRIPPER_CLOSED = 80.0
WRIST_ROTATE = 90.0

FRAME_W = 640
FRAME_H = 480

# Base angle at LEFT edge of image vs RIGHT edge (interpolated between).
# If the arm swings the WRONG way, SWAP these two numbers.
BASE_AT_LEFT_EDGE = 150.0
BASE_AT_RIGHT_EDGE = 30.0

# Bend at BOTTOM of image (near) vs TOP (far). Start identical; make
# FAR different later to enable depth reach.
PICK_NEAR = {"shoulder": 45.0, "elbow": 135.0, "wrist": 90.0}
PICK_FAR  = {"shoulder": 45.0, "elbow": 135.0, "wrist": 90.0}

CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
DROP_SHOULDER = 60.0
DROP_ELBOW = 115.0
DROP_WRIST = 90.0

FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}
TARGET_FRUITS = set(FRUIT_COLOR)

CONFIDENCE_MIN = 0.40       # display threshold (what shows on the page)
PICK_CONFIDENCE_MIN = 0.55  # ACTION threshold — a pick only triggers at
                             # this confidence or higher, so borderline
                             # misdetections can't move the arm
STABLE_HITS = 3
COOLDOWN_S = 5.0
MOVE_TIMEOUT_S = 20.0        # motion is slower now (~40 deg/s), allow time
POLL_S = 0.1
GRIP_SETTLE_S = 0.4

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.0)

_arm_enabled = False   # SAFETY: starts disabled; toggle from the web page
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0


def log(msg: str) -> None:
    print(msg, flush=True)
    try:
        ui.send_message("log", {"line": msg})
    except Exception:
        pass


def send_status(target=None, coords=None, conf=None) -> None:
    try:
        ui.send_message("status", {
            "state": _state,
            "arm_enabled": _arm_enabled,
            "target": target,
            "color": FRUIT_COLOR.get(target) if target else None,
            "coords": coords,
            "confidence": conf,
            "counts": _counts,
        })
    except Exception:
        pass


# ======================================================================
# VISION -> ARM MAPPING
# ======================================================================
def base_angle_for_cx(cx: int) -> float:
    frac = min(max(cx / float(FRAME_W), 0.0), 1.0)
    ang = BASE_AT_LEFT_EDGE + frac * (BASE_AT_RIGHT_EDGE - BASE_AT_LEFT_EDGE)
    lo, hi = sorted((BASE_AT_LEFT_EDGE, BASE_AT_RIGHT_EDGE))
    return min(max(ang, lo), hi)


def bend_for_cy(cy: int):
    t = min(max(cy / float(FRAME_H), 0.0), 1.0)  # 0 = top/far, 1 = bottom/near

    def lerp(near_v, far_v):
        return far_v + t * (near_v - far_v)

    return (lerp(PICK_NEAR["shoulder"], PICK_FAR["shoulder"]),
            lerp(PICK_NEAR["elbow"], PICK_FAR["elbow"]),
            lerp(PICK_NEAR["wrist"], PICK_FAR["wrist"]))


# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def move_and_wait(base, shoulder, elbow, wrist, wrot, grip) -> None:
    ok = Bridge.call("move_all", float(base), float(shoulder), float(elbow),
                     float(wrist), float(wrot), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > MOVE_TIMEOUT_S:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def pick_and_place(fruit: str, coords, conf: float) -> None:
    global _state, _last_pick_done
    try:
        cx, cy = coords
        b = base_angle_for_cx(cx)
        ps, pe, pw = bend_for_cy(cy)

        _state = f"picking {fruit}"
        send_status(fruit, coords, conf)
        log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) at ({cx},{cy}), conf={conf:.2f}")
        log(f"[AIM] cx={cx} -> base {b:.0f} deg | cy={cy} -> bend "
            f"S{ps:.0f}/E{pe:.0f}/W{pw:.0f}")

        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_OPEN)
        move_and_wait(b, ps, pe, pw, WRIST_ROTATE, GRIPPER_OPEN)
        move_and_wait(b, ps, pe, pw, WRIST_ROTATE, GRIPPER_CLOSED)
        time.sleep(GRIP_SETTLE_S)
        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_CLOSED)

        _state = f"placing {fruit}"
        send_status(fruit, coords, conf)
        box = BOX_BASE_ANGLE[fruit]
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, WRIST_ROTATE, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, WRIST_ROTATE, GRIPPER_OPEN)
        time.sleep(GRIP_SETTLE_S)
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, WRIST_ROTATE, GRIPPER_OPEN)
        move_and_wait(*HOME)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_and_wait(*HOME)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        _state = "idle"
        _last_pick_done = time.monotonic()
        send_status()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = [l if l in TARGET_FRUITS else f"{l} (ignored)"
                         for l in _last_labels]
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        ui_items = []
        for label, instances in (results or {}).items():
            lab = str(label).lower()
            is_target = lab in TARGET_FRUITS
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                # Send EVERYTHING to the page so the canvas shows what
                # the model sees; non-fruits render grey/"ignored".
                ui_items.append({
                    "fruit": lab,
                    "target": is_target,
                    "color": FRUIT_COLOR.get(lab),
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if is_target and (best is None or conf > best[2]):
                    best = (lab, (cx, cy), conf)

        try:
            ui.send_message("detections", {"items": ui_items})
        except Exception:
            pass

        if best is None:
            _stable_label, _stable_count = None, 0
            return

        label, coords, conf = best
        if label == _stable_label:
            _stable_count += 1
        else:
            _stable_label, _stable_count = label, 1

        if _stable_count < STABLE_HITS:
            return
        if conf < PICK_CONFIDENCE_MIN:
            return  # visible on the page, but not confident enough to act
        if _busy.is_set():
            return
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        if not _arm_enabled:
            # SAFETY PREVIEW: show exactly what the arm WOULD do, so the
            # aiming direction can be verified before enabling motion.
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                b = base_angle_for_cx(coords[0])
                log(f"[ARM DISABLED] would pick {label} at "
                    f"({coords[0]},{coords[1]}) -> base {b:.0f} deg. "
                    f"Press 'Enable Arm' on the page to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        threading.Thread(target=pick_and_place, args=(label, coords, conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# WEB PAGE CONTROLS
# ======================================================================
def on_arm_toggle(client, data=None):
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    send_status()


def on_estop(client, data=None):
    global _arm_enabled
    try:
        _arm_enabled = False   # E-STOP also drops back to disabled
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        send_status()
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")


def on_estop_reset(client, data=None):
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        send_status()
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")


def on_go_home(client, data=None):
    if not _busy.is_set():
        def _home():
            try:
                move_and_wait(*HOME)
            except Exception as exc:  # noqa: BLE001
                log(f"[ERROR] manual home failed: {exc}")
        threading.Thread(target=_home, daemon=True).start()
        log("[HOME] manual home requested from web page")


def on_hello(client, data=None):
    # Browser announces itself on connect -> push current state to it.
    send_status()


ui.on_message("arm_toggle", on_arm_toggle)
ui.on_message("estop", on_estop)
ui.on_message("estop_reset", on_estop_reset)
ui.on_message("go_home", on_go_home)
ui.on_message("hello", on_hello)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 10.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()

log("Fruit sorter started. ARM IS DISABLED — verify aiming on the page, "
    "then press 'Enable Arm'.")
send_status()

App.run()
