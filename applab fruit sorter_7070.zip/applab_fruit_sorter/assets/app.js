// app.js — v3: plain HTTP polling. NO Socket.IO anywhere — the page
// simply GETs /api/state once per second and renders it. Buttons call
// /api/* endpoints. Nothing here can version-mismatch with the board.

const $ = (id) => document.getElementById(id);

const FRAME_W = 640, FRAME_H = 480;
const COLOR_HEX = { Red: "#e5484d", Yellow: "#f5c518", Orange: "#f5820f" };
const VIDEO_STREAM_URL = "http://" + window.location.hostname + ":4912/";

// ---- raw video (lazy: only streams while the section is open) -------
window.addEventListener("DOMContentLoaded", () => {
  const details = document.querySelector(".rawvid");
  const img = $("rawvid-img");
  $("rawvid-link").href = VIDEO_STREAM_URL;
  details.addEventListener("toggle", () => {
    if (details.open) {
      img.style.display = "";
      img.src = VIDEO_STREAM_URL;
      img.onerror = () => { img.style.display = "none"; };
    } else {
      img.src = "";
    }
  });
});

// ---- detection canvas ----------------------------------------------
const canvas = $("radar");
const ctx = canvas.getContext("2d");
let lastItems = [];
let lastAge = null;

function drawRadar() {
  ctx.fillStyle = "#0b0e12";
  ctx.fillRect(0, 0, FRAME_W, FRAME_H);

  ctx.strokeStyle = "#1c222b";
  ctx.lineWidth = 1;
  for (let x = 0; x <= FRAME_W; x += 80) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, FRAME_H); ctx.stroke();
  }
  for (let y = 0; y <= FRAME_H; y += 80) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(FRAME_W, y); ctx.stroke();
  }

  ctx.font = "14px sans-serif";
  const stale = lastAge === null || lastAge > 4;

  if (stale || !lastItems.length) {
    ctx.fillStyle = "#8b96a5";
    ctx.fillText(stale ? "waiting for detections…" : "nothing detected in view",
                 16, 26);
    return;
  }

  for (const it of lastItems) {
    const [x1, y1, x2, y2] = it.box;
    const isFruit = !!it.target;
    const color = isFruit ? (COLOR_HEX[it.color] || "#3ecf8e") : "#5a6472";

    ctx.strokeStyle = color;
    ctx.lineWidth = isFruit ? 3 : 1.5;
    ctx.setLineDash(isFruit ? [] : [6, 5]);
    ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
    ctx.setLineDash([]);

    if (isFruit) {
      ctx.beginPath();
      ctx.arc(it.cx, it.cy, 4, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
    }

    const label = it.fruit + " " + Math.round(it.confidence * 100) + "%" +
                  (isFruit ? "" : " (ignored)");
    ctx.fillStyle = color;
    ctx.fillText(label, x1 + 2, Math.max(14, y1 - 6));
  }
}

// ---- render everything from one state snapshot ----------------------
function render(d) {
  $("conn-dot").className = "live";

  const state = d.state || "idle";
  const badge = $("state");
  badge.textContent = state;
  badge.className = "badge " + (state === "idle" ? "idle" : "active");

  const armBtn = $("btn-arm");
  if (d.arm_enabled) {
    armBtn.textContent = "Arm: ENABLED — tap to disable";
    armBtn.className = "btn arm-on";
  } else {
    armBtn.textContent = "Arm: DISABLED — tap to enable";
    armBtn.className = "btn arm-off";
  }

  if (d.counts) {
    $("c-apple").textContent = d.counts.apple ?? 0;
    $("c-banana").textContent = d.counts.banana ?? 0;
    $("c-orange").textContent = d.counts.orange ?? 0;
  }
  $("frames").textContent = d.frames ?? "—";

  lastItems = d.detections || [];
  lastAge = d.detections_age_s;
  drawRadar();

  const fruits = lastItems.filter((it) => it.target);
  const list = $("det-list");
  if (!fruits.length) {
    list.innerHTML = '<li class="dim">No fruit detected</li>';
  } else {
    list.innerHTML = fruits.map((it) =>
      `<li><span class="chip" style="background:${COLOR_HEX[it.color] || "#888"}"></span>` +
      `<b>${it.fruit}</b> · ${it.color} · (${it.cx}, ${it.cy}) · ` +
      `${Math.round(it.confidence * 100)}%</li>`
    ).join("");
  }

  if (fruits.length) {
    const best = fruits.reduce((a, b) => (b.confidence > a.confidence ? b : a));
    $("fruit").textContent = best.fruit;
    $("color").textContent = best.color;
    $("color-chip").style.background = COLOR_HEX[best.color] || "transparent";
    $("coords").textContent = `(${best.cx}, ${best.cy})`;
    $("conf").textContent = Math.round(best.confidence * 100) + "%";
  } else {
    $("fruit").textContent = "—";
    $("color").textContent = "—";
    $("color-chip").style.background = "transparent";
    $("coords").textContent = "—";
    $("conf").textContent = "—";
  }

  const box = $("log");
  const lines = d.log || [];
  box.textContent = lines.join("\n");
  box.scrollTop = box.scrollHeight;
}

// ---- polling loop ----------------------------------------------------
async function poll() {
  try {
    const res = await fetch("/api/state", { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    render(await res.json());
  } catch (err) {
    $("conn-dot").className = "down";
  }
}
poll();
setInterval(poll, 1000);

// ---- buttons ---------------------------------------------------------
function cmd(path) {
  fetch(path, { cache: "no-store" }).then(poll).catch(() => {
    $("conn-dot").className = "down";
  });
}
$("btn-arm").onclick = () => cmd("/api/arm_toggle");
$("btn-estop").onclick = () => cmd("/api/estop");
$("btn-reset").onclick = () => cmd("/api/estop_reset");
$("btn-home").onclick = () => cmd("/api/home");

drawRadar();
