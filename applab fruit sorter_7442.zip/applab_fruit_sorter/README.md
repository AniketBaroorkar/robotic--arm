# Fruit Sorting Robot — Arduino App Lab

Fruit staged in a WHITE box -> camera identifies it -> arm bends down
from servo 2 onwards (base only rotates), grips, and sorts it into the
matching COLORED box (apple->Red, banana->Yellow, orange->Orange).
Web page on port 7000 shows fruit, color, coordinates, counts, log,
and E-STOP buttons.

## Install (you already have the app imported — pick ONE option)

OPTION A — update in place (fastest, 2 files changed):
1. In App Lab open sketch/sketch.yaml -> select all -> paste the new
   sketch.yaml from this zip. (This adds the `default_profile: default`
   line that fixes the "has no default profile" startup error.)
2. Open python/main.py -> select all -> paste the new main.py.
3. Press Run. Do NOT use the "Add sketch library" button — libraries
   listed in sketch.yaml download automatically at compile time.

OPTION B — clean replace of the whole app:
1. App Lab console (bottom-left) -> `rm -rf ~/ArduinoApps/applab_fruit_sorter`
2. Copy this whole unzipped folder into ~/ArduinoApps/
3. Reopen App Lab, open the app, press Run.

## After pressing Run, the console should show (in order)
1. Sketch compiles (first time downloads the two libraries — takes a while)
2. `Servo bridge ready. All joints homed to 90 deg.` — all six servos move
3. `Fruit sorter started. Waiting for a fruit in the white box...`
4. Open http://<board-ip>:7000  (find IP with `hostname -I` in the console)
5. Put a fruit in view -> console prints `sample_detections: {...}` —
   check the labels are exactly apple / banana / orange

## MUST calibrate at the top of python/main.py
- WHITE_BOX_BASE_ANGLE — base rotation toward the white pickup box
- PICK_SHOULDER / PICK_ELBOW / PICK_WRIST — bend-down pose (START
  SHALLOW; placeholder values WILL be wrong for your arm)
- BOX_BASE_ANGLE — three distinct angles for Red/Yellow/Orange boxes
- DROP_* — shallower bend for releasing into a box
- GRIPPER_OPEN / GRIPPER_CLOSED — your gripper's real angles
- Servo min/max limits in sketch.ino if the arm binds anywhere

First arm test: NO fruit on the table, hand near the servo power switch.

## If toy fruits are never detected
The default model is COCO-trained on real fruit. Use the Video Object
Detection brick's "Train new AI model" (Edge Impulse) to train on your
plastic fruits, then keep the label names apple/banana/orange.
