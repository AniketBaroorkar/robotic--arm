// app.js — Socket.IO client for the fruit sorter dashboard.
// Events must match python/main.py: "status", "detections", "log"
// (server -> browser) and "estop", "estop_reset", "go_home"
// (browser -> server).

const socket = io("http://" + window.location.host);
const $ = (id) => document.getElementById(id);

// Camera stream: served by the video brick on port 4912 (embedded via
// iframe, same pattern as Arduino's official detection examples).
window.addEventListener("DOMContentLoaded", () => {
  $("video").src = "http://" + window.location.hostname + ":4912/";
});

// ---- connection indicator ------------------------------------------
socket.on("connect", () => $("conn-dot").className = "live");
socket.on("disconnect", () => $("conn-dot").className = "down");

// ---- status panel ---------------------------------------------------
const COLOR_HEX = { Red: "#e5484d", Yellow: "#f5c518", Orange: "#f5820f" };

socket.on("status", (d) => {
  const state = d.state || "idle";
  const badge = $("state");
  badge.textContent = state;
  badge.className = "badge " + (state === "idle" ? "idle" : "active");

  $("fruit").textContent = d.target || "—";
  $("color").textContent = d.color || "—";
  $("color-chip").style.background = COLOR_HEX[d.color] || "transparent";
  $("coords").textContent = d.coords ? `(${d.coords[0]}, ${d.coords[1]})` : "—";
  $("conf").textContent =
    (d.confidence != null) ? (d.confidence * 100).toFixed(0) + "%" : "—";

  if (d.counts) {
    $("c-apple").textContent = d.counts.apple ?? 0;
    $("c-banana").textContent = d.counts.banana ?? 0;
    $("c-orange").textContent = d.counts.orange ?? 0;
  }
});

// ---- live per-frame detections -------------------------------------
socket.on("detections", (d) => {
  const list = $("det-list");
  const items = (d && d.items) || [];
  if (!items.length) {
    list.innerHTML = '<li class="dim">No fruit detected</li>';
    return;
  }
  list.innerHTML = items.map((it) =>
    `<li><span class="chip" style="background:${COLOR_HEX[it.color] || "#888"}"></span>` +
    `<b>${it.fruit}</b> · ${it.color} · (${it.cx}, ${it.cy}) · ` +
    `${(it.confidence * 100).toFixed(0)}%</li>`
  ).join("");
});

// ---- log tail -------------------------------------------------------
socket.on("log", (d) => {
  const box = $("log");
  const line = document.createElement("div");
  line.textContent = d.line;
  box.appendChild(line);
  while (box.childElementCount > 40) box.removeChild(box.firstChild);
  box.scrollTop = box.scrollHeight;
});

// ---- buttons --------------------------------------------------------
$("btn-estop").onclick = () => socket.emit("estop", {});
$("btn-reset").onclick = () => socket.emit("estop_reset", {});
$("btn-home").onclick = () => socket.emit("go_home", {});
