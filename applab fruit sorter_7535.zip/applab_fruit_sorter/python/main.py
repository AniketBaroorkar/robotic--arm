"""
main.py — Fruit Sorting Robot v5 (Arduino App Lab) — STAGED + VERIFIED PICK
============================================================================
v5 changes:
  1. CHANNEL 2 (elbow) PROTECTION: configurable ELBOW_MIN/ELBOW_MAX hard
     limits enforced inside move_and_wait() — the single chokepoint every
     motion passes through — so NO function can ever send ch2 beyond
     them. Any clamped command is logged as [CLAMP]. There is no fixed
     180 anywhere; ch2 only moves to the computed angle for the current
     stage, interpolated gradually on the MCU.
  2/3. STAGED pick: aim base -> move above object with wrist aligned
     (banana rotation) -> PAUSE and confirm approach -> lower slowly
     (elbow only, vertical) -> close -> pause -> lift slowly -> VERIFY
     -> only then travel to the drop box. Never home -> pick directly.
  4. Three configurable speeds: TRAVEL (fastest, to boxes/home),
     APPROACH (medium, aiming/hovering), PRECISE (slowest — lowering,
     gripping, lifting).
  5. CAMERA VERIFICATION: after lifting, watches several frames; if the
     object is STILL at its original spot, the pickup failed -> open,
     re-approach with corrected alignment from a fresh detection, and
     retry (max attempts limited). Drops only after verified success.
  6. No premature lowering: stable-frame lock + full approach + pause
     happen before any downward motion.
"""

import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v5-staged"

# ======================================================================
# CALIBRATION
# Servo order: [base, shoulder, elbow(ch2), wrist_pitch(ch3),
#               wrist_rotate(ch4), gripper(ch5)]
# ======================================================================
GRIPPER_OPEN = 90.0
GRIPPER_CLOSED = 180.0   # lower to ~170 if the servo strains on fruit

FRAME_W = 640
FRAME_H = 480

BASE_AT_LEFT_EDGE = 150.0   # swap these two if the base aims mirrored
BASE_AT_RIGHT_EDGE = 30.0

# --- CHANNEL 2 (ELBOW) SAFE LIMITS — the v5 protection -----------------
ELBOW_MIN = 60.0    # ch2 will NEVER be commanded below this
ELBOW_MAX = 150.0   # ch2 will NEVER be commanded above this (no more
                     # full-down slams; raise carefully if too shallow)

# --- TOP-DOWN PICK GEOMETRY ------------------------------------------
PICK_SHOULDER = 40.0         # held constant through the pick (no scoop)
PICK_ELBOW_HOVER = 120.0     # claw above the object
PICK_ELBOW_DOWN_NEAR = 145.0  # DEPTH (object at bottom of image)
PICK_ELBOW_DOWN_FAR  = 145.0  # DEPTH (object at top of image)

# --- PER-FRUIT WRIST (set at approach, BEFORE lowering) ---------------
WRIST_PITCH_BY_FRUIT = {"apple": 30.0, "banana": 30.0, "orange": 30.0}
WRIST_ROTATE_BY_FRUIT = {"apple": 90.0, "banana": 0.0, "orange": 90.0}

CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
DROP_SHOULDER = 65.0
DROP_ELBOW = 65.0
DROP_WRIST = 45.0

# --- DETECTION LABEL MAPPING ------------------------------------------
LABEL_MAP = {
    "apple": "apple", "sports ball": "apple", "frisbee": "apple",
    "banana": "banana", "mouse": "banana", "bird": "banana",
    "orange": "orange",
}
FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}

# --- ACCURACY ----------------------------------------------------------
PICK_OFFSET_X_PX = 0
PICK_OFFSET_Y_PX = 0
CONFIDENCE_MIN = 0.35
PICK_CONFIDENCE_MIN = 0.35
STABLE_HITS = 3          # frames a target must persist before locking
COOLDOWN_S = 5.0

# --- STAGED MOTION / SPEEDS (deg per 20 ms MCU tick) ------------------
TRAVEL_STEP_DEG = 0.8     # ~40 deg/s: to drop boxes / home (safe & quick)
APPROACH_STEP_DEG = 0.5   # ~25 deg/s: aiming and moving above the object
PRECISE_STEP_DEG = 0.3    # ~15 deg/s: lowering, gripping, lifting
APPROACH_PAUSE_S = 0.8    # pause above the object before lowering
GRIP_SETTLE_S = 0.6       # pause after closing so the claw truly holds

# --- PICKUP VERIFICATION ----------------------------------------------
VERIFY_WAIT_S = 2.5       # watch the camera this long after lifting
VERIFY_RADIUS_PX = 70     # "still at origin" = same-category detection
                           # within this radius of the original spot
VERIFY_FAIL_HITS = 2      # frames-at-origin needed to declare failure
MAX_PICK_ATTEMPTS = 3     # total tries before giving up (no endless loop)

MOVE_TIMEOUT_S = 25.0
POLL_S = 0.1

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_coord_hist = deque(maxlen=STABLE_HITS)
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0

_log_lines = deque(maxlen=40)
_ui_items = []
_ui_items_ts = 0.0

# verification sampling (written by the pick thread, read by callback)
_verify_active = False
_verify_category = None
_verify_origin = (0, 0)
_verify_frames = 0
_verify_hits = 0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


# ======================================================================
# VISION -> ARM MAPPING
# ======================================================================
def base_angle_for_cx(cx: int) -> float:
    frac = min(max(cx / float(FRAME_W), 0.0), 1.0)
    ang = BASE_AT_LEFT_EDGE + frac * (BASE_AT_RIGHT_EDGE - BASE_AT_LEFT_EDGE)
    lo, hi = sorted((BASE_AT_LEFT_EDGE, BASE_AT_RIGHT_EDGE))
    return min(max(ang, lo), hi)


def elbow_down_for_cy(cy: int) -> float:
    t = min(max(cy / float(FRAME_H), 0.0), 1.0)
    return PICK_ELBOW_DOWN_FAR + t * (PICK_ELBOW_DOWN_NEAR - PICK_ELBOW_DOWN_FAR)


def apply_offsets(cx: float, cy: float):
    ox = min(max(cx + PICK_OFFSET_X_PX, 0), FRAME_W)
    oy = min(max(cy + PICK_OFFSET_Y_PX, 0), FRAME_H)
    return int(ox), int(oy)


def clamp_elbow(angle: float) -> float:
    """v5 core protection: ch2 can never leave [ELBOW_MIN, ELBOW_MAX]."""
    clamped = min(max(angle, ELBOW_MIN), ELBOW_MAX)
    if clamped != angle:
        log(f"[CLAMP] ch2 request {angle:.0f} -> {clamped:.0f} "
            f"(limits {ELBOW_MIN:.0f}-{ELBOW_MAX:.0f})")
    return clamped


# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def move_and_wait(base, shoulder, elbow, wrist, wrot, grip) -> None:
    """Single chokepoint for ALL motion — ch2 is clamped here, so no
    caller can bypass the elbow limits."""
    elbow = clamp_elbow(elbow)
    ok = Bridge.call("move_all", float(base), float(shoulder), float(elbow),
                     float(wrist), float(wrot), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > MOVE_TIMEOUT_S:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def set_speed(deg_per_tick: float) -> None:
    try:
        Bridge.call("set_speed", float(deg_per_tick))
    except Exception as exc:  # noqa: BLE001
        log(f"[WARN] set_speed failed: {exc}")


# ======================================================================
# PICKUP VERIFICATION
# ======================================================================
def verify_pickup(category: str, origin) -> bool:
    """Watch several camera frames after lifting. If the object is still
    detected at its original spot, the pickup failed. Not-visible-there
    counts as success (the held fruit / arm occludes the view)."""
    global _verify_active, _verify_category, _verify_origin
    global _verify_frames, _verify_hits
    _verify_category = category
    _verify_origin = origin
    _verify_frames = 0
    _verify_hits = 0
    _verify_active = True
    time.sleep(VERIFY_WAIT_S)
    _verify_active = False
    failed = _verify_hits >= VERIFY_FAIL_HITS
    log(f"[VERIFY] {_verify_frames} frames watched, {_verify_hits} still "
        f"at origin -> {'FAILED' if failed else 'PICKED OK'}")
    return not failed


def latest_target(category: str, max_age_s: float = 3.0):
    """Freshest detection of the given category, for retry realignment."""
    if not _ui_items or time.monotonic() - _ui_items_ts > max_age_s:
        return None
    best = None
    for it in _ui_items:
        if it.get("target") and it.get("fruit") == category:
            if best is None or it["confidence"] > best["confidence"]:
                best = it
    if best is None:
        return None
    return apply_offsets(best["cx"], best["cy"])


# ======================================================================
# PICK AND PLACE (staged, verified, retried)
# ======================================================================
def pick_and_place(fruit: str, coords, conf: float) -> None:
    global _state, _last_pick_done
    b = 90.0
    wr = 90.0
    try:
        aim = coords
        wp = WRIST_PITCH_BY_FRUIT.get(fruit, 30.0)
        wr = WRIST_ROTATE_BY_FRUIT.get(fruit, 90.0)
        picked = False

        for attempt in range(1, MAX_PICK_ATTEMPTS + 1):
            cx, cy = aim
            b = base_angle_for_cx(cx)
            ed = elbow_down_for_cy(cy)

            _state = f"picking {fruit} (attempt {attempt})"
            log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) attempt "
                f"{attempt}/{MAX_PICK_ATTEMPTS} at ({cx},{cy}), conf={conf:.2f}")
            log(f"[AIM] base {b:.0f} | elbow-down {ed:.0f} | wrist "
                f"pitch {wp:.0f} rotate {wr:.0f}")

            # STAGE 1: aim the base while upright (approach speed)
            set_speed(APPROACH_STEP_DEG)
            move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0, GRIPPER_OPEN)
            # STAGE 2: move directly above the object; wrist reaches its
            # per-fruit alignment HERE, before any lowering
            move_and_wait(b, PICK_SHOULDER, PICK_ELBOW_HOVER, wp, wr, GRIPPER_OPEN)
            # STAGE 3: pause — approach confirmed (move_and_wait only
            # returns once the MCU reports all servos arrived)
            log("[STAGE] aligned above object — pausing before descent")
            time.sleep(APPROACH_PAUSE_S)

            # STAGE 4: lower slowly — ONLY the elbow moves (vertical)
            set_speed(PRECISE_STEP_DEG)
            move_and_wait(b, PICK_SHOULDER, ed, wp, wr, GRIPPER_OPEN)
            # STAGE 5: close, and pause so the claw truly holds
            move_and_wait(b, PICK_SHOULDER, ed, wp, wr, GRIPPER_CLOSED)
            time.sleep(GRIP_SETTLE_S)
            # STAGE 6: lift slowly back to hover
            move_and_wait(b, PICK_SHOULDER, PICK_ELBOW_HOVER, wp, wr, GRIPPER_CLOSED)
            set_speed(TRAVEL_STEP_DEG)

            # STAGE 7: verify via camera before going anywhere
            _state = f"verifying {fruit}"
            if verify_pickup(fruit, aim):
                picked = True
                break

            # FAILED: release, realign from a fresh detection, retry
            log(f"[RETRY] object still at origin — reopening claw "
                f"(attempt {attempt}/{MAX_PICK_ATTEMPTS})")
            set_speed(APPROACH_STEP_DEG)
            move_and_wait(b, PICK_SHOULDER, PICK_ELBOW_HOVER, wp, wr, GRIPPER_OPEN)
            fresh = latest_target(fruit)
            if fresh is not None:
                aim = fresh
                log(f"[RETRY] corrected alignment to fresh detection {aim}")
            else:
                log("[RETRY] no fresh detection visible — retrying same spot")

        if not picked:
            log(f"[FAIL] could not pick {fruit} after "
                f"{MAX_PICK_ATTEMPTS} attempts — returning home, NOT dropping")
            move_and_wait(*HOME)
            return

        # SUCCESS: carry to the fixed box (travel speed), drop, home
        _state = f"placing {fruit}"
        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr, GRIPPER_CLOSED)
        box = BOX_BASE_ANGLE[fruit]
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, wr, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, wr, GRIPPER_OPEN)
        time.sleep(GRIP_SETTLE_S)
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0, GRIPPER_OPEN)
        move_and_wait(*HOME)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_and_wait(*HOME)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        set_speed(TRAVEL_STEP_DEG)
        _state = "idle"
        _last_pick_done = time.monotonic()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log, _ui_items, _ui_items_ts, _verify_frames, _verify_hits
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = []
                for l in _last_labels:
                    mapped = LABEL_MAP.get(l)
                    if mapped is None:
                        parts.append(f"{l} (ignored)")
                    elif mapped != l:
                        parts.append(f"{l}->{mapped}")
                    else:
                        parts.append(l)
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        items = []
        for label, instances in (results or {}).items():
            raw = str(label).lower()
            mapped = LABEL_MAP.get(raw)
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                items.append({
                    "fruit": mapped or raw,
                    "raw": raw,
                    "target": mapped is not None,
                    "color": FRUIT_COLOR.get(mapped) if mapped else None,
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if mapped is not None and (best is None or conf > best[2]):
                    best = (mapped, (cx, cy), conf)

        _ui_items = items
        _ui_items_ts = now

        # verification sampling window (set by the pick thread)
        if _verify_active and _verify_category:
            _verify_frames += 1
            ox, oy = _verify_origin
            r2 = VERIFY_RADIUS_PX * VERIFY_RADIUS_PX
            for it in items:
                if it["target"] and it["fruit"] == _verify_category:
                    dx, dy = it["cx"] - ox, it["cy"] - oy
                    if dx * dx + dy * dy <= r2:
                        _verify_hits += 1
                        break

        if best is None:
            _stable_label, _stable_count = None, 0
            _coord_hist.clear()
            return

        label, coords, conf = best
        if label == _stable_label:
            _stable_count += 1
            _coord_hist.append(coords)
        else:
            _stable_label, _stable_count = label, 1
            _coord_hist.clear()
            _coord_hist.append(coords)

        if _stable_count < STABLE_HITS:
            return
        if conf < PICK_CONFIDENCE_MIN:
            return
        if _busy.is_set():
            return   # target locked — no switching mid-pick
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        avg_cx = sum(c[0] for c in _coord_hist) / len(_coord_hist)
        avg_cy = sum(c[1] for c in _coord_hist) / len(_coord_hist)
        aim = apply_offsets(avg_cx, avg_cy)

        if not _arm_enabled:
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                bb = base_angle_for_cx(aim[0])
                log(f"[ARM DISABLED] would pick {label} at {aim} -> base "
                    f"{bb:.0f} deg. Press 'Enable Arm' on the page to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        _coord_hist.clear()
        threading.Thread(target=pick_and_place, args=(label, aim, conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested from web page")
    return {"ok": True}


def api_test_servos():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    _busy.set()

    def _wait_done(timeout=10.0):
        t0 = time.monotonic()
        while not Bridge.call("is_motion_complete"):
            if time.monotonic() - t0 > timeout:
                raise RuntimeError("timeout")
            time.sleep(POLL_S)

    def _run():
        names = ["0 = base", "1 = shoulder", "2 = elbow",
                 "3 = wrist pitch", "4 = wrist rotate", "5 = GRIPPER/claw"]
        try:
            log("[TEST] Servo sweep — watch which joint moves per channel.")
            for ch in range(6):
                log(f"[TEST] testing channel {names[ch]} ...")
                for target in (60.0, 120.0, 90.0):
                    if ch == 2:
                        target = clamp_elbow(target)
                    if not Bridge.call("move_servo", ch, target):
                        raise RuntimeError(f"MCU rejected move on ch {ch}")
                    _wait_done()
                time.sleep(0.4)
            log("[TEST] Sweep done. Returning to HOME.")
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] servo test failed: {exc}")
        finally:
            _busy.clear()

    threading.Thread(target=_run, daemon=True).start()
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)
ui.expose_api("GET", "/api/test_servos", api_test_servos)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 10.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


_stream_info = None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)
    candidates = [
        (4912, "/"), (4912, "/stream"), (4912, "/video"),
        (4912, "/mjpeg"), (4912, "/feed"), (5050, "/"),
    ]
    found = 0
    for port, path in candidates:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            status = getattr(resp, "status", 200)
            resp.close()
            if status == 200:
                found += 1
                log(f"[STREAM PROBE] FOUND: port {port} path {path} ({ctype})")
                if _stream_info is None:
                    _stream_info = {"port": port, "path": path,
                                    "content_type": ctype}
        except Exception:
            pass
    if found == 0:
        log("[STREAM PROBE] no raw stream found on common ports — the "
            "Live Detection View IS your live view.")
    else:
        log("[STREAM PROBE] open 'Raw camera stream' on the page to view it.")


threading.Thread(target=_probe_stream, daemon=True).start()

log(f"Fruit sorter {VERSION} started. ARM IS DISABLED — verify aiming on "
    f"the page, then press 'Enable Arm'.")

App.run()
