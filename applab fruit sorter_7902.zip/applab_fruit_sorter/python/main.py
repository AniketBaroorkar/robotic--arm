"""
main.py — Fruit Sorting Robot v7 (Arduino App Lab)
===================================================
v7 changes:
  1. CAMERA INVERSION: the camera and arm face each other, so image X
     is mirrored relative to the arm. INVERT_CAMERA_X / INVERT_CAMERA_Y
     flags correct the coordinates BEFORE any robot math; the raw
     coordinates are never used for base/shoulder/elbow after that.
     (The web page canvas still draws in raw image space, as it must.)
  2. STABILIZATION: the target must stay within POSITION_TOLERANCE_PIXELS
     of the running MEDIAN for STABLE_FRAMES consecutive frames before
     anything moves; the MEDIAN of those frames becomes the locked
     position for the whole pickup.
  3. DROP DEPTH = PICKUP DEPTH: the exact pickup elbow angle is saved
     when the claw grips, and the drop lowers to that same depth (slow,
     PRECISE speed) before the claw opens. No releasing from high up;
     vertical lift after release.
  4/5. CLAW FULLY ISOLATED: closing/opening commands ONLY the gripper
     channel (move_servo ch5). All arm joints are saved as locked poses
     and receive no commands while the claw operates — channel 3
     included: it is impossible for it to be re-commanded during the
     close, the grip pause, or verification.
  6. LOCKED POSES: approach/pickup/lift/drop poses are computed ONCE per
     attempt after stabilization and stored; no position math runs while
     lowering, closing, or lifting.
"""

import statistics
import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v11.3-smooth"

# ======================================================================
# CALIBRATION
# Servo order: [base(0), shoulder(1), elbow(2), wrist_pitch(3),
#               wrist_rotate(4), gripper(5)]
# ======================================================================
GRIPPER_CH = 5
GRIPPER_OPEN = 90.0
GRIPPER_CLOSED = 180.0

FRAME_W = 640
FRAME_H = 480

# --- CAMERA AXIS INVERSION (camera and arm FACE EACH OTHER) -----------
INVERT_CAMERA_X = True    # mirrors left/right: corrected_x = W - x
INVERT_CAMERA_Y = True    # CONFIRMED for the built layout: camera faces
                           # the arm, so the box edge NEAREST the camera
                           # (bottom of image) is the FARTHEST reach for
                           # the arm. If you ever move the camera behind
                           # the arm instead, set this back to False.

# --- BASE CALIBRATION --------------------------------------------------
CAMERA_X_OFFSET = 0.0
CAMERA_Y_OFFSET = 0.0
ROBOT_X_OFFSET = 0.0
ROBOT_Y_OFFSET = 0.0
BASE_CENTER_ANGLE = 90.0
BASE_X_SCALE = -0.12      # deg per px, RE-DERIVED for the 30 cm box
                           # distance: at 30 cm radius each lateral cm is
                           # only ~1.9 deg of base (half of the 15 cm
                           # case), so ~0.12 deg/px. This fixes the arm
                           # over-rotating and reaching OUTSIDE the box.
                           # Fine-tune ±0.03; flip sign if mirrored.
BASE_MIN_ANGLE = 30.0     # PICK-AIM WINDOW: with the arm at the zone's
BASE_MAX_ANGLE = 150.0    # top-right CORNER the base sweeps ~90 deg
                           # across the zone, so the window is wide.
                           # (Colored boxes use fixed angles, unaffected.)

# --- CHANNEL 2 (ELBOW) SAFE LIMITS ------------------------------------
ELBOW_MIN = 60.0
ELBOW_MAX = 150.0
VERTICAL_DESCENT_STEPS = 3

# --- CAMERA-SAFE TRAVEL (arm 54 cm tall, camera only 39 cm high!) -----
# The upright arm is TALLER than the overhead camera, so the arm must
# NEVER rotate while upright. Channels 2+3 fold DOWN first, base
# rotates in the folded posture, and only then does the arm unfold.
TRAVEL_SHOULDER = 60.0  # CROUCH, not upright: raising the shoulder to 90
                         # while still over the zone is what hit the
                         # camera after lifting. The arm now stays low
                         # and compact for every rotation; it only goes
                         # fully upright at HOME (its own spot).
TRAVEL_ELBOW = 145.0    # forearm tucked tight against the upper arm
TRAVEL_WRIST = 30.0

# --- 4-CORNER CALIBRATION (the accuracy fix) --------------------------
# Maps what the camera SAW (raw pixel, as shown on the web page) to
# angles that WORKED, measured at the four corners of the box. Every
# position in between is interpolated. This absorbs perspective, the
# mirrored camera, and the arm's kinematics in one table — no formulas.
#
# CALIBRATION PROCEDURE (one time, ~15 min):
#   For EACH corner of the box:
#   1. Put a fruit exactly at that corner.
#   2. Read its (x, y) from the web page "Coordinates" row -> type it
#      into that corner's "px" below.
#   3. Run a pick; watch where the claw lands vs the fruit.
#   4. Nudge that corner's base (left/right) and down shoulder/elbow
#      (reach/depth) by a few degrees; repeat until it lands on it.
#   Corners are named from the ARM's point of view.
USE_CORNER_CALIBRATION = True   # False = fall back to the linear formula
CAL_POINTS = {
    # Corner pixels MEASURED on this setup (overhead camera at 39 cm).
    # Image-X = distance from the arm (x~600 near arm, x~47 far).
    # Image-Y = lateral (y~32-47 = side A, y~398-422 = side B).
    # Base angles below are PREFILLS — tune each corner per the procedure.
    "near_A": {"px": (587, 32),  "base": 110.0,   # beside the arm
               "hover": (42.0, 108.0), "down": (52.0, 139.0)},
    "near_B": {"px": (608, 398), "base": 60.0,    # down the right edge
               "hover": (42.0, 108.0), "down": (52.0, 139.0)},
    "far_A":  {"px": (50, 47),   "base": 135.0,   # along the top edge
               "hover": (30.0, 100.0), "down": (42.0, 134.0)},
    "far_B":  {"px": (44, 422),  "base": 95.0,    # far diagonal (~43cm — may be OUT OF REACH)
               "hover": (30.0, 100.0), "down": (42.0, 134.0)},
}
# The px values are YOUR measured readings. Direction check (arm
# disabled): fruit on the ARM'S LEFT must log base > 90; if reversed,
# swap the base prefills between the _A and _B corners.

# --- RE-AIM AT HOVER (closed-loop refinement) -------------------------
REFINE_ENABLED = True
REFINE_MIN_PX = 25     # re-aim only if the fruit moved at least this far
REFINE_MAX_PX = 150    # ...but ignore absurd jumps (mis-detection)

# --- VERTICAL PICK: calibrated HOVER/DOWN pose PAIRS ------------------
# A single joint moves the claw along an ARC, never a straight line —
# that was the back/front drift during descent. The fix: each descent
# is a coordinated move between a HOVER pose and a DOWN pose whose claw
# positions are vertically aligned. The shoulder leans slightly BACK
# (bigger number) while the elbow extends, cancelling the forward
# swing. The MCU moves both joints synchronized (they arrive together).
#
# CALIBRATION RULE (per pair): watch one slow descent —
#   claw drifts FORWARD (toward camera) -> INCREASE the DOWN shoulder
#   claw drifts BACKWARD (toward arm)   -> DECREASE the DOWN shoulder
#   too high / too deep                 -> tune the DOWN elbow
# NEAR = box edge nearest the ARM, FAR = edge nearest the CAMERA.
PICK_HOVER_NEAR = {"shoulder": 42.0, "elbow": 108.0}
PICK_DOWN_NEAR  = {"shoulder": 52.0, "elbow": 145.0}
PICK_HOVER_FAR  = {"shoulder": 30.0, "elbow": 100.0}
PICK_DOWN_FAR   = {"shoulder": 42.0, "elbow": 140.0}

# --- PER-FRUIT WRIST ---------------------------------------------------
WRIST_PITCH_BY_FRUIT = {"apple": 30.0, "banana": 30.0, "orange": 30.0}
WRIST_ROTATE_NORMAL = 90.0
WRIST_ROTATE_BANANA = 0.0
BANANA_VERTICAL_RATIO = 1.25

CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
# Drop descent is a vertical pose pair as well (same physics):
DROP_HOVER_POSE = {"shoulder": 60.0, "elbow": 105.0}
DROP_DOWN_POSE  = {"shoulder": 68.0, "elbow": 140.0}
DROP_WRIST = 45.0
BANANA_DROP_LOWER_OFFSET = 0.0   # extra elbow on the banana drop only;
                                  # ch2 clamp caps the total either way

# --- DETECTION LABEL MAPPING ------------------------------------------
LABEL_MAP = {
    "apple": "apple", "sports ball": "apple", "frisbee": "apple",
    "banana": "banana", "mouse": "banana", "bird": "banana",
    "orange": "orange",
}
FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}

# --- STABILIZATION / ACCURACY -----------------------------------------
PICK_OFFSET_X_PX = 0
PICK_OFFSET_Y_PX = 0
CONFIDENCE_MIN = 0.35             # brick detection threshold (display)
MIN_DETECTION_CONFIDENCE = 0.35   # required to trigger a pick
STABLE_FRAMES = 4                 # consecutive in-tolerance frames
POSITION_TOLERANCE_PIXELS = 25    # max deviation from the running median
COOLDOWN_S = 5.0

# --- STAGED MOTION / SPEEDS (deg per 20 ms MCU tick) ------------------
TRAVEL_STEP_DEG = 0.8
APPROACH_STEP_DEG = 0.5
PRECISE_STEP_DEG = 0.3
APPROACH_PAUSE_S = 0.8
GRIP_SETTLE_S = 0.6

# --- PICKUP VERIFICATION ----------------------------------------------
VERIFY_WAIT_S = 2.5
VERIFY_RADIUS_PX = 70
VERIFY_FAIL_HITS = 2
# (no retries: one attempt per detection; a failed pick releases, goes
# home, and waits for the next detection cycle)

MOVE_TIMEOUT_S = 25.0
POLL_S = 0.1

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_hist = deque(maxlen=STABLE_FRAMES)   # (cx, cy, w, h) raw image coords
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0

_log_lines = deque(maxlen=40)
_ui_items = []
_ui_items_ts = 0.0

_verify_active = False
_verify_category = None
_verify_origin = (0, 0)   # RAW image coords (compared to raw detections)
_verify_frames = 0
_verify_hits = 0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


# ======================================================================
# VISION -> ROBOT MAPPING (all robot math uses CORRECTED coordinates)
# ======================================================================
def correct_camera(cx: float, cy: float):
    """Apply the face-to-face camera inversion. Everything downstream of
    this uses only the corrected values."""
    x = (FRAME_W - cx) if INVERT_CAMERA_X else cx
    y = (FRAME_H - cy) if INVERT_CAMERA_Y else cy
    return x, y


def apply_offsets(cx: float, cy: float):
    ox = min(max(cx + PICK_OFFSET_X_PX, 0), FRAME_W)
    oy = min(max(cy + PICK_OFFSET_Y_PX, 0), FRAME_H)
    return ox, oy


def camera_to_robot(cx: float, cy: float):
    rx = (cx - FRAME_W / 2.0 - CAMERA_X_OFFSET) + ROBOT_X_OFFSET
    ry = (FRAME_H - cy - CAMERA_Y_OFFSET) + ROBOT_Y_OFFSET
    return rx, ry


def base_angle_for(rx: float) -> float:
    ang = BASE_CENTER_ANGLE + rx * BASE_X_SCALE
    return min(max(ang, BASE_MIN_ANGLE), BASE_MAX_ANGLE)


def pick_pose_for(ry: float):
    """Y -> forward distance: interpolate BOTH the hover pose and the
    down pose between their NEAR and FAR calibrations. Each returned
    pair is vertically aligned, so hover->down is a straight descent."""
    t = min(max(ry / float(FRAME_H), 0.0), 1.0)

    def lerp(near_v, far_v):
        return near_v + t * (far_v - near_v)

    hover = (lerp(PICK_HOVER_NEAR["shoulder"], PICK_HOVER_FAR["shoulder"]),
             lerp(PICK_HOVER_NEAR["elbow"], PICK_HOVER_FAR["elbow"]))
    down = (lerp(PICK_DOWN_NEAR["shoulder"], PICK_DOWN_FAR["shoulder"]),
            lerp(PICK_DOWN_NEAR["elbow"], PICK_DOWN_FAR["elbow"]))
    return hover, down


def plan_pick(raw_cx: float, raw_cy: float):
    """Raw image center -> (base, hover_pose, down_pose). The ONLY place
    position math happens; called once per attempt (locked poses)."""
    if USE_CORNER_CALIBRATION:
        return plan_pick_calibrated(raw_cx, raw_cy)
    ccx, ccy = correct_camera(raw_cx, raw_cy)
    ccx, ccy = apply_offsets(ccx, ccy)
    rx, ry = camera_to_robot(ccx, ccy)
    hover, down = pick_pose_for(ry)
    return base_angle_for(rx), hover, down


def plan_pick_calibrated(raw_cx: float, raw_cy: float):
    """Inverse-distance-weighted interpolation over the 4 calibrated
    corners, in RAW pixel space (exactly what the page displays). Exact
    at each corner; smooth in between."""
    num_b = num_hs = num_he = num_ds = num_de = den = 0.0
    for c in CAL_POINTS.values():
        dx = raw_cx - c["px"][0]
        dy = raw_cy - c["px"][1]
        d2 = dx * dx + dy * dy
        if d2 < 1.0:            # standing on a corner -> use it exactly
            return (min(max(c["base"], BASE_MIN_ANGLE), BASE_MAX_ANGLE),
                    c["hover"], c["down"])
        w = 1.0 / d2
        num_b += w * c["base"]
        num_hs += w * c["hover"][0]; num_he += w * c["hover"][1]
        num_ds += w * c["down"][0];  num_de += w * c["down"][1]
        den += w
    b = min(max(num_b / den, BASE_MIN_ANGLE), BASE_MAX_ANGLE)
    return b, (num_hs / den, num_he / den), (num_ds / den, num_de / den)


def latest_target(category: str, max_age_s: float = 3.0):
    """Freshest detection of the category -> (cx, cy, w, h)."""
    if not _ui_items or time.monotonic() - _ui_items_ts > max_age_s:
        return None
    best = None
    for it in _ui_items:
        if it.get("target") and it.get("fruit") == category:
            if best is None or it["confidence"] > best["confidence"]:
                best = it
    if best is None:
        return None
    x1, y1, x2, y2 = best["box"]
    return best["cx"], best["cy"], (x2 - x1), (y2 - y1)


def clamp_elbow(angle: float) -> float:
    clamped = min(max(angle, ELBOW_MIN), ELBOW_MAX)
    if clamped != angle:
        log(f"[CLAMP] ch2 request {angle:.0f} -> {clamped:.0f} "
            f"(limits {ELBOW_MIN:.0f}-{ELBOW_MAX:.0f})")
    return clamped


BANANA_TWIST_WHEN_VERTICAL = True  # overhead camera: VERTICAL banana
                                    # twists the claw; horizontal does NOT.
                                    # (Set False to flip back.)


def banana_wrist_rotate(w: float, h: float) -> float:
    """Orientation-aware wrist for the overhead camera: a VERTICAL
    banana (tall box) twists the claw; a horizontal one does not."""
    if w <= 0 or h <= 0:
        return WRIST_ROTATE_NORMAL
    is_vertical = h >= w * BANANA_VERTICAL_RATIO
    twist = is_vertical if BANANA_TWIST_WHEN_VERTICAL else (not is_vertical)
    if twist:
        log(f"[ORIENT] banana box {w:.0f}x{h:.0f} -> "
            f"{'VERTICAL' if is_vertical else 'horizontal'} -> TWIST "
            f"{WRIST_ROTATE_BANANA:.0f}")
        return WRIST_ROTATE_BANANA
    log(f"[ORIENT] banana box {w:.0f}x{h:.0f} -> "
        f"{'VERTICAL' if is_vertical else 'horizontal'} -> no twist "
        f"{WRIST_ROTATE_NORMAL:.0f}")
    return WRIST_ROTATE_NORMAL


# ======================================================================
# MOTION# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def wait_motion(timeout: float = MOVE_TIMEOUT_S) -> None:
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > timeout:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


_cur_base = 90.0   # last commanded base angle (sketch boots at 90)


def move_pose(pose, grip) -> None:
    """pose = (base, shoulder, elbow, wrist_pitch, wrist_rotate)."""
    global _cur_base
    b, sh, el, wp, wr = pose
    el = clamp_elbow(el)
    ok = Bridge.call("move_all", float(b), float(sh), float(el),
                     float(wp), float(wr), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    wait_motion()
    _cur_base = float(b)


def go_travel(target_base: float, grip: float) -> None:
    """CAMERA-SAFE SEQUENTIAL FOLD (arm 54 cm, camera 39 cm):
       1. ch3 (wrist pitch) bends down FIRST — the very top of the arm
          tucks in before anything else moves
       2. ch4 (wrist rotate) returns to neutral
       3. elbow folds the forearm down (whole arm now under the camera)
       4. only then does the base rotate, still folded
    Each step fully completes before the next begins."""
    single_servo(3, TRAVEL_WRIST)     # 1. wrist pitch first
    single_servo(4, 90.0)             # 2. then wrist rotate
    move_pose((_cur_base, TRAVEL_SHOULDER, TRAVEL_ELBOW, TRAVEL_WRIST, 90.0), grip)  # 3. elbow fold
    if abs(target_base - _cur_base) > 0.5:
        move_pose((target_base, TRAVEL_SHOULDER, TRAVEL_ELBOW, TRAVEL_WRIST, 90.0), grip)  # 4. rotate folded


def single_servo(ch: int, angle: float) -> None:
    """Move ONE channel only; every other joint receives no command."""
    if ch == 2:
        angle = clamp_elbow(angle)
    if not Bridge.call("move_servo", ch, float(angle)):
        raise RuntimeError(f"MCU rejected move on ch {ch} (E-STOP active?)")
    wait_motion()


def gripper_only(angle: float) -> None:
    single_servo(GRIPPER_CH, angle)


def set_speed(deg_per_tick: float) -> None:
    try:
        Bridge.call("set_speed", float(deg_per_tick))
    except Exception as exc:  # noqa: BLE001
        log(f"[WARN] set_speed failed: {exc}")


# ======================================================================
# PICKUP VERIFICATION (raw image coords)
# ======================================================================
def verify_pickup(category: str, origin_raw) -> bool:
    global _verify_active, _verify_category, _verify_origin
    global _verify_frames, _verify_hits
    _verify_category = category
    _verify_origin = origin_raw
    _verify_frames = 0
    _verify_hits = 0
    _verify_active = True
    time.sleep(VERIFY_WAIT_S)
    _verify_active = False
    failed = _verify_hits >= VERIFY_FAIL_HITS
    log(f"[VERIFY] {_verify_frames} frames watched, {_verify_hits} still "
        f"at origin -> {'FAILED' if failed else 'PICKED OK'}")
    return not failed


# ======================================================================
# PICK AND PLACE (locked poses; claw isolated)
# ======================================================================
def pick_and_place(fruit: str, raw_aim, dims, conf: float) -> None:
    global _state, _last_pick_done
    try:
        w, h = dims
        wp = WRIST_PITCH_BY_FRUIT.get(fruit, 30.0)

        def build(point, bw, bh):
            """All locked poses for one aim point (the ONLY pose math)."""
            b, hover, down = plan_pick(point[0], point[1])
            wr = banana_wrist_rotate(bw, bh) if fruit == "banana" else WRIST_ROTATE_NORMAL
            steps = []
            for i in range(1, VERTICAL_DESCENT_STEPS + 1):
                f = i / VERTICAL_DESCENT_STEPS
                steps.append((b,
                              hover[0] + f * (down[0] - hover[0]),
                              hover[1] + f * (down[1] - hover[1]),
                              wp, wr))
            return {
                "b": b, "hover": hover, "down": down, "wr": wr,
                "aim": (b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0),
                "approach": (b, hover[0], hover[1], wp, wr),
                "descent": steps,
            }

        P = build(raw_aim, w, h)
        b, wr = P["b"], P["wr"]
        aim_pose, approach_pose, descent = P["aim"], P["approach"], P["descent"]
        hover, down = P["hover"], P["down"]

        _state = f"picking {fruit}"
        log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) raw={raw_aim} conf={conf:.2f}")
        log(f"[LOCK] base {b:.0f} | hover S{hover[0]:.0f}/E{hover[1]:.0f} -> "
            f"down S{down[0]:.0f}/E{down[1]:.0f} | wrist p{wp:.0f} r{wr:.0f}")

        set_speed(APPROACH_STEP_DEG)
        go_travel(b, GRIPPER_OPEN)                 # 1. FOLD, then rotate
        move_pose(approach_pose, GRIPPER_OPEN)     # 2. unfold into hover
        log("[STAGE] aligned above object — pausing")
        time.sleep(APPROACH_PAUSE_S)               # 3. pause

        # 3b. RE-AIM: one fresh look before committing to the descent
        if REFINE_ENABLED:
            fresh = latest_target(fruit)
            if fresh is not None:
                dx = fresh[0] - raw_aim[0]
                dy = fresh[1] - raw_aim[1]
                dist = (dx * dx + dy * dy) ** 0.5
                if REFINE_MIN_PX <= dist <= REFINE_MAX_PX:
                    raw_aim = (fresh[0], fresh[1])
                    P = build(raw_aim, fresh[2], fresh[3])
                    b, wr = P["b"], P["wr"]
                    approach_pose, descent = P["approach"], P["descent"]
                    hover, down = P["hover"], P["down"]
                    log(f"[REFINE] fruit moved {dist:.0f}px — re-aimed to "
                        f"{raw_aim}, base {b:.0f}")
                    move_pose(approach_pose, GRIPPER_OPEN)
                    time.sleep(0.4)

        set_speed(PRECISE_STEP_DEG)
        log(f"[STAGE] vertical descent ({VERTICAL_DESCENT_STEPS} steps)")
        for pose in descent:                       # 4. straight DOWN
            move_pose(pose, GRIPPER_OPEN)
        log("[STAGE] arm locked — closing claw only (no joint commands)")
        gripper_only(GRIPPER_CLOSED)               # 5. close
        time.sleep(GRIP_SETTLE_S)                  # 6. hold
        log("[STAGE] vertical lift")
        for pose in reversed(descent[:-1]):        # 7. straight UP
            move_pose(pose, GRIPPER_CLOSED)
        move_pose(approach_pose, GRIPPER_CLOSED)
        set_speed(TRAVEL_STEP_DEG)

        _state = f"verifying {fruit}"
        if not verify_pickup(fruit, raw_aim):      # 8. verify — NO retry
            log("[FAIL] pickup not verified — releasing, returning home, "
                "waiting for the next detection")
            set_speed(APPROACH_STEP_DEG)
            gripper_only(GRIPPER_OPEN)
            go_travel(90.0, GRIPPER_OPEN)
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
            return

        # ---- DROP: vertical pose-pair descent at the box --------------
        _state = f"placing {fruit}"
        box = BOX_BASE_ANGLE[fruit]
        d_elbow = DROP_DOWN_POSE["elbow"] + (
            BANANA_DROP_LOWER_OFFSET if fruit == "banana" else 0.0)
        drop_travel  = (box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr)
        drop_hover   = (box, DROP_HOVER_POSE["shoulder"], DROP_HOVER_POSE["elbow"], DROP_WRIST, wr)
        drop_release = (box, DROP_DOWN_POSE["shoulder"], d_elbow, DROP_WRIST, wr)
        log(f"[LOCK] drop: box {box:.0f}, release S{drop_release[1]:.0f}/"
            f"E{drop_release[2]:.0f}")

        go_travel(box, GRIPPER_CLOSED)             # 9. FOLD, rotate to box
        move_pose(drop_hover, GRIPPER_CLOSED)      # 10. above box
        set_speed(PRECISE_STEP_DEG)
        move_pose(drop_release, GRIPPER_CLOSED)    # 11. lower into box
        log("[STAGE] arm locked — opening claw only")
        gripper_only(GRIPPER_OPEN)                 # 12. open
        time.sleep(GRIP_SETTLE_S)
        move_pose(drop_hover, GRIPPER_OPEN)        # 13. lift
        set_speed(TRAVEL_STEP_DEG)
        go_travel(90.0, GRIPPER_OPEN)              # 14. fold, rotate to center
        move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)  # 15. home (upright at arm's own spot)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        set_speed(TRAVEL_STEP_DEG)
        _state = "idle"
        _last_pick_done = time.monotonic()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING (median + tolerance stabilization)
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log, _ui_items, _ui_items_ts, _verify_frames, _verify_hits
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = []
                for l in _last_labels:
                    mapped = LABEL_MAP.get(l)
                    if mapped is None:
                        parts.append(f"{l} (ignored)")
                    elif mapped != l:
                        parts.append(f"{l}->{mapped}")
                    else:
                        parts.append(l)
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        items = []
        for label, instances in (results or {}).items():
            raw = str(label).lower()
            mapped = LABEL_MAP.get(raw)
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                items.append({
                    "fruit": mapped or raw,
                    "raw": raw,
                    "target": mapped is not None,
                    "color": FRUIT_COLOR.get(mapped) if mapped else None,
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if mapped is not None and (best is None or conf > best[2]):
                    best = (mapped, (cx, cy, x2 - x1, y2 - y1), conf)

        _ui_items = items
        _ui_items_ts = now

        if _verify_active and _verify_category:
            _verify_frames += 1
            ox, oy = _verify_origin
            r2 = VERIFY_RADIUS_PX * VERIFY_RADIUS_PX
            for it in items:
                if it["target"] and it["fruit"] == _verify_category:
                    dx, dy = it["cx"] - ox, it["cy"] - oy
                    if dx * dx + dy * dy <= r2:
                        _verify_hits += 1
                        break

        if best is None:
            _stable_label, _stable_count = None, 0
            _hist.clear()
            return

        label, cinfo, conf = best
        if label != _stable_label:
            _stable_label, _stable_count = label, 1
            _hist.clear()
            _hist.append(cinfo)
            return

        # Tolerance check against the running MEDIAN (jitter rejection)
        med_cx = statistics.median(c[0] for c in _hist)
        med_cy = statistics.median(c[1] for c in _hist)
        if (abs(cinfo[0] - med_cx) > POSITION_TOLERANCE_PIXELS or
                abs(cinfo[1] - med_cy) > POSITION_TOLERANCE_PIXELS):
            # moved too much — restart stabilization from this sample
            _stable_count = 1
            _hist.clear()
            _hist.append(cinfo)
            return

        _stable_count += 1
        _hist.append(cinfo)

        if _stable_count < STABLE_FRAMES:
            return
        if conf < MIN_DETECTION_CONFIDENCE:
            return
        if _busy.is_set():
            return
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        # Locked position = MEDIAN of the stable window (raw coords)
        raw_aim = (int(statistics.median(c[0] for c in _hist)),
                   int(statistics.median(c[1] for c in _hist)))
        med_w = statistics.median(c[2] for c in _hist)
        med_h = statistics.median(c[3] for c in _hist)

        if not _arm_enabled:
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                bb, sh, ed = plan_pick(raw_aim[0], raw_aim[1])
                log(f"[ARM DISABLED] would pick {label} at raw {raw_aim} -> "
                    f"base {bb:.0f}, shoulder {sh:.0f}, elbow {ed:.0f}. "
                    f"Press 'Enable Arm' to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        _hist.clear()
        threading.Thread(target=pick_and_place,
                         args=(label, raw_aim, (med_w, med_h), conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            go_travel(90.0, GRIPPER_OPEN)
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested from web page")
    return {"ok": True}


def api_test_servos():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    _busy.set()

    def _run():
        names = ["0 = base", "1 = shoulder", "2 = elbow",
                 "3 = wrist pitch", "4 = wrist rotate", "5 = GRIPPER/claw"]
        try:
            log("[TEST] Servo sweep — watch which joint moves per channel.")
            for ch in range(6):
                log(f"[TEST] testing channel {names[ch]} ...")
                for target in (60.0, 120.0, 90.0):
                    if ch == 2:
                        target = clamp_elbow(target)
                    if not Bridge.call("move_servo", ch, target):
                        raise RuntimeError(f"MCU rejected move on ch {ch}")
                    wait_motion(10.0)
                time.sleep(0.4)
            log("[TEST] Sweep done. Returning to HOME.")
            move_pose((HOME[0], HOME[1], HOME[2], HOME[3], HOME[4]), GRIPPER_OPEN)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] servo test failed: {exc}")
        finally:
            _busy.clear()

    threading.Thread(target=_run, daemon=True).start()
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)
ui.expose_api("GET", "/api/test_servos", api_test_servos)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 20.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


_stream_info = None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)
    candidates = [
        (4912, "/"), (4912, "/stream"), (4912, "/video"),
        (4912, "/mjpeg"), (4912, "/feed"), (5050, "/"),
    ]
    found = 0
    for port, path in candidates:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            status = getattr(resp, "status", 200)
            resp.close()
            if status == 200:
                found += 1
                log(f"[STREAM PROBE] FOUND: port {port} path {path} ({ctype})")
                if _stream_info is None:
                    _stream_info = {"port": port, "path": path,
                                    "content_type": ctype}
        except Exception:
            pass
    if found == 0:
        log("[STREAM PROBE] no raw stream found on common ports — the "
            "Live Detection View IS your live view.")
    else:
        log("[STREAM PROBE] open 'Raw camera stream' on the page to view it.")


threading.Thread(target=_probe_stream, daemon=True).start()

log(f"Fruit sorter {VERSION} started. ARM IS DISABLED — verify aiming on "
    f"the page, then press 'Enable Arm'.")

App.run()
