"""
main.py — Fruit Sorting Robot v4 (Arduino App Lab) — TOP-DOWN PICK
===================================================================
v4 changes (per calibration session):
  1. Reduced picking depth (elbow down 150, was 170) — tune PICK_ELBOW_DOWN_*.
  2. TRUE top-down motion: the shoulder is FIXED during the descend;
     only the elbow lowers/lifts, so the claw travels vertically
     instead of scooping forward like a JCB.
  3. Wrist pitch (ch3) only ever moves to the configured per-fruit pick
     angle — smoothly, before the arm lowers. No fixed 180 anywhere.
  4. Accuracy: object CENTER used, coordinates AVERAGED over the stable
     frames before moving, X/Y calibration offsets available, and the
     target is locked once a pick starts (no mid-pick switching).
  5. Label mapping for toy fruits: sports ball & frisbee count as
     APPLE; mouse & bird count as BANANA; orange stays ORANGE; all
     other classes ignored.
  6. Per-fruit wrist: banana-type objects rotate the claw (ch4) to
     align with the long shape; round fruits use the normal angle.
     All configurable, applied at hover BEFORE lowering.
  7. Drop into the existing fixed colored-box positions by mapped
     category (apple→Red, banana→Yellow, orange→Orange).
"""

import threading
import time
from collections import deque

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.video_objectdetection import VideoObjectDetection

VERSION = "v4-topdown"

# ======================================================================
# CALIBRATION
# Servo order: [base, shoulder, elbow, wrist_pitch, wrist_rotate, gripper]
# ======================================================================
GRIPPER_OPEN = 90.0     # MEASURED: 90 = claw fully open
GRIPPER_CLOSED = 180.0  # MEASURED: 180 = claw fully closed (lower to ~170
                         # if the servo buzzes hard while holding a fruit)

FRAME_W = 640
FRAME_H = 480

# Base angle at LEFT edge of image vs RIGHT edge (interpolated).
# If the arm swings the wrong way, SWAP these two numbers.
BASE_AT_LEFT_EDGE = 150.0
BASE_AT_RIGHT_EDGE = 30.0

# --- TOP-DOWN PICK GEOMETRY ------------------------------------------
# The shoulder stays FIXED during the descend so the claw drops
# vertically (no scooping). Only the elbow moves down/up.
PICK_SHOULDER = 40.0        # forward lean, held constant through the pick
PICK_ELBOW_HOVER = 120.0    # claw hovering above the object
PICK_ELBOW_DOWN_NEAR = 150.0  # DEPTH KNOB (object at bottom of image).
PICK_ELBOW_DOWN_FAR  = 150.0  # DEPTH KNOB (object at top of image).
# Too low -> reduce toward 135-145. Not low enough -> raise toward 160-170.

# --- PER-FRUIT WRIST (applied at hover, BEFORE lowering) --------------
# ch3 = wrist pitch (claw tilt). ch4 = wrist rotate (claw jaw alignment).
WRIST_PITCH_BY_FRUIT = {
    "apple": 30.0,
    "banana": 30.0,
    "orange": 30.0,
}
WRIST_ROTATE_BY_FRUIT = {
    "apple": 90.0,    # round objects: normal claw orientation
    "banana": 0.0,    # long objects: claw rotated 90 deg to align with
                       # the banana's long axis — adjust if your banana
                       # usually lies at a different angle in the frame
    "orange": 90.0,
}

# Upright "carrying" pose used while rotating between positions:
CARRY_SHOULDER = 90.0
CARRY_ELBOW = 90.0
CARRY_WRIST = 90.0

# Fixed colored destination boxes (unchanged):
BOX_BASE_ANGLE = {"apple": 30.0, "banana": 60.0, "orange": 150.0}
DROP_SHOULDER = 65.0
DROP_ELBOW = 65.0
DROP_WRIST = 45.0

# --- DETECTION LABEL MAPPING (toy-fruit workaround) -------------------
# The COCO model sees toy fruits as other classes; map them:
LABEL_MAP = {
    "apple": "apple", "sports ball": "apple", "frisbee": "apple",
    "banana": "banana", "mouse": "banana", "bird": "banana",
    "orange": "orange",
}
FRUIT_COLOR = {"apple": "Red", "banana": "Yellow", "orange": "Orange"}

# --- ACCURACY / CALIBRATION OFFSETS -----------------------------------
PICK_OFFSET_X_PX = 0    # + shifts the aim RIGHT in the image, - LEFT
PICK_OFFSET_Y_PX = 0    # + shifts the aim toward the BOTTOM (nearer)

CONFIDENCE_MIN = 0.35
PICK_CONFIDENCE_MIN = 0.35
STABLE_HITS = 3        # frames the same fruit must persist; coordinates
                        # are AVERAGED over these frames before moving
COOLDOWN_S = 5.0
MOVE_TIMEOUT_S = 20.0
POLL_S = 0.1
GRIP_SETTLE_S = 0.4

HOME = [90.0, 90.0, 90.0, 90.0, 90.0, GRIPPER_OPEN]

NORMAL_STEP_DEG = 0.8   # travel speed (~40 deg/s)
SLOW_STEP_DEG = 0.4     # precise half speed for descend + grip + lift

# ======================================================================
# BRICKS + STATE
# ======================================================================
ui = WebUI()
detector = VideoObjectDetection(confidence=CONFIDENCE_MIN, debounce_sec=0.4)

_arm_enabled = False
_busy = threading.Event()
_last_pick_done = 0.0
_stable_label = None
_stable_count = 0
_coord_hist = deque(maxlen=STABLE_HITS)   # recent centers for averaging
_counts = {"apple": 0, "banana": 0, "orange": 0}
_state = "idle"
_printed_sample = False

_frames = 0
_last_frame_ts = 0.0
_last_beat_ts = 0.0
_last_labels = []
_last_wouldbe_log = 0.0

_log_lines = deque(maxlen=40)
_ui_items = []
_ui_items_ts = 0.0


def log(msg: str) -> None:
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    _log_lines.append(line)


# ======================================================================
# VISION -> ARM MAPPING
# ======================================================================
def base_angle_for_cx(cx: int) -> float:
    frac = min(max(cx / float(FRAME_W), 0.0), 1.0)
    ang = BASE_AT_LEFT_EDGE + frac * (BASE_AT_RIGHT_EDGE - BASE_AT_LEFT_EDGE)
    lo, hi = sorted((BASE_AT_LEFT_EDGE, BASE_AT_RIGHT_EDGE))
    return min(max(ang, lo), hi)


def elbow_down_for_cy(cy: int) -> float:
    """Object's y pixel -> elbow-down depth, interpolated FAR (top of
    image) to NEAR (bottom of image)."""
    t = min(max(cy / float(FRAME_H), 0.0), 1.0)  # 0 = top/far, 1 = bottom/near
    return PICK_ELBOW_DOWN_FAR + t * (PICK_ELBOW_DOWN_NEAR - PICK_ELBOW_DOWN_FAR)


def apply_offsets(cx: float, cy: float):
    """Apply calibration offsets and clamp to the frame."""
    ox = min(max(cx + PICK_OFFSET_X_PX, 0), FRAME_W)
    oy = min(max(cy + PICK_OFFSET_Y_PX, 0), FRAME_H)
    return int(ox), int(oy)


# ======================================================================
# MOTION (Bridge RPC to sketch.ino)
# ======================================================================
def move_and_wait(base, shoulder, elbow, wrist, wrot, grip) -> None:
    ok = Bridge.call("move_all", float(base), float(shoulder), float(elbow),
                     float(wrist), float(wrot), float(grip))
    if not ok:
        raise RuntimeError("MCU rejected move (E-STOP active?)")
    t0 = time.monotonic()
    while not Bridge.call("is_motion_complete"):
        if time.monotonic() - t0 > MOVE_TIMEOUT_S:
            raise RuntimeError("Motion timeout — check servo power / sketch")
        time.sleep(POLL_S)


def set_speed(deg_per_tick: float) -> None:
    try:
        Bridge.call("set_speed", float(deg_per_tick))
    except Exception as exc:  # noqa: BLE001
        log(f"[WARN] set_speed failed: {exc}")


def pick_and_place(fruit: str, coords, conf: float) -> None:
    """v4 top-down cycle: aim -> hover (wrist pre-set) -> vertical
    descend (elbow only) -> close -> vertical lift -> carry -> box."""
    global _state, _last_pick_done
    try:
        cx, cy = coords
        b = base_angle_for_cx(cx)
        ed = elbow_down_for_cy(cy)
        wp = WRIST_PITCH_BY_FRUIT.get(fruit, 30.0)
        wr = WRIST_ROTATE_BY_FRUIT.get(fruit, 90.0)

        _state = f"picking {fruit}"
        log(f"[PICK] {fruit} ({FRUIT_COLOR[fruit]}) at ({cx},{cy}), conf={conf:.2f}")
        log(f"[AIM] base {b:.0f} | elbow-down {ed:.0f} | wrist pitch {wp:.0f} "
            f"rotate {wr:.0f}")

        # Aim the base while upright
        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0, GRIPPER_OPEN)
        # Hover directly above the object; wrist reaches its per-fruit
        # angles HERE, before any lowering (requirement 6).
        move_and_wait(b, PICK_SHOULDER, PICK_ELBOW_HOVER, wp, wr, GRIPPER_OPEN)

        set_speed(SLOW_STEP_DEG)
        # Vertical descend: ONLY the elbow moves (no scooping)
        move_and_wait(b, PICK_SHOULDER, ed, wp, wr, GRIPPER_OPEN)
        move_and_wait(b, PICK_SHOULDER, ed, wp, wr, GRIPPER_CLOSED)
        time.sleep(GRIP_SETTLE_S)
        # Vertical lift: elbow back up, everything else unchanged
        move_and_wait(b, PICK_SHOULDER, PICK_ELBOW_HOVER, wp, wr, GRIPPER_CLOSED)
        set_speed(NORMAL_STEP_DEG)

        # Carry upright (keep the claw rotation while holding the fruit)
        move_and_wait(b, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr, GRIPPER_CLOSED)

        _state = f"placing {fruit}"
        box = BOX_BASE_ANGLE[fruit]
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, wr, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, wr, GRIPPER_CLOSED)
        move_and_wait(box, DROP_SHOULDER, DROP_ELBOW, DROP_WRIST, wr, GRIPPER_OPEN)
        time.sleep(GRIP_SETTLE_S)
        move_and_wait(box, CARRY_SHOULDER, CARRY_ELBOW, CARRY_WRIST, 90.0, GRIPPER_OPEN)
        move_and_wait(*HOME)

        _counts[fruit] += 1
        log(f"[DONE] {fruit} -> {FRUIT_COLOR[fruit]} box (total: {_counts[fruit]})")
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] pick cycle failed: {exc}")
        try:
            move_and_wait(*HOME)
        except Exception as exc2:  # noqa: BLE001
            log(f"[ERROR] recovery to home also failed: {exc2}")
    finally:
        set_speed(NORMAL_STEP_DEG)
        _state = "idle"
        _last_pick_done = time.monotonic()
        _busy.clear()


# ======================================================================
# DETECTION HANDLING
# ======================================================================
def on_detections(results) -> None:
    global _stable_label, _stable_count, _printed_sample
    global _frames, _last_frame_ts, _last_beat_ts, _last_labels
    global _last_wouldbe_log, _ui_items, _ui_items_ts
    try:
        _frames += 1
        now = time.monotonic()
        _last_frame_ts = now
        if results:
            _last_labels = sorted(str(k).lower() for k in results.keys())
        if now - _last_beat_ts > 5.0:
            _last_beat_ts = now
            if _last_labels:
                parts = []
                for l in _last_labels:
                    mapped = LABEL_MAP.get(l)
                    if mapped is None:
                        parts.append(f"{l} (ignored)")
                    elif mapped != l:
                        parts.append(f"{l}->{mapped}")
                    else:
                        parts.append(l)
                seen = ", ".join(parts)
            else:
                seen = "nothing recognized yet"
            log(f"[CAMERA OK] frames: {_frames} | model last saw: {seen}")

        if not _printed_sample and results:
            _printed_sample = True
            log(f"sample_detections: {results}")

        best = None
        items = []
        for label, instances in (results or {}).items():
            raw = str(label).lower()
            mapped = LABEL_MAP.get(raw)   # None => ignored class
            for inst in instances:
                conf = float(inst.get("confidence", 0.0))
                x1, y1, x2, y2 = inst.get("bounding_box_xyxy", (0, 0, 0, 0))
                # Requirement 4: use the CENTER of the detected object
                cx, cy = int((x1 + x2) / 2), int((y1 + y2) / 2)
                items.append({
                    "fruit": mapped or raw,
                    "raw": raw,
                    "target": mapped is not None,
                    "color": FRUIT_COLOR.get(mapped) if mapped else None,
                    "confidence": round(conf, 2), "cx": cx, "cy": cy,
                    "box": [int(x1), int(y1), int(x2), int(y2)],
                })
                if mapped is not None and (best is None or conf > best[2]):
                    best = (mapped, (cx, cy), conf)

        _ui_items = items
        _ui_items_ts = now

        if best is None:
            _stable_label, _stable_count = None, 0
            _coord_hist.clear()
            return

        label, coords, conf = best
        if label == _stable_label:
            _stable_count += 1
            _coord_hist.append(coords)
        else:
            _stable_label, _stable_count = label, 1
            _coord_hist.clear()
            _coord_hist.append(coords)

        if _stable_count < STABLE_HITS:
            return
        if conf < PICK_CONFIDENCE_MIN:
            return
        if _busy.is_set():
            return   # target locked — never switch mid-pick (req. 4)
        if time.monotonic() - _last_pick_done < COOLDOWN_S:
            return

        # Requirement 4: average the coordinates over the stable frames,
        # then apply the calibration offsets.
        avg_cx = sum(c[0] for c in _coord_hist) / len(_coord_hist)
        avg_cy = sum(c[1] for c in _coord_hist) / len(_coord_hist)
        aim = apply_offsets(avg_cx, avg_cy)

        if not _arm_enabled:
            if now - _last_wouldbe_log > 5.0:
                _last_wouldbe_log = now
                b = base_angle_for_cx(aim[0])
                log(f"[ARM DISABLED] would pick {label} at {aim} -> base "
                    f"{b:.0f} deg. Press 'Enable Arm' on the page to act.")
            return

        _busy.set()
        _stable_label, _stable_count = None, 0
        _coord_hist.clear()
        threading.Thread(target=pick_and_place, args=(label, aim, conf),
                         daemon=True).start()
    except Exception as exc:  # noqa: BLE001
        print(f"[WARN] detection callback error: {exc}", flush=True)


# ======================================================================
# REST API (polled by the web page)
# ======================================================================
def api_state():
    now = time.monotonic()
    return {
        "version": VERSION,
        "state": _state,
        "arm_enabled": _arm_enabled,
        "counts": dict(_counts),
        "frames": _frames,
        "detections": list(_ui_items),
        "detections_age_s": round(now - _ui_items_ts, 1) if _ui_items_ts else None,
        "stream": _stream_info,
        "log": list(_log_lines),
    }


def api_arm_toggle():
    global _arm_enabled
    _arm_enabled = not _arm_enabled
    log(f"[ARM] motion {'ENABLED' if _arm_enabled else 'DISABLED'} from web page")
    return {"ok": True, "arm_enabled": _arm_enabled}


def api_estop():
    global _arm_enabled
    _arm_enabled = False
    try:
        Bridge.call("estop_trigger")
        log("[E-STOP] triggered from web page (arm re-disabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP call failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_estop_reset():
    try:
        Bridge.call("estop_reset")
        log("[E-STOP] reset from web page (arm stays disabled until enabled)")
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        log(f"[ERROR] E-STOP reset failed: {exc}")
        return {"ok": False, "error": str(exc)}


def api_home():
    if _busy.is_set():
        return {"ok": False, "error": "busy"}

    def _home():
        try:
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] manual home failed: {exc}")

    threading.Thread(target=_home, daemon=True).start()
    log("[HOME] manual home requested from web page")
    return {"ok": True}


def api_test_servos():
    """Sweep each PCA9685 channel one at a time so you can SEE which
    physical joint is wired to which channel number."""
    if _busy.is_set():
        return {"ok": False, "error": "busy"}
    _busy.set()

    def _wait_done(timeout=8.0):
        t0 = time.monotonic()
        while not Bridge.call("is_motion_complete"):
            if time.monotonic() - t0 > timeout:
                raise RuntimeError("timeout")
            time.sleep(POLL_S)

    def _run():
        names = ["0 = base", "1 = shoulder", "2 = elbow",
                 "3 = wrist pitch", "4 = wrist rotate", "5 = GRIPPER/claw"]
        try:
            log("[TEST] Servo sweep starting — watch which joint moves "
                "for each channel number.")
            for ch in range(6):
                log(f"[TEST] testing channel {names[ch]} ...")
                for target in (60.0, 120.0, 90.0):
                    if not Bridge.call("move_servo", ch, target):
                        raise RuntimeError(f"MCU rejected move on ch {ch} "
                                           f"(E-STOP active?)")
                    _wait_done()
                time.sleep(0.4)
            log("[TEST] Sweep done. Returning to HOME.")
            move_and_wait(*HOME)
        except Exception as exc:  # noqa: BLE001
            log(f"[ERROR] servo test failed: {exc}")
        finally:
            _busy.clear()

    threading.Thread(target=_run, daemon=True).start()
    return {"ok": True}


ui.expose_api("GET", "/api/state", api_state)
ui.expose_api("GET", "/api/arm_toggle", api_arm_toggle)
ui.expose_api("GET", "/api/estop", api_estop)
ui.expose_api("GET", "/api/estop_reset", api_estop_reset)
ui.expose_api("GET", "/api/home", api_home)
ui.expose_api("GET", "/api/test_servos", api_test_servos)

detector.on_detect_all(on_detections)


def _camera_watchdog() -> None:
    warned_at = 0.0
    while True:
        time.sleep(5.0)
        now = time.monotonic()
        if _frames == 0 or now - _last_frame_ts > 10.0:
            if now - warned_at > 15.0:
                warned_at = now
                log("[CAMERA?] no frames from the detection brick — camera "
                    "not detected or brick failed. Check: lsusb, "
                    "ls /dev/video*, and the App launch log for errors.")


threading.Thread(target=_camera_watchdog, daemon=True).start()


_stream_info = None


def _probe_stream() -> None:
    global _stream_info
    import urllib.request
    time.sleep(8.0)
    candidates = [
        (4912, "/"), (4912, "/stream"), (4912, "/video"),
        (4912, "/mjpeg"), (4912, "/feed"), (5050, "/"),
    ]
    found = 0
    for port, path in candidates:
        url = f"http://127.0.0.1:{port}{path}"
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            ctype = resp.headers.get("Content-Type", "?")
            status = getattr(resp, "status", 200)
            resp.close()
            if status == 200:
                found += 1
                log(f"[STREAM PROBE] FOUND: port {port} path {path} ({ctype})")
                if _stream_info is None:
                    _stream_info = {"port": port, "path": path,
                                    "content_type": ctype}
        except Exception:
            pass
    if found == 0:
        log("[STREAM PROBE] no raw stream found on common ports — the "
            "Live Detection View IS your live view.")
    else:
        log("[STREAM PROBE] open 'Raw camera stream' on the page to view it.")


threading.Thread(target=_probe_stream, daemon=True).start()

log(f"Fruit sorter {VERSION} started. ARM IS DISABLED — verify aiming on "
    f"the page, then press 'Enable Arm'.")

App.run()
