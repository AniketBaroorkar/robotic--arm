# Fruit Sorting Robot — Nearest-Zone Clearance / Smoothstep Motion v28

This is the complete Arduino App Lab project. The camera identifies the fruit and the arm starts sorting automatically; there is no pickup enable/disable button. E-STOP and Reset remain available.

## v28 tray layout (geometry fix)

**What was wrong in v27:** each drop was placed 8 cm from its *own* pickup, but that measurement crossed over the *other* pickup. The apple drop ended up only **~2 cm from the banana pickup mark** (and banana drop ~2 cm from apple pickup) — drops were practically on top of the pickups.

**v28 rule:** every drop is placed with `DROP_CLEARANCE_CM` (8 cm) of straight-line distance from its **nearest** neighbouring zone. The pickups stay symmetric around 90°.

At the configured 15 cm working radius, the exact base directions are:

```text
LEFT                                                                        RIGHT
Apple drop   Banana/Orange pickup    90° centre    Apple pickup   Banana drop   Orange drop
   47.5°            78.5°               90.0°          101.5°        132.5°        163.4°
        <── 8 cm ──>       <── 6 cm ──>       <── 8 cm ──>      <── 8 cm ──>
```

Every drop is at least 8 cm from every pickup, the layout is perfectly symmetric around the centre line, and all angles sit inside the safe base window (10–170°). The orange drop is now computed (`banana drop + clearance`) instead of a hard-coded 165°, so the whole tray scales if you change one constant.

The base rotates in a circle, so the physical marks lie on one constant-radius **arc**, not a mathematically straight line. Keep the shoulder and elbow reach unchanged and align the long tray along the tested arc. Re-mark all five spots on the tray using the angles above.

Adjust spacing in `python/main.py`:

```python
WORKING_RADIUS_CM = 15.0
PICKUP_SPACING_CM = 6.0
DROP_CLEARANCE_CM = 8.0     # distance from each drop to its NEAREST zone
MIN_ZONE_GAP_CM = 5.5       # validate_layout() rejects anything closer
PICKUP_CENTER_BASE = 90.0
```

The code splits `PICKUP_SPACING_CM` equally around `PICKUP_CENTER_BASE` and derives all three drops from the clearance. `validate_layout()` now measures the real chord distance between **every adjacent pair of zones** at startup and refuses to run if any gap is under `MIN_ZONE_GAP_CM` — the exact check that would have caught the v27 bug.

## v28 motion smoothness

- **Smoothstep S-curve ramps (MCU):** the ease-in/ease-out ramp is now `f²(3−2f)` instead of linear, so acceleration changes gradually — starts and stops look organic rather than mechanical. `RAMP_DEG` widened 12→15.
- **Blended waypoints (Python):** the 3-step descent/lift no longer stops at each waypoint. The next waypoint is issued while ~2.5° of travel remains (`WAYPOINT_BLEND_DEG`, via the new `motion_remaining` Bridge RPC), so the descent is one continuous motion. The **final** waypoint still waits for full completion, so grip/release accuracy is unchanged.
- The crouch blends into the base rotation during travel, and the pickup reach (`ready → above`) is one fluid move.

## Banana movement

Pickup:

```text
CH3 wrist pitch = 10°
CH4 wrist rotation = 0°
```

Safe travel and vertical drop:

```text
CH4 wrist rotation = 90°
```

The banana rotates from horizontal to vertical only while the arm is compact and lifted. It remains vertical while lowering and releasing.

## Automatic operation

- The robot starts in automatic mode when the app launches.
- Stable fruit detection starts the cycle automatically.
- E-STOP pauses sorting.
- Reset E-STOP resumes sorting.

## Servo order

```text
CH0 base
CH1 shoulder
CH2 elbow
CH3 wrist pitch
CH4 wrist/claw rotation
CH5 gripper open/close
```

Test every base position without fruit first and keep the E-STOP ready.
