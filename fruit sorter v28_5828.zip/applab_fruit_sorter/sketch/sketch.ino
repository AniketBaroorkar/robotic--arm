/*
 * sketch.ino — Fruit Sorting Robot MCU firmware (Arduino UNO Q)
 * ==============================================================
 * Runs on the STM32 MCU. Owns the PCA9685 (I2C) and all six servos.
 * Python on the Linux side sends TARGET angles over Bridge RPC; this
 * sketch's loop() walks each servo smoothly toward its target and
 * polls the physical E-STOP button every iteration.
 *
 * IMPORTANT: motion/E-STOP setters use Bridge.provide_safe() so they
 * run in loop() context — Bridge.provide() runs handlers in a
 * background RPC thread where hardware calls can fail. Pure state
 * reads (is_motion_complete, get_estop_state) stay on provide().
 */

#include <Arduino_RouterBridge.h>
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

#define NUM_CHANNELS 6
#define PCA9685_ADDR 0x40
#define PCA9685_FREQ 50
#define SERVO_MIN_US 500.0
#define SERVO_MAX_US 2500.0

// Channel map: 0=base 1=shoulder 2=elbow 3=wrist_pitch 4=wrist_rotate 5=gripper
#define ESTOP_PIN 2            // normally-closed button to GND (press = LOW)
#define ESTOP_ACTIVE_LOW true

float stepDeg = 0.8f;                       // degrees per tick (runtime adjustable)
const unsigned long STEP_INTERVAL_MS = 20;  // tick period (~50 Hz)
// 0.8 deg / 20 ms = ~40 deg/s normal travel. Python lowers this via
// set_speed() during the descend/grip for a slow, accurate pick.

Adafruit_PWMServoDriver pca = Adafruit_PWMServoDriver(PCA9685_ADDR);

float currentAngle[NUM_CHANNELS] = {90, 90, 90, 90, 90, 90};
float targetAngle[NUM_CHANNELS]  = {90, 90, 90, 90, 90, 90};
// Per-channel step scaling so ALL joints of a pose arrive TOGETHER
// (proportional interpolation). Without this, the joint with less
// travel finishes first and the claw path curves instead of going
// straight — the "moves back and front" effect during descent.
float stepScale[NUM_CHANNELS] = {1, 1, 1, 1, 1, 1};
// --- SMOOTH MOTION: ease-in / ease-out ramps -------------------------
// Speed ramps up over the first RAMP_DEG of each move and back down
// over the last RAMP_DEG, so moves start and stop fluidly instead of
// jerking. This is what lets the top speeds be raised without the
// motion looking violent.
float startMaxTravel = 180.0f;      // master travel of the current move
const float RAMP_DEG = 15.0f;       // bigger = softer starts/stops (v28:
                                    // widened for the smoothstep S-curve)
const float MIN_SPEED_FACTOR = 0.12f;

// Per-channel hard limits — tune to your arm's real mechanical range.
// ch5 (claw): MEASURED on this arm as 90 = open, 180 = closed.
float minLimit[NUM_CHANNELS] = {0,  20, 10, 0,   0,   80};
float maxLimit[NUM_CHANNELS] = {180,160,170,180, 180, 180};

volatile bool estopActive = false;
unsigned long lastStepMs = 0;

void writeServoAngle(uint8_t ch, float angle) {
  angle = constrain(angle, minLimit[ch], maxLimit[ch]);
  float pulse_us = SERVO_MIN_US + (angle / 180.0f) * (SERVO_MAX_US - SERVO_MIN_US);
  float period_us = 1000000.0f / PCA9685_FREQ;
  uint16_t ticks = (uint16_t)((pulse_us / period_us) * 4096.0f);
  pca.setPWM(ch, 0, ticks);
  currentAngle[ch] = angle;
}

void freezeTargetsAtCurrent() {
  for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) targetAngle[ch] = currentAngle[ch];
}

// ---- RPC functions (called from Python via Bridge) -------------------
bool move_servo(int channel, float angle) {
  if (channel < 0 || channel >= NUM_CHANNELS) return false;
  if (estopActive) return false;
  targetAngle[channel] = constrain(angle, minLimit[channel], maxLimit[channel]);
  stepScale[channel] = 1.0f;
  startMaxTravel = fabs(targetAngle[channel] - currentAngle[channel]);
  return true;
}

// Atomically freeze arm joints 0..4 and command only the claw.
// This guarantees the arm cannot move backward/forward while gripping.
bool lock_arm_and_grip(float gripperAngle) {
  if (estopActive) return false;
  for (uint8_t ch = 0; ch < 5; ch++) {
    targetAngle[ch] = currentAngle[ch];
    stepScale[ch] = 0.0f;
  }
  targetAngle[5] = constrain(gripperAngle, minLimit[5], maxLimit[5]);
  stepScale[5] = 1.0f;
  startMaxTravel = fabs(targetAngle[5] - currentAngle[5]);
  return true;
}

// Argument order MUST match move_and_wait() in python/main.py:
// base, shoulder, elbow, wrist_pitch, wrist_rotate, gripper
bool move_all(float base, float shoulder, float elbow,
              float wristPitch, float wristRotate, float gripper) {
  if (estopActive) return false;
  float vals[NUM_CHANNELS] = {base, shoulder, elbow, wristPitch, wristRotate, gripper};
  float maxTravel = 0.0f;
  for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
    targetAngle[ch] = constrain(vals[ch], minLimit[ch], maxLimit[ch]);
    float t = fabs(targetAngle[ch] - currentAngle[ch]);
    if (t > maxTravel) maxTravel = t;
  }
  // Proportional scaling: every joint finishes at the same moment, so
  // multi-joint moves trace a straight-ish path instead of curving.
  for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
    float t = fabs(targetAngle[ch] - currentAngle[ch]);
    stepScale[ch] = (maxTravel > 0.01f) ? (t / maxTravel) : 1.0f;
  }
  startMaxTravel = maxTravel;
  return true;
}

bool is_motion_complete() {
  for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
    if (fabs(targetAngle[ch] - currentAngle[ch]) > 0.5f) return false;
  }
  return true;
}

// Largest remaining joint travel in degrees. Python uses this to blend
// consecutive waypoints (issue the next one slightly before this one
// finishes) so multi-waypoint descents are one continuous motion.
float motion_remaining() {
  float remaining = 0.0f;
  for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
    float d = fabs(targetAngle[ch] - currentAngle[ch]);
    if (d > remaining) remaining = d;
  }
  return remaining;
}

bool get_estop_state() { return estopActive; }

bool estop_trigger() {
  estopActive = true;
  freezeTargetsAtCurrent();   // freeze in place immediately
  Monitor.println("E-STOP triggered.");
  return true;
}

// Runtime speed control: Python slows the arm for the precise
// descend/grip phase, then restores normal travel speed.
bool set_speed(float degPerTick) {
  stepDeg = constrain(degPerTick, 0.2f, 3.0f);
  return true;
}

bool estop_reset() {
  estopActive = false;
  Monitor.println("E-STOP reset.");
  return true;
}

// ---- setup / loop -----------------------------------------------------
void setup() {
  Bridge.begin();
  Monitor.begin(115200);

  pinMode(ESTOP_PIN, INPUT_PULLUP);

  Wire.begin();
  pca.begin();
  pca.setPWMFreq(PCA9685_FREQ);
  delay(10);

  // Home all six servos at boot — independent of the Python side.
  for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
    writeServoAngle(ch, 90.0f);
    targetAngle[ch] = 90.0f;
  }

  // Hardware-affecting calls: provide_safe (runs in loop() context).
  Bridge.provide_safe("move_servo", move_servo);
  Bridge.provide_safe("move_all", move_all);
  Bridge.provide_safe("lock_arm_and_grip", lock_arm_and_grip);
  Bridge.provide_safe("estop_trigger", estop_trigger);
  Bridge.provide_safe("estop_reset", estop_reset);
  Bridge.provide_safe("set_speed", set_speed);
  // Pure reads: plain provide is fine.
  Bridge.provide("is_motion_complete", is_motion_complete);
  Bridge.provide("motion_remaining", motion_remaining);
  Bridge.provide("get_estop_state", get_estop_state);

  Monitor.println("Servo bridge ready. All joints homed to 90 deg.");
}

void loop() {
  // Physical E-STOP: hard-real-time path, checked every iteration.
  bool pressed = ESTOP_ACTIVE_LOW ? (digitalRead(ESTOP_PIN) == LOW)
                                   : (digitalRead(ESTOP_PIN) == HIGH);
  if (pressed && !estopActive) estop_trigger();

  unsigned long now = millis();
  if (now - lastStepMs >= STEP_INTERVAL_MS) {
    lastStepMs = now;
    if (!estopActive) {
      // master progress -> ease-in/ease-out speed factor for this tick
      float remaining = 0.0f;
      for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
        float d = fabs(targetAngle[ch] - currentAngle[ch]);
        if (d > remaining) remaining = d;
      }
      if (remaining > 0.01f) {
        float travelled = startMaxTravel - remaining;
        if (travelled < 0.0f) travelled = 0.0f;
        float fUp = travelled / RAMP_DEG;
        float fDown = remaining / RAMP_DEG;
        float f = fUp < fDown ? fUp : fDown;
        if (f > 1.0f) f = 1.0f;
        // v28: smoothstep the ramp (f² · (3 − 2f)) — an S-curve velocity
        // profile with zero-slope entry/exit instead of a linear ramp.
        // Accel changes gradually, so starts and stops look organic.
        f = f * f * (3.0f - 2.0f * f);
        if (f < MIN_SPEED_FACTOR) f = MIN_SPEED_FACTOR;
        for (uint8_t ch = 0; ch < NUM_CHANNELS; ch++) {
          float diff = targetAngle[ch] - currentAngle[ch];
          if (fabs(diff) < 0.01f) continue;
          float maxStep = stepDeg * stepScale[ch] * f;
          if (maxStep < 0.05f) maxStep = 0.05f; // never fully stall a joint
          float step = constrain(diff, -maxStep, maxStep);
          writeServoAngle(ch, currentAngle[ch] + step);
        }
      }
    }
  }
}
