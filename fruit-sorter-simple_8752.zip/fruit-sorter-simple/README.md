# Fruit-Sorting 6DOF Robotic Arm — Arduino UNO Q

An automatic fruit sorter: a fixed USB camera watches an unsorted tray and
three buckets; YOLO + HSV color verification identify **apple / orange /
banana**; a 6DOF arm on a PCA9685 picks each fruit and drops it into the
matching bucket (apple→red, orange→orange, banana→yellow), returns to the
90° home pose, and keeps scanning until you press Stop.

Follow **STAGES.md** for the step-by-step build order. Do not skip stages.

---

## 1. Hardware

| Item | Notes |
|---|---|
| Arduino UNO Q (4GB) | Qualcomm QRB2210 Linux side + STM32U585 MCU side |
| Logitech Brio 100 **or** Waveshare OV5693 USB camera | fixed above/in front of the whole workspace |
| 6DOF arm, six **180° positional** servos (MG996R class) | no continuous-rotation logic anywhere |
| PCA9685 16-ch PWM driver | I²C address 0x40 |
| 7.4 V 2S Li-ion pack + power switch | main supply |
| 5 V high-current UBEC / buck converter | servo power ONLY |

## 2. ⚠️ Power warnings — read before wiring

* **Never power servos from the UNO Q's 5 V/3.3 V pins.** The board's
  regulator cannot supply servo current and you will brown-out or destroy
  the board.
* **Calculate your servo current.** Each MG996R-class servo can stall at
  ~2.5 A. Worst case = sum of stall currents of servos that can be loaded
  simultaneously. With 4 joints under load while moving:
  `4 × 2.5 A = 10 A` peak. **A "5 V 5 A" buck is NOT automatically
  enough.** Rule of thumb: UBEC continuous rating ≥ (number of loaded
  servos × stall current × 0.6). For this arm choose **5 V 8–10 A**.
  Check your servos' datasheet stall figure and redo the math.
* Undersized supplies cause the classic symptom: the arm twitches,
  resets, or the camera disconnects when servos load up.
* Use thick wires (≥ 18 AWG) from the UBEC to PCA9685 V+ and GND.
* **All grounds must be common**: battery−, UBEC−, PCA9685 GND, UNO Q GND.

## 3. Wiring

```
7.4 V battery → power switch ─┬─ branch 1 → UNO Q power input (see below)
                              └─ branch 2 → 5 V UBEC → PCA9685 V+ / GND
```

* UNO Q power: use the USB-C input with a suitable 5 V regulator from the
  battery, or the board's supported DC input per the official pinout —
  never feed raw 7.4 V into a 5 V pin.

| PCA9685 pin | Connects to |
|---|---|
| SDA | UNO Q **SDA** (header pin A4/SDA, 3.3 V logic) |
| SCL | UNO Q **SCL** (header pin A5/SCL) |
| VCC (logic) | UNO Q **3V3** (logic supply only, a few mA) |
| GND | UNO Q GND **and** UBEC GND (common ground) |
| V+ (servo power) | UBEC 5 V output (screw terminal) |

| PCA9685 channel | Servo |
|---|---|
| 0 | Base |
| 1 | Shoulder |
| 2 | Elbow |
| 3 | Wrist pitch |
| 4 | Wrist rotation |
| 5 | Gripper |

USB camera → UNO Q USB host port (use a powered hub/adapter if your UNO Q
setup shares the USB-C port for power).

## 4. Architecture (UNO Q dual-processor)

```
┌───────────────── Linux (QRB2210, Debian) ─────────────────┐
│ camera.py → detector.py (YOLO) → color_verifier.py (HSV)  │
│ → stability.py → calibration.py (homography, regions)     │
│ → inverse_kinematics.py → motion_planner.py               │
│ → state_machine.py  → webapp.py (Flask dashboard :8000)   │
│                 │ bridge.py (ONLY file touching Bridge)   │
└─────────────────┼─────────────────────────────────────────┘
                  │ official Arduino Router/Bridge RPC
┌─────────────────▼──────── MCU (STM32U585) ────────────────┐
│ sketch.ino: PCA9685 I²C, angle validation, smooth         │
│ interpolation, HOME, gripper, STOP/E-STOP, angle reports  │
└───────────────────────────────────────────────────────────┘
```

Bridge API used (official, verified):
* Python: `from arduino.app_utils import Bridge` → `Bridge.call("cmd", payload)`
* Sketch: `#include <Arduino_RouterBridge.h>` → `Bridge.begin()`,
  `Bridge.provide("cmd", handleCmd)`
* The router service owns the internal UART — never open `Serial1`.

## 5. Folder structure

```
fruit-sorter/
├── app.yaml                  App Lab app manifest
├── config/
│   ├── config.yaml           EVERY tunable value
│   └── calibration.example.json
├── python/
│   ├── main.py               entry: state machine + Flask dashboard (HTML inside)
│   ├── vision.py             camera + YOLO + HSV + stability + calibration
│   └── robot.py              Bridge RPC + inverse kinematics + motion planner
├── python/vision.py          camera + YOLO + HSV + tracking + calibration
├── sketch/sketch.ino         MCU firmware (+ sketch.yaml libraries)
├── calibrate.py              click-to-calibrate workspace tool
├── requirements.txt
└── STAGES.md                 build order — follow it exactly
```

## 6. Installation (summary — full detail in STAGES.md Stage 2)

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-venv python3-pip v4l-utils
cd ~/ArduinoApps && mkdir -p fruit-sorter   # copy this project there
cd fruit-sorter
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 7. Measuring the arm (placeholders)

`config/config.yaml` contains bracketed placeholders that **you must
replace with real measurements** (mm, use a ruler/calipers, measure axis
to axis, not edge to edge):

* `[MEASURE_BASE_HEIGHT_MM]` — table surface → shoulder-servo axis.
* `[MEASURE_UPPER_ARM_MM]` — shoulder axis → elbow axis.
* `[MEASURE_FOREARM_MM]` — elbow axis → wrist-pitch axis.
* `[MEASURE_TOOL_OFFSET_MM]` — wrist-pitch axis → gripper fingertip
  centre when the gripper points straight down.
* `[MEASURE_BASE_X_MM]` / `[MEASURE_BASE_Y_MM]` — base-axis position in
  workspace mm (also asked during calibration; calibration wins).

All motion is blocked until every placeholder is a number.

## 8. Servo horn centring (do this before assembling the arm!)

1. Remove every horn/bracket screw so servos spin freely.
2. Run `python/main.py (dashboard sliders)` → `home` — all outputs go to 90°.
3. With power still on, reinstall each horn so the arm segment sits in
   its mechanically neutral mid-pose at 90°.
4. If a segment is one spline-tooth off, correct the remainder with that
   joint's `offset_deg` in `config.yaml`.
Never force a horn onto a powered servo against its position.

## 9. Coordinate frames & Z limitation

* **Image frame**: pixels (u,v), v grows downward.
* **Workspace frame**: mm, origin at the top-left calibration corner,
  +X right, +Y "down the image", +Z up.
* **Robot frame**: origin under the base axis on the table, +X straight
  ahead at base zero, +Z up. `robot.base_rotation_deg` rotates it.

**Honest limitation:** a plain USB camera has **no depth**. The
homography gives accurate X/Y only for objects on the flat table. All Z
values are the fixed heights in `config.yaml` (`PICK_Z` + per-fruit
height). This works because fruits sit on one flat surface — it is not
real 3D vision, and tall/stacked objects will be grasped at the wrong
height.

## 10. Running

```bash
source .venv/bin/activate
python3 python/main.py            # starts in dry_run: true — SAFE
# open http://<uno-q-ip>:8000
```
As an App Lab app instead: `arduino-app-cli app start ~/ArduinoApps/fruit-sorter`
(this also flashes/runs the sketch). Logs:
`arduino-app-cli app logs ~/ArduinoApps/fruit-sorter`.

Automatic mode: set `dry_run: false` **only after** Stages 1–13 pass,
keep `low_speed_mode: true` for the first real runs, then press **Start**
on the dashboard.

## 11. Emergency stop

* Dashboard red button → firmware freezes all targets instantly and
  rejects every motion command.
* **Clear E-stop** works only while the arm is stationary.
* Hardware layer: the main power switch cuts servo power — keep it
  within reach.

## 12. Troubleshooting (quick table)

| Symptom | Check |
|---|---|
| No camera | `ls /dev/video*`, camera.index, powered hub |
| YOLO slow | inference_size 320→256, fps 15→10 |
| Wrong colors | tune `hsv:` with scripts/test_hsv.py, add diffuse light |
| Arm twitches/resets | undersized 5 V supply, thin wires, missing common GND |
| Bridge timeout | app running via App Lab? firmware flashed? router service up? |
| IK "unreachable" | fruit too far/close; re-measure link lengths |
| Wrong bucket | re-check bucket drop positions in calibration.json |

## 13. Known limitations & future improvements

* No depth sensing (fixed Z), no grip-force feedback (visual failure
  check only), single-fruit sequential sorting, lighting-sensitive HSV.
* Ideas: depth camera, gripper current sensing, custom-trained YOLO for
  your exact fruits, conveyor feed, trajectory blending.
