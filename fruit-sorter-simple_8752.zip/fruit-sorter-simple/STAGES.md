# Build Stages — follow in order, do not skip

Every stage lists: purpose, files, commands, expected output, what you
should physically observe, troubleshooting, and the **PASS condition**
required before the next stage.

---

## Stage 1 — Safety and hardware

**Purpose:** wire everything correctly before any code runs.

1. Read README sections 2–3 (power math + wiring tables) completely.
2. Compute your supply current: `loaded_servos × stall_current`. For four
   loaded MG996R (~2.5 A stall) that is 10 A peak → use a 5 V 8–10 A UBEC.
3. Wire: battery → switch → (UNO Q power) + (UBEC → PCA9685 V+/GND).
   SDA→SDA, SCL→SCL, PCA9685 VCC→3V3, all GNDs common.
4. Do **not** attach the servo horns / arm linkages yet (Stage 3 centres
   the servos first).

**Observe:** with the switch on, UNO Q boots (LEDs), nothing moves, no
part gets warm.
**Troubleshooting:** board reboots when a servo is plugged in → supply
too weak or no common ground.
**PASS:** board boots with servos connected to PCA9685, grounds
verified with a multimeter continuity test.

---

## Stage 2 — UNO Q setup

**Purpose:** working Linux environment + project in place.

```bash
# on the UNO Q (attach monitor+keyboard, or ssh in; App Lab can also
# open a terminal for you)
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-venv python3-pip v4l-utils git
mkdir -p ~/ArduinoApps && cd ~/ArduinoApps
# copy the fruit-sorter folder here (USB stick / scp / git)
cd fruit-sorter
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt        # first run downloads torch; slow
mkdir -p models logs
python3 -c "import cv2, flask, yaml, ultralytics; print('imports OK')"
```

Camera permission check: `ls -l /dev/video*` — your user should be in
the `video` group (`sudo usermod -aG video $USER`, then re-login).

**Expected:** `imports OK`.
**Troubleshooting:** torch wheel issues on aarch64 → install the CPU
wheel first (see requirements.txt comment). Out of space → `df -h`,
clean apt cache.
**PASS:** imports OK, `/dev/video0` present.

---

## Stage 3 — Servo testing (horns OFF)

**Purpose:** centre every servo at 90° before the arm is assembled, and
find real safe limits.

1. Open the project in **Arduino App Lab** (it appears under
   `~/ArduinoApps`). App Lab compiles `sketch/sketch.ino` for the MCU and
   installs the libraries from `sketch/sketch.yaml`, then runs
   `python/main.py`. For this stage stop the main app and run only:

```bash
arduino-app-cli app start ~/ArduinoApps/fruit-sorter   # flashes firmware
# in a second terminal:
cd ~/ArduinoApps/fruit-sorter && source .venv/bin/activate
python3 python/main.py (dashboard sliders)
```

2. Type `home` → all six outputs rotate to 90° and hold.
3. Attach horns per README §8.
4. Move ONE joint at a time (`0 60`, `0 120`, …) and write down where the
   mechanics would collide. Put those numbers into `config.yaml`
   `servos:` min/max.
5. Test gripper: `5 60` (open), `5 118` (close) — adjust
   `GRIPPER_OPEN_ANGLE` / `GRIPPER_CLOSED_ANGLE` until it holds a fruit
   firmly without stalling loudly.

**Expected terminal:** angle dictionaries after each move; `ERR:` lines
when you request an angle outside limits (this is correct behavior).
**Observe:** smooth slow motion, no buzzing stall at rest.
**Troubleshooting:** no movement → check V+ power and PCA9685 address
0x40; jitter → weak supply.
**PASS:** all six servos centre at 90°, safe limits recorded in
config.yaml, gripper angles chosen.

---

## Stage 4 — PCA9685 + Bridge round-trip

**Purpose:** prove Python ⇄ MCU communication with acknowledgements and
timeout handling.

```bash
python3 scripts/test_bridge.py
```

**Expected:**
```
PING: OK
Limits + speeds pushed from config.yaml
Sending HOME (all servos to 90 deg, slow)…
Angles: {'base': 90.0, ...}
PASS: Bridge round-trip works.
```
**Troubleshooting:** `MockBridge active` warning → you are not inside
the App Lab environment / `arduino.app_utils` missing → run through App
Lab, or check `systemctl status arduino-router`. Timeout → firmware not
flashed/running.
**PASS:** the printed PASS line, and unplugging nothing: repeat run
still passes.

---

## Stage 5 — Camera

```bash
python3 scripts/test_camera.py
```
**Expected:** `OK: camera 0 -> 1280x720`, ~10–15 FPS. Headless: a
`test_frame.jpg` you can copy off and inspect.
**Troubleshooting:** wrong index → try `python3 scripts/test_camera.py 1`;
`v4l2-ctl --list-devices` names them.
**PASS:** sharp frame showing the ENTIRE tray + all three buckets.

---

## Stage 6 — YOLO

```bash
python3 scripts/test_yolo.py     # first run downloads yolov8n.pt
```
Place an apple, an orange, a banana, and a decoy (cup/bottle) in view.
**Expected:** boxes + confidences printed for the three fruits ONLY; the
decoy never appears (it is filtered by class id).
**Troubleshooting:** low confidence → more light, closer camera, lower
`confidence_threshold` to 0.35; slow → `inference_size: 256`.
**PASS:** all three fruits detected ≥ 0.45 conf, decoys ignored.

---

## Stage 7 — HSV verification

```bash
python3 scripts/test_hsv.py
```
**Expected per fruit:** dominant color matches reality with a percentage
above `min_color_percent` (35%), e.g.
`apple  conf=0.71 dominant=red    82.3% valid=True`.
Test the failure case: show a picture of a banana on your phone screen —
YOLO may say banana but the color percentage/validity should reject it,
or a green plastic toy orange → `valid=False`.
**Troubleshooting:** yellow reads as orange → move the boundary hue
(config `hsv: orange`/`yellow`); everything dark → raise camera exposure
or add diffuse white light.
**PASS:** each real fruit valid=True, wrong-colored objects valid=False.

---

## Stage 8 — Workspace calibration

```bash
python3 calibrate.py
```
Click the 4 workspace corners (TL,TR,BR,BL), enter real width/height in
mm (measure with a tape), then click tray + 3 bucket polygons, then type
bucket drop positions and the arm-base position.
**Expected:** `Sanity: TL corner maps to (0.0, 0.0) mm` and
`Saved config/calibration.json ✔`.
Verify: place a fruit at a known spot (e.g. 100 mm, 100 mm measured with
a ruler), run the backend dry-run (Stage 10) and compare the dashboard's
workspace X/Y — within ~5–10 mm is fine.
**PASS:** calibration.json exists, spot-check error < 10 mm.

---

## Stage 9 — IK testing (no motion)

First replace ALL `[MEASURE_*]` placeholders in config.yaml with your
ruler measurements (README §7). Then:
```bash
python3 scripts/test_inverse_kinematics.py
```
**Expected:** sensible angles for reachable targets; the far/near/high
cases print `UNREACHABLE (correctly rejected)` — they must NOT return
clamped fake angles.
**PASS:** reachable cases solve, impossible cases are rejected with a
clear message.

---

## Stage 10 — Dry-run integration

`config.yaml` already has `dry_run: true`. Start everything:
```bash
python3 python/main.py
```
Open `http://<uno-q-ip>:8000`. Press **Start**.
**Expected:** live annotated feed, tray/bucket outlines, detections
table with pixel + workspace coordinates, state cycling
SCANNING → TARGET_LOCKED → … → RETURNING_HOME in the badge, log lines
`[dry-run] MOVING_TO_PRE_GRASP: {...}`, servo sliders animating —
**and zero physical movement**.
**PASS:** a full simulated cycle completes for each fruit type and
counters increment.

---

## Stage 11 — Manual arm movement

Set `dry_run: false`, keep `low_speed_mode: true`. Restart the app.
Clear the workspace of fruit. On the dashboard: **Home**, then jog
X+/X−/Y+/Y−/Z+/Z−, gripper open/close, individual sliders.
**Observe:** slow smooth motion; jog rejects unreachable steps with an
error message instead of moving.
**PASS:** Home + all jogs behave; E-stop freezes instantly; Clear
E-stop only works when stationary.

---

## Stage 12 — Single-fruit pickup

One fruit in the tray, buckets empty, `retry_enabled: false`. Press
**Start**, watch one full cycle, press **Stop** after it returns home.
Keep a hand on the main power switch.
**PASS:** fruit is gripped, lifted, and the arm returns home without
hitting anything (the drop may still be inaccurate — next stage).

---

## Stage 13 — Bucket placement

Use the dashboard jog / a small test object to verify each calibrated
drop position: run one cycle per fruit type and confirm the release
happens INSIDE the correct bucket. Adjust `bucket_drop_positions` in
calibration.json (or re-run the calibrator) until all three are correct.
**PASS:** three consecutive cycles: apple→red, orange→orange,
banana→yellow.

---

## Stage 14 — Complete automatic sorting

Several fruits in the tray. Press **Start** and let it run.
**Expected:** fruits sorted one by one by the priority rules, counters
increase, scanning resumes after each sort, **Stop** ends the run after
the current safe motion, home pose (all 90°) between fruits.
Optional auto-start on boot (only now): create a systemd unit or use
App Lab's autostart for the app — never before all stages pass.

---

## Final verification checklist

- [ ] Camera streams the whole workspace
- [ ] YOLO detects apple, orange, banana; decoys ignored
- [ ] HSV validation accepts right colors, rejects wrong ones
- [ ] Source tray + all three bucket polygons calibrated
- [ ] Pixel→mm conversion within 10 mm on a spot check
- [ ] Robot-base transform verified (jog moves the way you expect)
- [ ] IK rejects unreachable targets with a clear message
- [ ] Every servo stays inside its measured safe range
- [ ] Home command → all six at 90°
- [ ] Emergency stop freezes and blocks commands; clears only at rest
- [ ] Dry-run full cycle completes
- [ ] Apple → red bucket, Orange → orange bucket, Banana → yellow bucket
- [ ] Arm returns to 90° home after every fruit
- [ ] Scanning resumes automatically after each completed sort
