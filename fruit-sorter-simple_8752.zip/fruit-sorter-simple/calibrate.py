"""Interactive workspace calibration (Stage 8).

Run with a display attached to the UNO Q, or over `ssh -X`, or run the
backend dashboard on another machine. Usage:

    python3 scripts/calibrate_workspace.py

Click points with the LEFT mouse button in this order (prompt shown in
the window title and terminal):
  Phase 1 — 4 workspace corners: top-left, top-right, bottom-right,
            bottom-left. You then type the real workspace width/height
            in millimetres in the terminal.
  Phase 2 — 4 corners of the SOURCE TRAY.
  Phase 3 — 4 corners of the RED bucket.
  Phase 4 — 4 corners of the ORANGE bucket.
  Phase 5 — 4 corners of the YELLOW bucket.
Keys:  u = undo last click   r = restart phase   q = abort without saving

Afterwards you type the drop position (in workspace mm) for each bucket
and the arm-base position. Everything is written to
config/calibration.json.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

import cv2
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
import yaml  # noqa: E402


def load_config() -> Dict[str, Any]:
    with open(os.path.join(PROJECT_ROOT, "config", "config.yaml"),
              "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)

PHASES = [
    ("WORKSPACE corners (TL, TR, BR, BL)", 4),
    ("SOURCE TRAY corners", 4),
    ("RED bucket corners", 4),
    ("ORANGE bucket corners", 4),
    ("YELLOW bucket corners", 4),
]

clicks: List[List[int]] = []


def on_mouse(event: int, x: int, y: int, _flags: int, _param) -> None:
    if event == cv2.EVENT_LBUTTONDOWN:
        clicks.append([x, y])
        print(f"  point {len(clicks)}: ({x}, {y})")


def ask_float(prompt: str) -> float:
    while True:
        try:
            return float(input(prompt).strip())
        except ValueError:
            print("  Please enter a number.")


def collect_phase(cap: cv2.VideoCapture, title: str, n: int
                  ) -> List[List[int]]:
    global clicks
    clicks = []
    print(f"\n== {title}: click {n} points ==")
    while True:
        ok, frame = cap.read()
        if not ok:
            print("Camera read failed"); sys.exit(1)
        for i, (x, y) in enumerate(clicks):
            cv2.circle(frame, (x, y), 6, (0, 255, 0), -1)
            cv2.putText(frame, str(i + 1), (x + 8, y - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        if len(clicks) > 1:
            cv2.polylines(frame, [np.array(clicks)], len(clicks) == n,
                          (0, 255, 255), 1)
        cv2.putText(frame, f"{title} [{len(clicks)}/{n}]  u=undo r=restart",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    (255, 255, 255), 2)
        cv2.imshow("calibration", frame)
        key = cv2.waitKey(30) & 0xFF
        if key == ord("u") and clicks:
            clicks.pop(); print("  undo")
        elif key == ord("r"):
            clicks = []; print("  restart phase")
        elif key == ord("q"):
            print("Aborted — nothing saved."); sys.exit(0)
        if len(clicks) == n:
            print("  Press SPACE to confirm, u to undo.")
            key = cv2.waitKey(0) & 0xFF
            if key == ord(" "):
                return list(clicks)
            if key == ord("u") and clicks:
                clicks.pop()


def main() -> None:
    cfg = load_config()
    cam = cfg["camera"]
    cap = cv2.VideoCapture(int(cam["index"]))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(cam["width"]))
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(cam["height"]))
    if not cap.isOpened():
        print(f"Cannot open camera {cam['index']}"); sys.exit(1)
    cv2.namedWindow("calibration")
    cv2.setMouseCallback("calibration", on_mouse)

    results = [collect_phase(cap, title, n) for title, n in PHASES]
    cap.release(); cv2.destroyAllWindows()

    ws_px, tray, red_b, orange_b, yellow_b = results

    print("\nEnter the REAL workspace size (measure with a ruler):")
    w_mm = ask_float("  width  (TL->TR) in mm: ")
    h_mm = ask_float("  height (TL->BL) in mm: ")
    world = [[0, 0], [w_mm, 0], [w_mm, h_mm], [0, h_mm]]

    H, _ = cv2.findHomography(np.array(ws_px, np.float32),
                              np.array(world, np.float32))
    if H is None:
        print("Homography failed — corners collinear? Re-run."); sys.exit(1)

    # quick sanity check
    tl = cv2.perspectiveTransform(
        np.array([[ws_px[0]]], np.float64), H)[0, 0]
    print(f"Sanity: TL corner maps to ({tl[0]:.1f}, {tl[1]:.1f}) mm "
          "(should be ~0, 0)")

    print("\nArm base position in WORKSPACE mm "
          "(where the base axis meets the table):")
    bx = ask_float("  base X mm: ")
    by = ask_float("  base Y mm: ")

    drops: Dict[str, Any] = {}
    for name in ("red_bucket", "orange_bucket", "yellow_bucket"):
        print(f"\nDrop position for {name} (workspace mm, "
              "inside the bucket opening):")
        drops[name] = {
            "x_mm": ask_float("  x mm: "),
            "y_mm": ask_float("  y mm: "),
            "approach_z_mm": ask_float("  approach Z mm (e.g. 140): "),
            "release_z_mm": ask_float("  release Z mm (e.g. 100): "),
            "gripper_orientation_deg": 90,
            "waypoint": None,
        }

    out = {
        "camera_index": int(cam["index"]),
        "image_width": int(cam["width"]),
        "image_height": int(cam["height"]),
        "image_points": ws_px,
        "world_points_mm": world,
        "workspace_width_mm": w_mm,
        "workspace_height_mm": h_mm,
        "homography": H.tolist(),
        "arm_base_position_mm": {"x": bx, "y": by},
        "source_tray_polygon_px": tray,
        "red_bucket_polygon_px": red_b,
        "orange_bucket_polygon_px": orange_b,
        "yellow_bucket_polygon_px": yellow_b,
        "bucket_drop_positions": drops,
    }
    path = os.path.join(PROJECT_ROOT, cfg["calibration"]["file"])
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved {path} ✔  Restart the backend to load it.")


if __name__ == "__main__":
    main()
