"""main.py — entry point: config, shared state, sorting state machine,
Flask dashboard (HTML embedded below). Run:  python3 python/main.py
"""
from __future__ import annotations
from robot import (RobotBridge, BridgeError, InverseKinematics,
                   IKError, MotionPlanner, MotionStep)
from vision import (Camera, FruitDetector, ColorVerifier,
                    StabilityTracker, Workspace, build_workspace)

# ==================================================================
# ==== from config_loader.py ====
# ==================================================================
"""Load and validate config/config.yaml and config/calibration.json.

Every module reads configuration through this file so that there is exactly
one source of truth. Placeholder values like "[MEASURE_UPPER_ARM_MM]" are
detected and reported clearly instead of crashing later with a math error.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional

import yaml

log = logging.getLogger("config")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "config.yaml")


class ConfigError(Exception):
    """Raised when the configuration is missing or invalid."""


def _is_placeholder(value: Any) -> bool:
    """A placeholder is a string like "[MEASURE_UPPER_ARM_MM]"."""
    return isinstance(value, str) and value.startswith("[") and value.endswith("]")


def load_config(path: str = CONFIG_PATH) -> Dict[str, Any]:
    """Read config.yaml, validate the parts needed at startup.

    Placeholders in the robot geometry are ALLOWED at load time (so that
    dry-run camera/YOLO testing works before the arm is measured) but the
    list of unresolved placeholders is stored under config["_placeholders"]
    and real motion is blocked while it is non-empty.
    """
    if not os.path.exists(path):
        raise ConfigError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        cfg: Dict[str, Any] = yaml.safe_load(f)

    placeholders: List[str] = []

    def walk(node: Any, trail: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{trail}.{k}" if trail else str(k))
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{trail}[{i}]")
        elif _is_placeholder(node):
            placeholders.append(f"{trail} = {node}")

    walk(cfg, "")
    cfg["_placeholders"] = placeholders
    if placeholders:
        log.warning("Unmeasured placeholders present (motion will be blocked):")
        for p in placeholders:
            log.warning("  %s", p)

    _validate(cfg)
    return cfg


def _validate(cfg: Dict[str, Any]) -> None:
    """Fail fast on structural problems."""
    for section in ("camera", "yolo", "hsv", "servos", "heights",
                    "gripper", "motion", "stability", "fruit_rules", "web"):
        if section not in cfg:
            raise ConfigError(f"Missing config section: {section}")

    for name in ("base", "shoulder", "elbow", "wrist_pitch", "wrist_rot", "gripper"):
        s = cfg["servos"].get(name)
        if s is None:
            raise ConfigError(f"Missing servo config: {name}")
        if not (0 <= s["min"] < s["max"] <= 180):
            raise ConfigError(f"Servo '{name}' limits invalid: {s['min']}..{s['max']}")
        if not (s["min"] <= s["home"] <= s["max"]):
            raise ConfigError(f"Servo '{name}' home {s['home']} outside limits")
        if s["direction"] not in (1, -1):
            raise ConfigError(f"Servo '{name}' direction must be 1 or -1")

    g = cfg["gripper"]
    lim = cfg["servos"]["gripper"]
    for key in ("GRIPPER_OPEN_ANGLE", "GRIPPER_CLOSED_ANGLE", "GRIPPER_RELEASE_ANGLE"):
        if not (lim["min"] <= g[key] <= lim["max"]):
            raise ConfigError(f"{key}={g[key]} outside gripper servo limits")


def robot_geometry_ready(cfg: Dict[str, Any]) -> bool:
    """True when every geometry placeholder has been replaced by a number."""
    return not any("robot." in p or "MEASURE" in p for p in cfg["_placeholders"])


def load_calibration(cfg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Load calibration.json if it exists; return None if not calibrated yet."""
    path = os.path.join(PROJECT_ROOT, cfg["calibration"]["file"])
    if not os.path.exists(path):
        log.warning("Calibration file missing: %s (motion blocked)", path)
        return None
    with open(path, "r", encoding="utf-8") as f:
        cal = json.load(f)
    required = ("homography", "image_points", "world_points_mm",
                "source_tray_polygon_px", "red_bucket_polygon_px",
                "orange_bucket_polygon_px", "yellow_bucket_polygon_px",
                "bucket_drop_positions")
    for key in required:
        if key not in cal:
            raise ConfigError(f"calibration.json missing key: {key}")
    return cal

# ==================================================================
# ==== from shared_state.py ====
# ==================================================================
"""Thread-safe shared state.

Three threads touch this object:
  1. the perception thread (camera + YOLO + HSV),
  2. the robot state-machine thread,
  3. Flask request handlers.
Every read/write goes through the lock. Nothing outside this class should
hold references to the mutable internals.
"""

import threading
import time
from collections import deque
from typing import Any, Dict, List, Optional


class SharedState:
    def __init__(self, max_log: int = 200) -> None:
        self._lock = threading.RLock()
        self._frame_jpeg: Optional[bytes] = None
        self._detections: List[Dict[str, Any]] = []
        self._robot_state: str = "IDLE"
        self._servo_angles: Dict[str, float] = {}
        self._target: Optional[Dict[str, Any]] = None
        self._error: str = ""
        self._counts: Dict[str, int] = {"apple": 0, "orange": 0, "banana": 0}
        self._last_sorted: str = ""
        self._logs: deque = deque(maxlen=max_log)
        self._flags = {
            "auto_mode": False,
            "estop": False,
            "stop_requested": False,
            "calibrated": False,
            "bridge_ok": False,
            "dry_run": True,
            "motion_busy": False,
        }

    # ---- frame -------------------------------------------------
    def set_frame(self, jpeg: bytes) -> None:
        with self._lock:
            self._frame_jpeg = jpeg

    def get_frame(self) -> Optional[bytes]:
        with self._lock:
            return self._frame_jpeg

    # ---- detections & target ----------------------------------
    def set_detections(self, dets: List[Dict[str, Any]]) -> None:
        with self._lock:
            self._detections = dets

    def get_detections(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._detections)

    def set_target(self, target: Optional[Dict[str, Any]]) -> None:
        with self._lock:
            self._target = dict(target) if target else None

    def get_target(self) -> Optional[Dict[str, Any]]:
        with self._lock:
            return dict(self._target) if self._target else None

    # ---- robot ------------------------------------------------
    def set_robot_state(self, state: str) -> None:
        with self._lock:
            self._robot_state = state

    def get_robot_state(self) -> str:
        with self._lock:
            return self._robot_state

    def set_angles(self, angles: Dict[str, float]) -> None:
        with self._lock:
            self._servo_angles = dict(angles)

    def get_angles(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._servo_angles)

    # ---- flags ------------------------------------------------
    def set_flag(self, name: str, value: bool) -> None:
        with self._lock:
            self._flags[name] = value

    def get_flag(self, name: str) -> bool:
        with self._lock:
            return bool(self._flags.get(name, False))

    # ---- errors / logs / counts -------------------------------
    def set_error(self, msg: str) -> None:
        with self._lock:
            self._error = msg
        if msg:
            self.log(f"ERROR: {msg}")

    def log(self, msg: str) -> None:
        with self._lock:
            self._logs.appendleft(
                {"t": time.strftime("%H:%M:%S"), "msg": msg})

    def increment_count(self, fruit: str) -> None:
        with self._lock:
            self._counts[fruit] = self._counts.get(fruit, 0) + 1
            self._last_sorted = fruit

    # ---- snapshot for the dashboard ---------------------------
    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "robot_state": self._robot_state,
                "servo_angles": dict(self._servo_angles),
                "target": dict(self._target) if self._target else None,
                "error": self._error,
                "counts": dict(self._counts),
                "last_sorted": self._last_sorted,
                "flags": dict(self._flags),
                "detections": list(self._detections),
            }

    def get_logs(self) -> List[Dict[str, str]]:
        with self._lock:
            return list(self._logs)

# ==================================================================
# ==== from state_machine.py ====
# ==================================================================
"""High-level robot control: perception loop + explicit pick-and-place
state machine.

States:
  IDLE, HOMING, SCANNING, TARGET_LOCKED, CALCULATING,
  MOVING_TO_PRE_GRASP, OPENING_GRIPPER, DESCENDING, CLOSING_GRIPPER,
  LIFTING, MOVING_TO_BUCKET, RELEASING, RETURNING_HOME, STOPPED, ERROR

The arm NEVER moves just because a detection exists. Motion happens only
when every item in _motion_preconditions() passes.
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import cv2


log = logging.getLogger("robot")


class RobotController:
    def __init__(self, cfg: Dict[str, Any], state: SharedState,
                 camera: Camera, detector: FruitDetector,
                 colors: ColorVerifier, tracker: StabilityTracker,
                 workspace: Optional[Workspace],
                 ik: Optional[InverseKinematics],
                 planner: Optional[MotionPlanner],
                 bridge: RobotBridge) -> None:
        self.cfg = cfg
        self.s = state
        self.camera = camera
        self.detector = detector
        self.colors = colors
        self.tracker = tracker
        self.workspace = workspace
        self.ik = ik
        self.planner = planner
        self.bridge = bridge
        self._shutdown = threading.Event()
        self.move_timeout = float(cfg["motion"]["move_timeout_s"])
        self.retry_enabled = bool(cfg["failure"]["retry_enabled"])
        self.max_retries = int(cfg["failure"]["max_retry_count"])
        self.reappear_px = float(cfg["failure"]["reappear_radius_px"])
        self._retries_for_target = 0

        self.s.set_flag("dry_run", bool(cfg["dry_run"]))
        self.s.set_flag("calibrated", workspace is not None)
        self.s.set_flag("bridge_ok", bridge.ping())
        self.s.set_angles(planner.home_angles() if planner else {})

    # ==========================================================
    # Perception thread
    # ==========================================================
    def perception_loop(self) -> None:
        period = 1.0 / max(1, int(self.cfg["camera"]["fps"]))
        while not self._shutdown.is_set():
            t0 = time.time()
            frame = self.camera.grab()
            if frame is None:
                if self.camera.is_stalled():
                    self.s.set_error("Camera timeout — no frames received")
                time.sleep(0.2)
                continue
            try:
                raw = self.detector.detect(frame)
            except Exception as exc:  # noqa: BLE001 — YOLO must not kill us
                self.s.set_error(f"YOLO exception: {exc}")
                raw = []

            valid: List[Dict[str, Any]] = []
            annotated: List[Dict[str, Any]] = []
            for det in raw:
                cres = self.colors.verify(frame, det)
                u, v = det["center"]
                in_tray = self.workspace.in_source_tray(u, v) \
                    if self.workspace else False
                in_bucket = self.workspace.in_any_bucket(u, v) \
                    if self.workspace else False
                ok = cres["valid"] and in_tray and not in_bucket
                d = {**det, "color": cres["color"],
                     "color_percent": cres["percent"],
                     "color_valid": cres["valid"],
                     "in_tray": in_tray, "in_bucket": in_bucket,
                     "accepted": ok}
                if self.workspace:
                    wx, wy = self.workspace.pixel_to_workspace(u, v)
                    d["workspace_mm"] = [round(wx, 1), round(wy, 1)]
                annotated.append(d)
                if ok:
                    valid.append(d)

            self.tracker.update(valid)
            self.s.set_detections(annotated)
            self._draw(frame, annotated)
            ok_enc, jpeg = cv2.imencode(
                ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            if ok_enc:
                self.s.set_frame(jpeg.tobytes())
            dt = time.time() - t0
            if dt < period:
                time.sleep(period - dt)
        self.camera.release()

    def _draw(self, frame, dets: List[Dict[str, Any]]) -> None:
        if self.workspace:
            self.workspace.draw_regions(frame)
        for d in dets:
            x1, y1, x2, y2 = [int(v) for v in d["box"]]
            col = (0, 255, 0) if d["accepted"] else (0, 0, 255)
            cv2.rectangle(frame, (x1, y1), (x2, y2), col, 2)
            cv2.putText(frame,
                        f"{d['label']} {d['confidence']:.2f} "
                        f"{d['color']} {d['color_percent']:.0f}%",
                        (x1, max(15, y1 - 6)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 2)
        cv2.putText(frame, self.s.get_robot_state(), (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    # ==========================================================
    # Robot thread
    # ==========================================================
    def robot_loop(self) -> None:
        self.s.set_robot_state("IDLE")
        while not self._shutdown.is_set():
            if self.s.get_flag("estop"):
                self.s.set_robot_state("STOPPED")
                time.sleep(0.2)
                continue
            if not self.s.get_flag("auto_mode"):
                if self.s.get_robot_state() not in ("STOPPED", "ERROR", "IDLE"):
                    self.s.set_robot_state("IDLE")
                time.sleep(0.2)
                continue
            try:
                self._auto_cycle()
            except (BridgeError, IKError, RuntimeError) as exc:
                self._recoverable_error(str(exc))
            except Exception as exc:  # noqa: BLE001 — last-resort guard
                log.exception("Unexpected error")
                self._recoverable_error(f"Unexpected: {exc}")

    def _recoverable_error(self, msg: str) -> None:
        self.s.set_error(msg)
        self.s.set_robot_state("ERROR")
        try:
            if not self.cfg["dry_run"]:
                self._go_home("RETURNING_HOME")
        except BridgeError as exc:
            log.error("Could not return home after error: %s", exc)
        self.s.set_flag("auto_mode", False)
        self.s.set_robot_state("ERROR")

    # ---- precondition gate -----------------------------------
    def _motion_preconditions(self) -> Tuple[bool, str]:
        checks = [
            (self.workspace is not None, "calibration not loaded"),
            (self.ik is not None and robot_geometry_ready(self.cfg),
             "robot geometry placeholders not measured yet"),
            (self.s.get_flag("bridge_ok"), "Bridge health check failed"),
            (not self.s.get_flag("estop"), "emergency stop active"),
            (self.s.get_flag("auto_mode"), "automatic mode not enabled"),
            (not self.camera.is_stalled(), "camera stalled"),
        ]
        for ok, why in checks:
            if not ok:
                return False, why
        # every configured bucket must be reachable BEFORE we pick anything
        for name in ("red_bucket", "orange_bucket", "yellow_bucket"):
            drop = self.workspace.drop_position(name)
            rx, ry = self.workspace.workspace_to_robot(
                float(drop["x_mm"]), float(drop["y_mm"]))
            ok, why = self.ik.check_reachable(
                rx, ry, float(drop["release_z_mm"]))
            if not ok:
                return False, f"{name} unreachable: {why}"
        return True, "ok"

    # ---- one full scan->pick->place cycle ---------------------
    def _auto_cycle(self) -> None:
        ok, why = self._motion_preconditions()
        if not ok:
            self.s.set_error(f"Motion blocked: {why}")
            self.s.set_flag("auto_mode", False)
            return
        self.s.set_error("")

        self._go_home("HOMING")
        self.s.set_robot_state("SCANNING")

        target = self._wait_for_stable_target()
        if target is None:
            return  # stop pressed or auto disabled while scanning

        self.s.set_robot_state("TARGET_LOCKED")
        self.s.set_target(target)
        self.s.log(f"Locked {target['label']} ({target['color']}) "
                   f"conf={target['confidence']:.2f}")

        self.s.set_robot_state("CALCULATING")
        rx, ry = target["robot_xy"]
        fruit = target["label"]
        bucket = self.cfg["fruit_rules"][fruit]["bucket"]
        drop_ws = self.workspace.drop_position(bucket)
        drx, dry_ = self.workspace.workspace_to_robot(
            float(drop_ws["x_mm"]), float(drop_ws["y_mm"]))
        drop = {**drop_ws, "x_mm": drx, "y_mm": dry_}
        if drop.get("waypoint"):
            wx, wy = self.workspace.workspace_to_robot(
                float(drop["waypoint"]["x_mm"]),
                float(drop["waypoint"]["y_mm"]))
            drop["waypoint"] = {**drop["waypoint"], "x_mm": wx, "y_mm": wy}

        pick_steps = self.planner.plan_pick(rx, ry, fruit)
        place_steps = self.planner.plan_place(drop)

        for step in pick_steps + place_steps:
            if self._should_abort():
                raise RuntimeError("Stop requested during motion")
            self._execute(step)

        self._go_home("RETURNING_HOME")
        self._check_pickup_result(target, fruit)
        self.s.set_target(None)
        self.s.set_robot_state("SCANNING")

    def _wait_for_stable_target(self) -> Optional[Dict[str, Any]]:
        def reach_check(track):
            u, v = track["center"]
            wx, wy = self.workspace.pixel_to_workspace(u, v)
            rx, ry = self.workspace.workspace_to_robot(wx, wy)
            z = float(self.cfg["heights"]["PICK_Z"])
            ok, _ = self.ik.check_reachable(rx, ry, z)
            return ok, (rx, ry)

        while not self._should_abort():
            stable = self.tracker.stable_tracks()
            target = self.tracker.select_target(stable, reach_check)
            if target is not None:
                return target
            time.sleep(0.1)
        return None

    def _execute(self, step: MotionStep) -> None:
        self.s.set_robot_state(step.name)
        if self.cfg["dry_run"]:
            self.s.log(f"[dry-run] {step.name}: {step.angles}")
            self.s.set_angles(step.angles)
            time.sleep(0.3)
        else:
            self.bridge.move_all(step.angles)
            self.bridge.wait_until_idle(self.move_timeout,
                                        stop_flag=self._should_abort)
            self.s.set_angles(self.bridge.get_angles())
        if step.pause_s:
            time.sleep(step.pause_s)

    def _go_home(self, state_name: str) -> None:
        self.s.set_robot_state(state_name)
        home = self.planner.home_angles()
        if self.cfg["dry_run"]:
            self.s.set_angles(home)
            time.sleep(0.3)
            return
        self.bridge.move_all(home)
        self.bridge.wait_until_idle(self.move_timeout,
                                    stop_flag=self._should_abort)
        self.s.set_angles(self.bridge.get_angles())

    def _check_pickup_result(self, target: Dict[str, Any],
                             fruit: str) -> None:
        """No force/gripper sensor exists, so after the drop we look at the
        tray: if the SAME fruit is still visible near its old position the
        pickup probably failed."""
        time.sleep(0.5)  # let the tracker see a fresh frame from home pose
        if self.tracker.fruit_near(target["center"], self.reappear_px):
            self.s.log(f"Possible pickup FAILURE for {fruit} "
                       f"(still visible in tray)")
            if self.retry_enabled and \
                    self._retries_for_target < self.max_retries:
                self._retries_for_target += 1
                self.s.log(f"Retry {self._retries_for_target}"
                           f"/{self.max_retries} enabled")
            else:
                self._retries_for_target = 0
                if self.retry_enabled:
                    raise RuntimeError(
                        f"Pickup failed {self.max_retries + 1}x — stopping "
                        "to avoid an infinite retry loop")
        else:
            self._retries_for_target = 0
            self.s.increment_count(fruit)
            self.s.log(f"Sorted {fruit} ✔")

    def _should_abort(self) -> bool:
        return (self.s.get_flag("stop_requested")
                or self.s.get_flag("estop")
                or not self.s.get_flag("auto_mode")
                or self._shutdown.is_set())

    # ==========================================================
    # Commands from the web API
    # ==========================================================
    def cmd_start(self) -> Tuple[bool, str]:
        ok, why = self._motion_preconditions_precheck()
        if not ok:
            return False, why
        self.s.set_flag("stop_requested", False)
        self.s.set_flag("auto_mode", True)
        self.s.log("Automatic sorting STARTED")
        return True, "started"

    def _motion_preconditions_precheck(self) -> Tuple[bool, str]:
        if self.s.get_flag("estop"):
            return False, "Clear the emergency stop first"
        if self.workspace is None:
            return False, "Run workspace calibration first"
        if self.ik is None or not robot_geometry_ready(self.cfg):
            return False, "Measure the arm and fill the geometry placeholders"
        if not self.cfg["dry_run"] and not self.bridge.ping():
            self.s.set_flag("bridge_ok", False)
            return False, "Bridge health check failed"
        self.s.set_flag("bridge_ok", True)
        return True, "ok"

    def cmd_stop(self) -> None:
        self.s.set_flag("stop_requested", True)
        self.s.set_flag("auto_mode", False)
        try:
            if not self.cfg["dry_run"]:
                self.bridge.stop()
        except BridgeError as exc:
            self.s.set_error(f"Stop send failed: {exc}")
        self.s.set_robot_state("STOPPED")
        self.s.log("STOP")

    def cmd_estop(self) -> None:
        self.s.set_flag("estop", True)
        self.s.set_flag("auto_mode", False)
        try:
            if not self.cfg["dry_run"]:
                self.bridge.estop()
        except BridgeError as exc:
            self.s.set_error(f"E-stop send failed: {exc}")
        self.s.set_robot_state("STOPPED")
        self.s.log("EMERGENCY STOP")

    def cmd_clear_estop(self) -> Tuple[bool, str]:
        try:
            if not self.cfg["dry_run"]:
                moving, _, _ = self.bridge.status()
                if moving:
                    return False, "Arm still moving — cannot clear e-stop"
                self.bridge.clear_estop()
            self.s.set_flag("estop", False)
            self.s.set_robot_state("IDLE")
            self.s.log("Emergency stop cleared")
            return True, "cleared"
        except BridgeError as exc:
            return False, str(exc)

    def cmd_home(self) -> Tuple[bool, str]:
        if self.s.get_flag("auto_mode"):
            return False, "Press Stop before manual commands"
        if self.s.get_flag("estop"):
            return False, "Emergency stop active"
        try:
            self._go_home("HOMING")
            self.s.set_robot_state("IDLE")
            return True, "homed"
        except BridgeError as exc:
            return False, str(exc)

    def cmd_set_servo(self, joint: str, angle: float) -> Tuple[bool, str]:
        if self.s.get_flag("auto_mode"):
            return False, "Press Stop before manual commands"
        if self.s.get_flag("estop"):
            return False, "Emergency stop active"
        s = self.cfg["servos"].get(joint)
        if s is None:
            return False, f"Unknown joint {joint}"
        if not (s["min"] <= angle <= s["max"]):
            return False, f"{joint} limit is {s['min']}–{s['max']}°"
        try:
            if self.cfg["dry_run"]:
                a = self.s.get_angles(); a[joint] = angle
                self.s.set_angles(a)
            else:
                self.bridge.move_joint(joint, angle)
                self.bridge.wait_until_idle(self.move_timeout)
                self.s.set_angles(self.bridge.get_angles())
            return True, "ok"
        except BridgeError as exc:
            return False, str(exc)

    def cmd_jog(self, axis: str, delta_mm: float) -> Tuple[bool, str]:
        """Cartesian jog: X+/X-/Y+/Y-/Z+/Z- from the CURRENT pose is
        approximated by tracking a virtual cartesian setpoint."""
        if self.s.get_flag("auto_mode"):
            return False, "Press Stop before manual commands"
        if self.workspace is None or self.ik is None:
            return False, "Calibrate and measure the arm first"
        if not hasattr(self, "_jog_xyz"):
            self._jog_xyz = [150.0, 0.0, float(self.cfg["heights"]["SAFE_Z"])]
        i = {"x": 0, "y": 1, "z": 2}.get(axis)
        if i is None:
            return False, "axis must be x, y, or z"
        trial = list(self._jog_xyz)
        trial[i] += delta_mm
        try:
            res = self.ik.solve(trial[0], trial[1], trial[2],
                                gripper_angle=self.s.get_angles()
                                .get("gripper"))
        except IKError as exc:
            return False, f"Unreachable: {exc}"
        self._jog_xyz = trial
        if self.cfg["dry_run"]:
            self.s.set_angles(res.servo_angles)
            return True, f"dry-run jog to {trial}"
        try:
            self.bridge.move_all(res.servo_angles)
            self.bridge.wait_until_idle(self.move_timeout)
            self.s.set_angles(self.bridge.get_angles())
            return True, f"jogged to {['%.0f' % v for v in trial]} mm"
        except BridgeError as exc:
            return False, str(exc)

    def shutdown(self) -> None:
        self._shutdown.set()
        try:
            if not self.cfg["dry_run"]:
                self.bridge.stop()
        except BridgeError:
            pass

# ==================================================================
# ==== from webapp.py ====
# ==================================================================
"""Flask backend: dashboard, MJPEG video feed, REST API, SSE updates."""

import json
import logging
import os
import time
from typing import Any, Dict

from flask import Flask, Response, jsonify, request


log = logging.getLogger("web")

def create_app(cfg: Dict[str, Any], state: SharedState,
               robot: RobotController) -> Flask:
    app = Flask(__name__)

    # ---- pages & streams --------------------------------------
    @app.get("/")
    def index() -> Response:
        return Response(DASHBOARD_HTML, mimetype="text/html")

    @app.get("/video_feed")
    def video_feed() -> Response:
        def gen():
            while True:
                jpeg = state.get_frame()
                if jpeg is None:
                    time.sleep(0.1)
                    continue
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"
                       + jpeg + b"\r\n")
                time.sleep(1.0 / max(1, int(cfg["camera"]["fps"])))
        return Response(gen(),
                        mimetype="multipart/x-mixed-replace; boundary=frame")

    @app.get("/api/stream")
    def sse() -> Response:
        def gen():
            while True:
                yield f"data: {json.dumps(state.snapshot())}\n\n"
                time.sleep(0.5)
        return Response(gen(), mimetype="text/event-stream")

    # ---- read APIs --------------------------------------------
    @app.get("/api/status")
    def status():
        return jsonify(state.snapshot())

    @app.get("/api/detections")
    def detections():
        return jsonify(state.get_detections())

    @app.get("/api/logs")
    def logs():
        return jsonify(state.get_logs())

    # ---- command APIs -----------------------------------------
    @app.post("/api/start")
    def start():
        ok, msg = robot.cmd_start()
        return jsonify({"ok": ok, "message": msg}), 200 if ok else 409

    @app.post("/api/stop")
    def stop():
        robot.cmd_stop()
        return jsonify({"ok": True, "message": "stopped"})

    @app.post("/api/emergency-stop")
    def estop():
        robot.cmd_estop()
        return jsonify({"ok": True, "message": "EMERGENCY STOP"})

    @app.post("/api/clear-estop")
    def clear_estop():
        ok, msg = robot.cmd_clear_estop()
        return jsonify({"ok": ok, "message": msg}), 200 if ok else 409

    @app.post("/api/home")
    def home():
        ok, msg = robot.cmd_home()
        return jsonify({"ok": ok, "message": msg}), 200 if ok else 409

    @app.post("/api/jog")
    def jog():
        data = request.get_json(silent=True) or {}
        axis = str(data.get("axis", "")).lower()
        try:
            delta = float(data.get("delta_mm", 0))
        except (TypeError, ValueError):
            return jsonify({"ok": False, "message": "delta_mm must be a "
                            "number"}), 400
        if axis not in ("x", "y", "z") or not (-50 <= delta <= 50):
            return jsonify({"ok": False,
                            "message": "axis x|y|z, delta_mm within ±50"}), 400
        ok, msg = robot.cmd_jog(axis, delta)
        return jsonify({"ok": ok, "message": msg}), 200 if ok else 409

    @app.post("/api/set-servo")
    def set_servo():
        data = request.get_json(silent=True) or {}
        joint = str(data.get("joint", ""))
        try:
            angle = float(data.get("angle"))
        except (TypeError, ValueError):
            return jsonify({"ok": False, "message": "angle must be a "
                            "number"}), 400
        ok, msg = robot.cmd_set_servo(joint, angle)
        return jsonify({"ok": ok, "message": msg}), 200 if ok else 409

    @app.get("/api/ui-config")
    def ui_config():
        g = cfg["gripper"]
        return jsonify({
            "gripper_open": g["GRIPPER_OPEN_ANGLE"],
            "gripper_closed": g["GRIPPER_CLOSED_ANGLE"],
            "servo_limits": {j: [cfg["servos"][j]["min"],
                                 cfg["servos"][j]["max"]]
                             for j in ("base", "shoulder", "elbow",
                                       "wrist_pitch", "wrist_rot",
                                       "gripper")},
        })

    @app.get("/api/calibration-status")
    def calib_status():
        return jsonify({
            "calibrated": state.get_flag("calibrated"),
            "geometry_placeholders": cfg["_placeholders"],
        })

    return app


# ==================================================================
# ==== embedded dashboard (was frontend/) ====
# ==================================================================
DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fruit Sorter — Control</title>
<style>
/* Fruit Sorter dashboard — dark control-room theme.
   Palette: ink navy background, purple accents, signal orange for
   attention, safety red reserved ONLY for the emergency stop. */
:root {
  --bg: #0d1021;
  --card: #171b33;
  --card-edge: #262c52;
  --text: #e7e9f5;
  --muted: #8b91b5;
  --accent: #8f7bf0;
  --orange: #ff9b45;
  --ok: #4bd88a;
  --danger: #ff4b4b;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: "Segoe UI", Roboto, system-ui, sans-serif;
  padding: 14px;
}
header { display: flex; justify-content: space-between; align-items: center;
  flex-wrap: wrap; gap: 10px; margin-bottom: 14px; }
h1 { font-size: 1.35rem; letter-spacing: 0.18em;
  background: linear-gradient(90deg, var(--accent), var(--orange));
  -webkit-background-clip: text; background-clip: text; color: transparent; }
h2 { font-size: 0.95rem; color: var(--muted); text-transform: uppercase;
  letter-spacing: 0.1em; margin-bottom: 10px; }
h3 { font-size: 0.85rem; color: var(--muted); margin: 14px 0 6px; }

.badge { background: var(--card-edge); border-radius: 999px;
  padding: 4px 12px; font-size: 0.8rem; }
.badge.ok { background: #123c28; color: var(--ok); }
.badge.warn { background: #3c2a12; color: var(--orange); }
.badge.bad { background: #3c1212; color: var(--danger); }

main { display: grid; grid-template-columns: 1.4fr 1fr; gap: 14px; }
@media (max-width: 900px) { main { grid-template-columns: 1fr; } }

.panel { background: var(--card); border: 1px solid var(--card-edge);
  border-radius: 12px; padding: 14px; }
#videoFeed { width: 100%; border-radius: 8px; background: #000;
  min-height: 200px; }

.dettable { margin-top: 10px; font-size: 0.82rem; }
.dettable .det { display: grid;
  grid-template-columns: 1fr 1fr 1fr 1.4fr; gap: 6px;
  padding: 5px 8px; border-radius: 6px; margin-bottom: 4px;
  background: var(--card-edge); }
.dettable .det.rej { opacity: 0.45; }

button { background: var(--card-edge); color: var(--text); border: none;
  border-radius: 8px; padding: 10px 14px; font-size: 0.9rem;
  cursor: pointer; }
button:hover { filter: brightness(1.25); }
button:focus-visible { outline: 2px solid var(--accent); }
button.primary { background: var(--accent); color: #0d1021; font-weight: 700; }
button.estop { width: 100%; background: var(--danger); color: #fff;
  font-size: 1.15rem; font-weight: 800; padding: 18px;
  letter-spacing: 0.1em; margin-bottom: 12px; }
.row { display: flex; gap: 8px; flex-wrap: wrap; }

.joggrid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.servos .servo { display: grid;
  grid-template-columns: 90px 1fr 52px; gap: 8px; align-items: center;
  margin-bottom: 6px; font-size: 0.82rem; }
.servos input[type=range] { width: 100%; accent-color: var(--accent); }

.counters { display: flex; gap: 10px; }
.counter { flex: 1; text-align: center; background: var(--card-edge);
  border-radius: 8px; padding: 10px; font-size: 1.1rem; }
.lastsorted { margin-top: 8px; color: var(--muted); font-size: 0.85rem; }
.error { color: var(--danger); margin-top: 10px; font-size: 0.85rem;
  min-height: 1.2em; }

.logs-panel { margin-top: 14px; max-height: 240px; overflow-y: auto; }
#logList { list-style: none; font-size: 0.8rem; }
#logList li { padding: 3px 0; border-bottom: 1px solid var(--card-edge);
  color: var(--muted); }
#logList li .t { color: var(--orange); margin-right: 8px; }
@media (prefers-reduced-motion: reduce) { * { transition: none !important; } }

</style>
</head>
<body>
<header>
  <h1>FRUIT SORTER</h1>
  <div class="statusline">
    <span id="stateBadge" class="badge">—</span>
    <span id="modeBadge" class="badge">—</span>
    <span id="calibBadge" class="badge">—</span>
    <span id="bridgeBadge" class="badge">—</span>
  </div>
</header>

<main>
  <!-- LEFT: camera + detections -->
  <section class="panel camera-panel">
    <h2>Live camera</h2>
    <img id="videoFeed" src="/video_feed" alt="Live camera feed">
    <div id="detTable" class="dettable"></div>
  </section>

  <!-- RIGHT: controls -->
  <section class="panel control-panel">
    <h2>Controls</h2>
    <button id="btnEstop" class="estop">EMERGENCY STOP</button>
    <div class="row">
      <button id="btnStart" class="primary">Start</button>
      <button id="btnStop">Stop</button>
      <button id="btnHome">Home</button>
      <button id="btnClearEstop">Clear E-stop</button>
    </div>

    <h3>Manual jog (mm)</h3>
    <div class="joggrid">
      <button class="jog" data-axis="x" data-delta="10">X+</button>
      <button class="jog" data-axis="x" data-delta="-10">X−</button>
      <button class="jog" data-axis="y" data-delta="10">Y+</button>
      <button class="jog" data-axis="y" data-delta="-10">Y−</button>
      <button class="jog" data-axis="z" data-delta="10">Z+</button>
      <button class="jog" data-axis="z" data-delta="-10">Z−</button>
      <button id="btnGripOpen">Gripper open</button>
      <button id="btnGripClose">Gripper close</button>
    </div>

    <h3>Servo test</h3>
    <div id="servoControls" class="servos"></div>

    <h3>Counters</h3>
    <div class="counters">
      <div class="counter apple">🍎 <span id="cntApple">0</span></div>
      <div class="counter orange">🍊 <span id="cntOrange">0</span></div>
      <div class="counter banana">🍌 <span id="cntBanana">0</span></div>
    </div>
    <p class="lastsorted">Last sorted: <span id="lastSorted">—</span></p>
    <p id="errorBox" class="error"></p>
  </section>
</main>

<section class="panel logs-panel">
  <h2>Detection log</h2>
  <ul id="logList"></ul>
</section>

<script>
/* Fruit Sorter dashboard logic — plain JS, no framework. */
"use strict";

const JOINTS = ["base", "shoulder", "elbow", "wrist_pitch",
                "wrist_rot", "gripper"];

const $ = (id) => document.getElementById(id);

// ---------- API helpers -------------------------------------
async function post(path, body) {
  try {
    const res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : null,
    });
    const data = await res.json();
    if (!data.ok) showError(data.message);
    else showError("");
    return data;
  } catch (err) {
    showError("Backend unreachable: " + err.message);
    return { ok: false };
  }
}

function showError(msg) { $("errorBox").textContent = msg || ""; }

// ---------- servo sliders -----------------------------------
function buildServoControls() {
  const box = $("servoControls");
  JOINTS.forEach((j) => {
    const row = document.createElement("div");
    row.className = "servo";
    row.innerHTML =
      `<span>${j}</span>` +
      `<input type="range" min="0" max="180" value="90" id="sl_${j}">` +
      `<span id="sv_${j}">90°</span>`;
    box.appendChild(row);
    const slider = row.querySelector("input");
    slider.addEventListener("change", () =>
      post("/api/set-servo", { joint: j, angle: Number(slider.value) }));
    slider.addEventListener("input", () =>
      ($("sv_" + j).textContent = slider.value + "°"));
  });
}

// ---------- status rendering --------------------------------
function setBadge(el, text, cls) {
  el.textContent = text;
  el.className = "badge " + (cls || "");
}

function render(s) {
  setBadge($("stateBadge"), s.robot_state,
    s.robot_state === "ERROR" ? "bad"
      : s.robot_state === "STOPPED" ? "warn" : "ok");
  setBadge($("modeBadge"),
    s.flags.estop ? "E-STOP" : s.flags.auto_mode ? "RUNNING"
      : s.flags.dry_run ? "DRY-RUN" : "MANUAL",
    s.flags.estop ? "bad" : s.flags.auto_mode ? "ok" : "warn");
  setBadge($("calibBadge"),
    s.flags.calibrated ? "Calibrated" : "NOT calibrated",
    s.flags.calibrated ? "ok" : "bad");
  setBadge($("bridgeBadge"),
    s.flags.bridge_ok ? "Bridge OK" : "Bridge DOWN",
    s.flags.bridge_ok ? "ok" : "bad");

  JOINTS.forEach((j) => {
    const a = s.servo_angles[j];
    if (a === undefined) return;
    const slider = $("sl_" + j);
    if (document.activeElement !== slider) slider.value = a;
    $("sv_" + j).textContent = Math.round(a) + "°";
  });

  $("cntApple").textContent = s.counts.apple;
  $("cntOrange").textContent = s.counts.orange;
  $("cntBanana").textContent = s.counts.banana;
  $("lastSorted").textContent = s.last_sorted || "—";
  if (s.error) showError(s.error);

  const box = $("detTable");
  box.innerHTML = "";
  (s.detections || []).forEach((d) => {
    const row = document.createElement("div");
    row.className = "det" + (d.accepted ? "" : " rej");
    const ws = d.workspace_mm
      ? `${d.workspace_mm[0]},${d.workspace_mm[1]}mm` : "no calib";
    row.innerHTML =
      `<span>${d.label} ${(d.confidence * 100).toFixed(0)}%</span>` +
      `<span>${d.color} ${d.color_percent.toFixed(0)}%</span>` +
      `<span>px ${Math.round(d.center[0])},${Math.round(d.center[1])}</span>` +
      `<span>${ws}${d.in_bucket ? " (in bucket)" : ""}` +
      `${d.accepted ? " ✔" : " ✖"}</span>`;
    box.appendChild(row);
  });
}

async function refreshLogs() {
  try {
    const res = await fetch("/api/logs");
    const logs = await res.json();
    $("logList").innerHTML = logs
      .map((l) => `<li><span class="t">${l.t}</span>${l.msg}</li>`)
      .join("");
  } catch (_e) { /* backend restarting — retry next tick */ }
}

// ---------- wiring ------------------------------------------
async function init() {
  buildServoControls();

  // Gripper angles and servo limits come from config.yaml via the API —
  // nothing is hardcoded here.
  let ui = { gripper_open: 60, gripper_closed: 118, servo_limits: {} };
  try { ui = await (await fetch("/api/ui-config")).json(); } catch (_e) {}
  JOINTS.forEach((j) => {
    const lim = ui.servo_limits[j];
    if (lim) { $("sl_" + j).min = lim[0]; $("sl_" + j).max = lim[1]; }
  });

  $("btnStart").onclick = () => post("/api/start");
  $("btnStop").onclick = () => post("/api/stop");
  $("btnHome").onclick = () => post("/api/home");
  $("btnEstop").onclick = () => post("/api/emergency-stop");
  $("btnClearEstop").onclick = () => post("/api/clear-estop");
  $("btnGripOpen").onclick = () =>
    post("/api/set-servo", { joint: "gripper", angle: ui.gripper_open });
  $("btnGripClose").onclick = () =>
    post("/api/set-servo", { joint: "gripper", angle: ui.gripper_closed });

  document.querySelectorAll(".jog").forEach((b) => {
    b.onclick = () => post("/api/jog", {
      axis: b.dataset.axis, delta_mm: Number(b.dataset.delta),
    });
  });

  const es = new EventSource("/api/stream");
  es.onmessage = (ev) => render(JSON.parse(ev.data));
  setInterval(refreshLogs, 2000);
  refreshLogs();
}

document.addEventListener("DOMContentLoaded", init);

</script>
</body>
</html>
"""


# ==================================================================
# ==== entry point ====
# ==================================================================
def setup_logging(cfg) -> None:
    os.makedirs(os.path.join(PROJECT_ROOT, "logs"), exist_ok=True)
    logging.basicConfig(
        level=getattr(logging, cfg["logging"]["level"].upper(), logging.INFO),
        format="%(asctime)s %(name)-10s %(levelname)-7s %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(
                os.path.join(PROJECT_ROOT, cfg["logging"]["file"])),
        ])


def main() -> None:
    cfg = load_config()
    setup_logging(cfg)
    log = logging.getLogger("main")
    log.info("=== Fruit Sorter starting (dry_run=%s) ===", cfg["dry_run"])

    state = SharedState(max_log=int(cfg["logging"]["max_detection_log"]))

    camera = Camera(cfg)
    camera.open()

    detector = FruitDetector(cfg)
    colors = ColorVerifier(cfg)
    tracker = StabilityTracker(cfg)

    cal = load_calibration(cfg)
    workspace = build_workspace(cal, cfg)

    ik = None
    planner = None
    if robot_geometry_ready(cfg):
        ik = InverseKinematics(cfg)
        planner = MotionPlanner(cfg, ik)
    else:
        log.warning("Robot geometry placeholders unmeasured — "
                    "camera/YOLO/HSV run, all motion is blocked.")

    bridge = RobotBridge(cfg, dry_run=bool(cfg["dry_run"]))
    if not cfg["dry_run"] and not bridge.is_mock:
        bridge.push_limits_and_speeds()

    robot = RobotController(cfg, state, camera, detector, colors, tracker,
                            workspace, ik, planner, bridge)

    threads = [
        threading.Thread(target=robot.perception_loop,
                         name="perception", daemon=True),
        threading.Thread(target=robot.robot_loop, name="robot", daemon=True),
    ]
    for t in threads:
        t.start()

    app = create_app(cfg, state, robot)

    def handle_sig(_sig, _frm):
        log.info("Shutting down…")
        robot.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    web = cfg["web"]
    log.info("Dashboard: http://<uno-q-ip>:%d", web["port"])
    app.run(host=web["host"], port=int(web["port"]),
            threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
