"""robot.py — everything that talks to / computes for the arm:
Bridge communication (MCU RPC), inverse kinematics, motion planning.
"""
from __future__ import annotations

# ==================================================================
# ==== from bridge.py ====
# ==================================================================
"""All Arduino UNO Q Bridge communication lives in THIS file only.

Official Bridge API used here (verified against Arduino docs, July 2026):
  * Python side (Linux/MPU):  `from arduino.app_utils import Bridge`
    — provided by Arduino App Lab's Python environment. `Bridge.call(name,
    *args)` performs a blocking RPC to a function that the MCU sketch
    registered with `Bridge.provide(...)`.
  * Arduino side (MCU): `#include <Arduino_RouterBridge.h>` — gives the
    `Bridge` singleton with `Bridge.begin()` / `Bridge.provide(...)`.
  * The router service owns the internal UART; never open Serial1 yourself.

Wire protocol (single RPC endpoint, plain-text — easy to debug):
  Python calls MCU function  "cmd" with ONE String argument, receives ONE
  String reply.
  Requests:   PING | HOME | MOVEALL:a0,a1,a2,a3,a4,a5 | MOVEONE:ch,angle
              | STOP | ESTOP | CLEARESTOP | GETANGLES | STATUS
              | LIMITS:ch,min,max | SPEED:ch,deg_per_s
  Replies:    OK:<CMD>|MOVING=<0/1>|ESTOP=<0/1>|A=a0,a1,a2,a3,a4,a5
              ERR:<CMD>|<human readable reason>

If `dry_run` is enabled, or the arduino.app_utils package is unavailable
(e.g. developing on a laptop), a MockBridge simulates the firmware so the
whole pipeline still runs without any hardware.
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("bridge")

CHANNEL_ORDER = ("base", "shoulder", "elbow", "wrist_pitch",
                 "wrist_rot", "gripper")


class BridgeError(Exception):
    """Raised on timeout, malformed reply, or firmware-reported error."""


class _MockBridge:
    """Simulates the firmware for dry-run mode and desktop development."""

    def __init__(self, homes: List[float]) -> None:
        self._angles = list(homes)
        self._estop = False

    def call(self, method: str, payload: str) -> str:
        assert method == "cmd"
        parts = payload.split(":", 1)
        cmd = parts[0]
        arg = parts[1] if len(parts) > 1 else ""
        if cmd == "ESTOP":
            self._estop = True
        elif cmd == "CLEARESTOP":
            self._estop = False
        elif self._estop and cmd not in ("PING", "STATUS", "GETANGLES"):
            return f"ERR:{cmd}|estop active"
        elif cmd == "MOVEALL":
            self._angles = [float(v) for v in arg.split(",")]
        elif cmd == "MOVEONE":
            ch, ang = arg.split(",")
            self._angles[int(ch)] = float(ang)
        elif cmd == "HOME":
            pass  # angles already treated as reached instantly
        a = ",".join(f"{v:.1f}" for v in self._angles)
        return f"OK:{cmd}|MOVING=0|ESTOP={int(self._estop)}|A={a}"


class RobotBridge:
    """Thread-safe wrapper. Only ONE motion sequence may run at a time;
    the state machine enforces that, this class enforces one RPC at a time.
    """

    def __init__(self, cfg: Dict[str, Any], dry_run: bool) -> None:
        self.cfg = cfg
        self.timeout = float(cfg["bridge"]["call_timeout_s"])
        self._lock = threading.Lock()
        self._homes = [float(cfg["servos"][j]["home"]) for j in CHANNEL_ORDER]
        self._impl: Any = None
        self._mock = False

        if dry_run:
            self._impl = _MockBridge(self._homes)
            self._mock = True
            log.warning("DRY RUN: using MockBridge, no servo will move.")
            return
        try:
            from arduino.app_utils import Bridge  # official App Lab package
            self._impl = Bridge
            log.info("Connected to Arduino UNO Q Bridge (arduino.app_utils).")
        except ImportError as exc:
            self._impl = _MockBridge(self._homes)
            self._mock = True
            log.error("arduino.app_utils not available (%s). Falling back "
                      "to MockBridge — NO real motion possible.", exc)

    # ---------------------------------------------------------
    @property
    def is_mock(self) -> bool:
        return self._mock

    def _raw(self, payload: str) -> str:
        """One serialized RPC with timeout supervision."""
        with self._lock:
            box: Dict[str, Any] = {}

            def runner() -> None:
                try:
                    box["reply"] = self._impl.call("cmd", payload)
                except Exception as exc:  # noqa: BLE001
                    box["error"] = exc

            th = threading.Thread(target=runner, daemon=True)
            th.start()
            th.join(self.timeout)
            if th.is_alive():
                raise BridgeError(f"Bridge timeout ({self.timeout}s) "
                                  f"for '{payload}'")
            if "error" in box:
                raise BridgeError(f"Bridge call failed: {box['error']}")
            reply = str(box.get("reply", ""))
            if not reply:
                raise BridgeError("Empty reply from firmware")
            return reply

    def _parse(self, reply: str) -> Dict[str, Any]:
        if reply.startswith("ERR:"):
            raise BridgeError(reply[4:])
        if not reply.startswith("OK:"):
            raise BridgeError(f"Malformed reply: {reply}")
        fields = reply[3:].split("|")
        out: Dict[str, Any] = {"cmd": fields[0]}
        for f in fields[1:]:
            if "=" not in f:
                continue
            k, v = f.split("=", 1)
            if k == "A":
                out["angles"] = [float(x) for x in v.split(",")]
            else:
                out[k.lower()] = v
        return out

    def command(self, payload: str) -> Dict[str, Any]:
        return self._parse(self._raw(payload))

    # ---- high-level helpers ----------------------------------
    def ping(self) -> bool:
        try:
            self.command("PING")
            return True
        except BridgeError as exc:
            log.warning("Ping failed: %s", exc)
            return False

    def push_limits_and_speeds(self) -> None:
        """Send servo limits + speeds from config.yaml to the firmware."""
        low_speed = bool(self.cfg.get("low_speed_mode", True))
        for i, joint in enumerate(CHANNEL_ORDER):
            s = self.cfg["servos"][joint]
            self.command(f"LIMITS:{i},{s['min']},{s['max']}")
            speed = float(s["max_speed_dps"]) * (0.5 if low_speed else 1.0)
            self.command(f"SPEED:{i},{speed:.1f}")

    def home(self) -> None:
        self.command("HOME")

    def move_all(self, angles: Dict[str, float]) -> None:
        vals = ",".join(f"{angles[j]:.2f}" for j in CHANNEL_ORDER)
        self.command(f"MOVEALL:{vals}")

    def move_joint(self, joint: str, angle: float) -> None:
        ch = CHANNEL_ORDER.index(joint)
        self.command(f"MOVEONE:{ch},{angle:.2f}")

    def stop(self) -> None:
        self.command("STOP")

    def estop(self) -> None:
        self.command("ESTOP")

    def clear_estop(self) -> None:
        self.command("CLEARESTOP")

    def get_angles(self) -> Dict[str, float]:
        st = self.command("GETANGLES")
        return dict(zip(CHANNEL_ORDER, st["angles"]))

    def status(self) -> Tuple[bool, bool, Dict[str, float]]:
        """Return (moving, estop, angles)."""
        st = self.command("STATUS")
        return (st.get("moving") == "1", st.get("estop") == "1",
                dict(zip(CHANNEL_ORDER, st.get("angles", self._homes))))

    def wait_until_idle(self, timeout_s: float,
                        stop_flag=None) -> None:
        """Poll STATUS until motion completes. Raises on timeout.
        `stop_flag()` returning True sends STOP and raises."""
        t0 = time.time()
        while True:
            moving, estop_active, _ = self.status()
            if estop_active:
                raise BridgeError("Emergency stop became active during move")
            if not moving:
                return
            if stop_flag is not None and stop_flag():
                self.stop()
                raise BridgeError("Motion aborted by stop request")
            if time.time() - t0 > timeout_s:
                self.stop()
                raise BridgeError(f"Move timeout after {timeout_s}s")
            time.sleep(0.05)

# ==================================================================
# ==== from inverse_kinematics.py ====
# ==================================================================
"""Reduced-DOF inverse kinematics for the 6DOF hobby arm.

Approach (practical pick-and-place IK):
  * Base servo aims the arm toward (x, y):  base = atan2(y, x)
  * Shoulder + elbow form a planar 2-link chain that reaches the wrist
    point at radial distance r and height z_w.
  * Wrist pitch is compensated so the gripper stays vertical (pointing
    straight down at the fruit): shoulder + elbow + wrist = -90° measured
    from the horizontal.
  * Wrist rotation is a fixed configurable pickup orientation.
  * Gripper open/close is handled separately.

Math zero conventions (see README diagram):
  * Base 0°      = arm pointing along robot +X.
  * Shoulder 0°  = upper arm horizontal, pointing outward; +angle lifts it.
  * Elbow 0°     = forearm in line with the upper arm; +angle folds it up.
  * Wrist 0°     = gripper in line with the forearm.
Servo angles = math angle * direction + offset + home, clamped to limits.
"""

import logging
import math
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

log = logging.getLogger("ik")

JOINTS = ("base", "shoulder", "elbow", "wrist_pitch", "wrist_rot", "gripper")


class IKError(Exception):
    """Raised for unreachable targets or invalid geometry."""


@dataclass
class IKResult:
    servo_angles: Dict[str, float]   # degrees, ready to send to firmware
    math_angles: Dict[str, float]    # degrees, for debugging
    reachable: bool
    message: str


class InverseKinematics:
    def __init__(self, cfg: Dict[str, Any]) -> None:
        rb = cfg["robot"]
        self.base_h = float(rb["base_height_mm"])
        self.l1 = float(rb["upper_arm_mm"])
        self.l2 = float(rb["forearm_mm"])
        self.tool = float(rb["tool_offset_mm"])
        self.elbow_solution = str(rb.get("elbow_solution", "up"))
        self.reach_margin = float(rb.get("max_reach_margin_mm", 5.0))
        self.servos = cfg["servos"]
        self.pickup_wrist_rot = float(
            cfg["gripper"]["pickup_wrist_rotation_deg"])
        for v, name in ((self.l1, "upper_arm_mm"), (self.l2, "forearm_mm")):
            if v <= 0:
                raise IKError(f"robot.{name} must be > 0 (got {v})")

    # ---------------------------------------------------------
    def solve(self, x: float, y: float, z: float,
              gripper_angle: Optional[float] = None) -> IKResult:
        """Solve for gripper TIP at (x, y, z) in the ROBOT frame, gripper
        vertical. Raises IKError when unreachable or outside servo limits.
        """
        # 1. Base rotation
        base_math = math.degrees(math.atan2(y, x))

        # 2. Wrist-pitch joint position: tip + tool pointing straight down
        r = math.hypot(x, y)
        z_wrist = z + self.tool          # wrist sits `tool` mm above the tip
        dz = z_wrist - self.base_h       # height relative to shoulder axis

        # 3. Two-link planar IK (cosine law)
        d = math.hypot(r, dz)            # shoulder axis -> wrist distance
        max_reach = self.l1 + self.l2 - self.reach_margin
        min_reach = abs(self.l1 - self.l2) + self.reach_margin
        if d > max_reach:
            raise IKError(f"Target {d:.1f}mm away, beyond reach "
                          f"({max_reach:.1f}mm). Move fruit closer.")
        if d < min_reach:
            raise IKError(f"Target {d:.1f}mm away, inside minimum reach "
                          f"({min_reach:.1f}mm).")

        cos_elbow = (d * d - self.l1 * self.l1 - self.l2 * self.l2) \
            / (2.0 * self.l1 * self.l2)
        # Clamp ONLY floating-point error; genuine out-of-domain was
        # already rejected by the reach checks above.
        if cos_elbow > 1.0:
            if cos_elbow > 1.0 + 1e-9:
                raise IKError("IK domain error (cos_elbow > 1)")
            cos_elbow = 1.0
        if cos_elbow < -1.0:
            if cos_elbow < -1.0 - 1e-9:
                raise IKError("IK domain error (cos_elbow < -1)")
            cos_elbow = -1.0

        elbow_inner = math.acos(cos_elbow)      # 0 = straight arm
        gamma = math.atan2(dz, r)               # angle to the wrist point
        k = math.atan2(self.l2 * math.sin(elbow_inner),
                       self.l1 + self.l2 * math.cos(elbow_inner))

        solutions = {
            # elbow-up: elbow folds upward, shoulder raised extra
            "up":   (math.degrees(gamma + k), -math.degrees(elbow_inner)),
            # elbow-down
            "down": (math.degrees(gamma - k), math.degrees(elbow_inner)),
        }
        shoulder_math, elbow_math = solutions[self.elbow_solution]

        # 4. Wrist pitch keeps the gripper vertical (pointing down):
        #    shoulder + elbow + wrist = -90  (all in math degrees)
        wrist_math = -90.0 - shoulder_math - elbow_math

        math_angles = {
            "base": base_math, "shoulder": shoulder_math,
            "elbow": elbow_math, "wrist_pitch": wrist_math,
            "wrist_rot": 0.0, "gripper": 0.0,
        }

        # 5. Map math angles -> physical servo angles
        servo_angles: Dict[str, float] = {}
        for joint in JOINTS:
            s = self.servos[joint]
            if joint == "wrist_rot":
                angle = self.pickup_wrist_rot
            elif joint == "gripper":
                angle = gripper_angle if gripper_angle is not None \
                    else float(s["home"])
            else:
                angle = float(s["home"]) + s["direction"] * (
                    math_angles[joint] + float(s["offset_deg"]))
            if not (s["min"] <= angle <= s["max"]):
                raise IKError(
                    f"Joint '{joint}' would need {angle:.1f}° but limits "
                    f"are {s['min']}–{s['max']}°. Target unreachable "
                    "safely — NOT clamping.")
            servo_angles[joint] = round(angle, 2)

        return IKResult(servo_angles=servo_angles, math_angles=math_angles,
                        reachable=True, message="ok")

    # ---------------------------------------------------------
    def check_reachable(self, x: float, y: float, z: float) -> Tuple[bool, str]:
        """Non-throwing reachability probe used by the state machine
        and the dashboard."""
        try:
            self.solve(x, y, z)
            return True, "reachable"
        except IKError as exc:
            return False, str(exc)

# ==================================================================
# ==== from motion_planner.py ====
# ==================================================================
"""Motion planning: turns "pick fruit at (x,y)" into a checked sequence of
IK-solved waypoints. No servo is ever commanded from here directly; the
state machine executes the plan step-by-step so it can check the stop and
emergency-stop flags between EVERY phase.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List


log = logging.getLogger("planner")


@dataclass
class MotionStep:
    name: str                       # e.g. "MOVING_TO_PRE_GRASP"
    angles: Dict[str, float]        # full servo target set
    pause_s: float = 0.0            # settle/grip delay after the move


@dataclass
class PickPlan:
    steps_pick: List[MotionStep] = field(default_factory=list)
    steps_place: List[MotionStep] = field(default_factory=list)


class MotionPlanner:
    def __init__(self, cfg: Dict[str, Any], ik: InverseKinematics) -> None:
        self.cfg = cfg
        self.ik = ik
        self.h = cfg["heights"]
        g = cfg["gripper"]
        self.open_a = float(g["GRIPPER_OPEN_ANGLE"])
        self.closed_a = float(g["GRIPPER_CLOSED_ANGLE"])
        self.release_a = float(g["GRIPPER_RELEASE_ANGLE"])
        self.grip_delay = float(cfg["motion"]["grip_delay_s"])
        self.drop_delay = float(cfg["motion"]["drop_delay_s"])
        self.settle = float(cfg["motion"]["settle_delay_s"])

    def _solve(self, x: float, y: float, z: float, grip: float,
               phase: str) -> Dict[str, float]:
        try:
            return self.ik.solve(x, y, z, gripper_angle=grip).servo_angles
        except IKError as exc:
            raise IKError(f"{phase}: {exc}") from exc

    def plan_pick(self, x: float, y: float, fruit: str) -> List[MotionStep]:
        """Waypoints from SAFE height down to the fruit and back up."""
        pick_z = float(self.h["PICK_Z"]) \
            + float(self.h["fruit_height_mm"].get(fruit, 0.0))
        pre = self._solve(x, y, float(self.h["PRE_GRASP_Z"]),
                          self.open_a, "pre-grasp")
        down = self._solve(x, y, pick_z, self.open_a, "descend")
        grab = dict(down); grab["gripper"] = self.closed_a
        lift = self._solve(x, y, float(self.h["LIFT_Z"]),
                           self.closed_a, "lift")
        return [
            MotionStep("MOVING_TO_PRE_GRASP", pre, self.settle),
            MotionStep("OPENING_GRIPPER", pre, self.settle),
            MotionStep("DESCENDING", down, self.settle),
            MotionStep("CLOSING_GRIPPER", grab, self.grip_delay),
            MotionStep("LIFTING", lift, self.settle),
        ]

    def plan_place(self, drop: Dict[str, Any]) -> List[MotionStep]:
        """Waypoints from the lift position to the bucket and release."""
        steps: List[MotionStep] = []
        wp = drop.get("waypoint")
        if wp:
            w = self._solve(float(wp["x_mm"]), float(wp["y_mm"]),
                            float(wp["z_mm"]), self.closed_a, "waypoint")
            steps.append(MotionStep("MOVING_TO_BUCKET", w, self.settle))
        x, y = float(drop["x_mm"]), float(drop["y_mm"])
        above = self._solve(x, y, float(drop["approach_z_mm"]),
                            self.closed_a, "bucket approach")
        release_pose = self._solve(x, y, float(drop["release_z_mm"]),
                                   self.closed_a, "bucket release")
        released = dict(release_pose); released["gripper"] = self.release_a
        away = dict(above); away["gripper"] = self.release_a
        steps += [
            MotionStep("MOVING_TO_BUCKET", above, self.settle),
            MotionStep("MOVING_TO_BUCKET", release_pose, self.settle),
            MotionStep("RELEASING", released, self.drop_delay),
            MotionStep("RELEASING", away, self.settle),
        ]
        return steps

    def home_angles(self) -> Dict[str, float]:
        return {j: float(self.cfg["servos"][j]["home"])
                for j in ("base", "shoulder", "elbow",
                          "wrist_pitch", "wrist_rot", "gripper")}
