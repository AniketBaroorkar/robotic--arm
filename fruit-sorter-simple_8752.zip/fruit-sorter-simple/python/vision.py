"""vision.py — everything that sees: camera capture, YOLO detection,
HSV color verification, stability tracking, workspace calibration.
"""
from __future__ import annotations

# ==================================================================
# ==== from camera.py ====
# ==================================================================
"""USB camera capture with clean shutdown and stall detection."""

import logging
import threading
import time
from typing import Any, Dict, Optional

import cv2
import numpy as np

log = logging.getLogger("camera")


class Camera:
    """Owns the cv2.VideoCapture. One instance per process.

    grab() returns the newest frame or None. If no frame arrives for
    `timeout_s` seconds, is_stalled() becomes True and the state machine
    must refuse to move the arm.
    """

    def __init__(self, cfg: Dict[str, Any], timeout_s: float = 3.0) -> None:
        cam = cfg["camera"]
        self.index: int = int(cam["index"])
        self.width: int = int(cam["width"])
        self.height: int = int(cam["height"])
        self.fps: int = int(cam["fps"])
        self.timeout_s = timeout_s
        self._cap: Optional[cv2.VideoCapture] = None
        self._last_ok = 0.0
        self._lock = threading.Lock()

    def open(self) -> None:
        with self._lock:
            self._cap = cv2.VideoCapture(self.index)
            if not self._cap.isOpened():
                raise RuntimeError(
                    f"Cannot open camera index {self.index}. "
                    "Check `ls /dev/video*` and camera.index in config.yaml.")
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self._cap.set(cv2.CAP_PROP_FPS, self.fps)
            self._last_ok = time.time()
            log.info("Camera %d opened at %dx%d",
                     self.index, self.width, self.height)

    def grab(self) -> Optional[np.ndarray]:
        with self._lock:
            if self._cap is None:
                return None
            ok, frame = self._cap.read()
        if not ok or frame is None:
            return None
        self._last_ok = time.time()
        return frame

    def is_stalled(self) -> bool:
        return (time.time() - self._last_ok) > self.timeout_s

    def release(self) -> None:
        with self._lock:
            if self._cap is not None:
                self._cap.release()
                self._cap = None
                log.info("Camera released")

# ==================================================================
# ==== from detector.py ====
# ==================================================================
"""YOLO fruit detector.

Uses a small Ultralytics model (yolov8n by default). Only the three COCO
classes apple / orange / banana pass through; every other label (bottle,
cup, person, hand, toys, ...) is rejected here, before color checking.
"""

import logging
import os
from typing import Any, Dict, List

import numpy as np

log = logging.getLogger("detector")


class FruitDetector:
    def __init__(self, cfg: Dict[str, Any]) -> None:
        from ultralytics import YOLO  # imported here so scripts can mock it

        y = cfg["yolo"]
        self.conf: float = float(y["confidence_threshold"])
        self.imgsz: int = int(y["inference_size"])
        # id -> name for the classes we accept
        self.wanted: Dict[int, str] = {int(v): k for k, v in y["class_ids"].items()}

        model_path = y["model_path"]
        if not os.path.exists(model_path):
            os.makedirs(os.path.dirname(model_path) or ".", exist_ok=True)
            log.info("Model %s not found locally; ultralytics will download it.",
                     model_path)
        self.model = YOLO(model_path)
        log.info("YOLO model loaded: %s", model_path)

    def detect(self, frame_bgr: np.ndarray) -> List[Dict[str, Any]]:
        """Return a list of raw detections:
        {label, confidence, box:[x1,y1,x2,y2], center:[cx,cy]}
        """
        results = self.model.predict(
            frame_bgr, imgsz=self.imgsz, conf=self.conf, verbose=False)
        out: List[Dict[str, Any]] = []
        if not results:
            return out
        r = results[0]
        if r.boxes is None:
            return out
        for box in r.boxes:
            cls_id = int(box.cls[0])
            if cls_id not in self.wanted:
                continue  # reject bottle, cup, person, everything else
            x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
            out.append({
                "label": self.wanted[cls_id],
                "confidence": float(box.conf[0]),
                "box": [x1, y1, x2, y2],
                "center": [(x1 + x2) / 2.0, (y1 + y2) / 2.0],
            })
        return out

# ==================================================================
# ==== from color_verifier.py ====
# ==================================================================
"""HSV color verification.

For every YOLO detection we look at the *pixels themselves* inside a
shrunken, preferably elliptical region of the bounding box and measure
what percentage of them is red / green / yellow / orange. A fruit is only
accepted when its dominant color matches the rules in config.yaml.
"""

import logging
from typing import Any, Dict, List, Tuple

import cv2
import numpy as np

log = logging.getLogger("color")

COLOR_NAMES = ("red", "green", "yellow", "orange")


class ColorVerifier:
    def __init__(self, cfg: Dict[str, Any]) -> None:
        h = cfg["hsv"]
        self.roi_shrink: float = float(h["roi_shrink"])
        self.use_ellipse: bool = bool(h["use_ellipse_roi"])
        self.min_percent: float = float(h["min_color_percent"])
        self.ranges: Dict[str, List[Tuple[np.ndarray, np.ndarray]]] = {
            "red": [
                (np.array(h["red_low"][0]), np.array(h["red_low"][1])),
                (np.array(h["red_high"][0]), np.array(h["red_high"][1])),
            ],
            "orange": [(np.array(h["orange"][0]), np.array(h["orange"][1]))],
            "yellow": [(np.array(h["yellow"][0]), np.array(h["yellow"][1]))],
            "green": [(np.array(h["green"][0]), np.array(h["green"][1]))],
        }
        # rules: label -> set of allowed colors
        self.rules: Dict[str, List[str]] = {
            label: rule["colors"] for label, rule in cfg["fruit_rules"].items()
        }

    def _roi(self, frame: np.ndarray, box: List[float]
             ) -> Tuple[np.ndarray, np.ndarray]:
        """Return (roi_bgr, mask) — mask selects the central ellipse/rect."""
        H, W = frame.shape[:2]
        x1, y1, x2, y2 = box
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        w = (x2 - x1) * self.roi_shrink
        h = (y2 - y1) * self.roi_shrink
        ax1 = int(max(0, cx - w / 2)); ay1 = int(max(0, cy - h / 2))
        ax2 = int(min(W - 1, cx + w / 2)); ay2 = int(min(H - 1, cy + h / 2))
        roi = frame[ay1:ay2, ax1:ax2]
        mask = np.zeros(roi.shape[:2], dtype=np.uint8)
        if roi.size == 0:
            return roi, mask
        if self.use_ellipse:
            center = (roi.shape[1] // 2, roi.shape[0] // 2)
            axes = (max(1, roi.shape[1] // 2 - 1), max(1, roi.shape[0] // 2 - 1))
            cv2.ellipse(mask, center, axes, 0, 0, 360, 255, -1)
        else:
            mask[:] = 255
        return roi, mask

    def verify(self, frame_bgr: np.ndarray, det: Dict[str, Any]
               ) -> Dict[str, Any]:
        """Return {color, percent, valid, percents:{name:pct}}."""
        roi, region_mask = self._roi(frame_bgr, det["box"])
        result = {"color": "none", "percent": 0.0, "valid": False,
                  "percents": {c: 0.0 for c in COLOR_NAMES}}
        total = int(cv2.countNonZero(region_mask))
        if roi.size == 0 or total == 0:
            return result

        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        for name, ranges in self.ranges.items():
            color_mask = np.zeros(roi.shape[:2], dtype=np.uint8)
            for lo, hi in ranges:
                color_mask |= cv2.inRange(hsv, lo, hi)
            color_mask &= region_mask
            pct = 100.0 * cv2.countNonZero(color_mask) / total
            result["percents"][name] = round(pct, 1)

        best = max(result["percents"], key=result["percents"].get)
        best_pct = result["percents"][best]
        result["color"] = best
        result["percent"] = best_pct

        allowed = self.rules.get(det["label"], [])
        result["valid"] = (best in allowed) and (best_pct >= self.min_percent)
        return result

# ==================================================================
# ==== from stability.py ====
# ==================================================================
"""Stable-detection tracking and target selection.

A fruit becomes a candidate target only after it has been seen with a
valid class + valid color, roughly in the same place, inside the source
tray and outside every bucket, for `required_frames` consecutive frames.

Selection priority when several fruits qualify:
  1. valid class and color        (mandatory filter)
  2. highest stability count
  3. highest YOLO confidence
  4. closest reachable fruit to the arm base
The chosen target is LOCKED by the state machine; this module only
proposes candidates.
"""

import logging
import math
from typing import Any, Dict, List, Optional

log = logging.getLogger("stability")


class StabilityTracker:
    def __init__(self, cfg: Dict[str, Any]) -> None:
        st = cfg["stability"]
        self.required: int = int(st["required_frames"])
        self.max_jump: float = float(st["max_center_jump_px"])
        self._tracks: List[Dict[str, Any]] = []
        self._next_id = 1

    def update(self, valid_dets: List[Dict[str, Any]]) -> None:
        """Match this frame's VALID detections against existing tracks."""
        unmatched = list(valid_dets)
        for track in self._tracks:
            best = None
            best_d = self.max_jump
            for det in unmatched:
                d = math.dist(track["center"], det["center"])
                if d <= best_d and det["label"] == track["label"]:
                    best, best_d = det, d
            if best is not None:
                unmatched.remove(best)
                track.update(center=best["center"], box=best["box"],
                             confidence=best["confidence"],
                             color=best["color"],
                             color_percent=best["color_percent"])
                track["count"] += 1
                track["missed"] = 0
            else:
                track["missed"] += 1

        # Consecutive means consecutive: a single missed frame resets.
        self._tracks = [t for t in self._tracks if t["missed"] == 0]

        for det in unmatched:
            self._tracks.append({
                "id": self._next_id, "label": det["label"],
                "center": det["center"], "box": det["box"],
                "confidence": det["confidence"], "color": det["color"],
                "color_percent": det["color_percent"],
                "count": 1, "missed": 0,
            })
            self._next_id += 1

    def stable_tracks(self) -> List[Dict[str, Any]]:
        return [t for t in self._tracks if t["count"] >= self.required]

    def select_target(self, stable: List[Dict[str, Any]],
                      reach_check) -> Optional[Dict[str, Any]]:
        """Pick one target. `reach_check(track) -> (bool, robot_xyz|None)`
        is supplied by the state machine (it knows calibration + IK)."""
        candidates = []
        for t in stable:
            ok, robot_xy = reach_check(t)
            if ok:
                t2 = dict(t)
                t2["robot_xy"] = robot_xy
                t2["dist"] = math.hypot(*robot_xy)
                candidates.append(t2)
        if not candidates:
            return None
        candidates.sort(key=lambda t: (-t["count"], -t["confidence"], t["dist"]))
        return candidates[0]

    def reset(self) -> None:
        self._tracks = []

    def fruit_near(self, center_px, radius: float) -> bool:
        """Used for pickup-failure detection after a drop."""
        return any(math.dist(t["center"], center_px) <= radius
                   for t in self._tracks)

# ==================================================================
# ==== from calibration.py ====
# ==================================================================
"""Pixel -> workspace -> robot coordinate transforms + region checks.

Frames used in this project
---------------------------
1. Camera image frame : pixels (u, v). u grows right, v grows DOWN.
2. Workspace frame    : millimetres on the flat table. Origin at the
   TOP-LEFT calibration corner. +X to the right, +Y away from the top edge
   (i.e. "down" in the image), Z up out of the table.
3. Robot-base frame   : origin on the table directly under the base
   rotation axis. +X points straight out in front of the arm when the
   base servo reads its zero direction, +Y follows the right-hand rule,
   +Z is up. Base angle 0° math-zero corresponds to servo (home±offset).

The homography converts (u,v) -> workspace (x,y) on the FLAT table only.
A plain USB camera gives NO depth, so Z always comes from the fixed
heights in config.yaml — this is an honest limitation, see README.
"""

import logging
import math
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

log = logging.getLogger("calibration")


class Workspace:
    def __init__(self, cal: Dict[str, Any], cfg: Dict[str, Any]) -> None:
        self.H = np.array(cal["homography"], dtype=np.float64)
        self.source_tray = np.array(cal["source_tray_polygon_px"], np.int32)
        self.buckets_px = {
            "red_bucket": np.array(cal["red_bucket_polygon_px"], np.int32),
            "orange_bucket": np.array(cal["orange_bucket_polygon_px"], np.int32),
            "yellow_bucket": np.array(cal["yellow_bucket_polygon_px"], np.int32),
        }
        self.drops: Dict[str, Dict[str, Any]] = cal["bucket_drop_positions"]

        rb = cfg["robot"]
        base = cal.get("arm_base_position_mm") or rb["base_position_mm"]
        self.base_x = float(base["x"])
        self.base_y = float(base["y"])
        self.base_rot = math.radians(float(rb["base_rotation_deg"]))

    # ---- pixel -> workspace -----------------------------------
    def pixel_to_workspace(self, u: float, v: float) -> Tuple[float, float]:
        pt = np.array([[[u, v]]], dtype=np.float64)
        out = cv2.perspectiveTransform(pt, self.H)
        return float(out[0, 0, 0]), float(out[0, 0, 1])

    # ---- workspace -> robot base ------------------------------
    def workspace_to_robot(self, x_mm: float, y_mm: float
                           ) -> Tuple[float, float]:
        dx = x_mm - self.base_x
        dy = y_mm - self.base_y
        c, s = math.cos(-self.base_rot), math.sin(-self.base_rot)
        return dx * c - dy * s, dx * s + dy * c

    # ---- region checks (in pixels) ----------------------------
    def in_source_tray(self, u: float, v: float) -> bool:
        return cv2.pointPolygonTest(self.source_tray, (float(u), float(v)),
                                    False) >= 0

    def in_any_bucket(self, u: float, v: float) -> bool:
        for poly in self.buckets_px.values():
            if cv2.pointPolygonTest(poly, (float(u), float(v)), False) >= 0:
                return True
        return False

    def drop_position(self, bucket: str) -> Dict[str, Any]:
        if bucket not in self.drops:
            raise KeyError(f"No drop position calibrated for {bucket}")
        return self.drops[bucket]

    # ---- drawing overlays -------------------------------------
    def draw_regions(self, frame: np.ndarray) -> None:
        cv2.polylines(frame, [self.source_tray], True, (255, 255, 0), 2)
        colors = {"red_bucket": (0, 0, 255), "orange_bucket": (0, 140, 255),
                  "yellow_bucket": (0, 220, 255)}
        for name, poly in self.buckets_px.items():
            cv2.polylines(frame, [poly], True, colors[name], 2)


def build_workspace(cal: Optional[Dict[str, Any]],
                    cfg: Dict[str, Any]) -> Optional[Workspace]:
    if cal is None:
        return None
    try:
        return Workspace(cal, cfg)
    except Exception as exc:  # noqa: BLE001 — surface every calib problem
        log.error("Calibration invalid: %s", exc)
        return None
