/*
 * Fruit Sorter firmware — Arduino UNO Q (STM32U585 MCU side)
 *
 * Responsibilities (nothing else runs here):
 *   - PCA9685 servo control over I2C (Adafruit PWM Servo Driver)
 *   - Servo-angle validation against per-channel limits
 *   - Smooth non-blocking interpolation toward target angles
 *   - HOME command, gripper moves, STOP, EMERGENCY STOP
 *   - Current-angle reporting + acknowledgement for every command
 *
 * Communication: Arduino_RouterBridge (official UNO Q Bridge).
 * The Linux/Python side calls the RPC function "cmd" with one String and
 * receives one String back. NEVER open Serial1 here — the router owns it.
 *
 * Protocol (requests):
 *   PING | HOME | MOVEALL:a0,a1,a2,a3,a4,a5 | MOVEONE:ch,angle
 *   STOP | ESTOP | CLEARESTOP | GETANGLES | STATUS
 *   LIMITS:ch,min,max | SPEED:ch,deg_per_s
 * Replies:
 *   OK:<CMD>|MOVING=<0/1>|ESTOP=<0/1>|A=a0,a1,a2,a3,a4,a5
 *   ERR:<CMD>|<reason>
 */

#include <Arduino_RouterBridge.h>
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

// ---------------- configuration -----------------------------
const uint8_t  NUM_SERVOS   = 6;
const float    PWM_FREQ_HZ  = 50.0;   // standard hobby-servo frequency
const uint16_t UPDATE_MS    = 20;     // interpolation step interval

// Per-channel pulse range in microseconds (matches config.yaml defaults).
// Adjust ONLY if your servos need it; 500–2500 us maps 0–180 deg on MG996R
// class servos. Safer narrow default would be 600–2400.
uint16_t pulseMinUs[NUM_SERVOS] = {500, 500, 500, 500, 500, 500};
uint16_t pulseMaxUs[NUM_SERVOS] = {2500, 2500, 2500, 2500, 2500, 2500};

// Safe limits (deg). Python overwrites these from config.yaml at startup
// via LIMITS commands; these defaults are deliberately conservative.
float limitMin[NUM_SERVOS] = {10, 20, 20, 15, 10, 30};
float limitMax[NUM_SERVOS] = {170, 160, 160, 165, 170, 150};

// Max speed per joint, degrees/second (Python overwrites via SPEED).
float maxSpeedDps[NUM_SERVOS] = {60, 45, 45, 60, 60, 90};

const float HOME_ANGLE = 90.0;        // all six servos home at 90 deg

// ---------------- state -------------------------------------
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);

float currentAngle[NUM_SERVOS];
float targetAngle[NUM_SERVOS];
bool  estopActive   = false;
bool  motionActive  = false;
unsigned long lastStep = 0;

// ---------------- helpers -----------------------------------
uint16_t angleToTicks(uint8_t ch, float angle) {
  // 50 Hz -> one period = 20000 us, PCA9685 resolution = 4096 ticks.
  float us = pulseMinUs[ch] +
             (angle / 180.0f) * (pulseMaxUs[ch] - pulseMinUs[ch]);
  return (uint16_t)(us * 4096.0f / 20000.0f);
}

void writeServo(uint8_t ch, float angle) {
  pwm.setPWM(ch, 0, angleToTicks(ch, angle));
}

bool angleValid(uint8_t ch, float angle) {
  return (ch < NUM_SERVOS) &&
         (angle >= limitMin[ch]) && (angle <= limitMax[ch]);
}

String angleList() {
  String s = "";
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    if (i) s += ",";
    s += String(currentAngle[i], 1);
  }
  return s;
}

String okReply(const String &cmdName) {
  return "OK:" + cmdName +
         "|MOVING=" + String(motionActive ? 1 : 0) +
         "|ESTOP=" + String(estopActive ? 1 : 0) +
         "|A=" + angleList();
}

String errReply(const String &cmdName, const String &why) {
  return "ERR:" + cmdName + "|" + why;
}

void setTargets(const float *angles) {
  for (uint8_t i = 0; i < NUM_SERVOS; i++) targetAngle[i] = angles[i];
  motionActive = true;
}

// Parse "a,b,c,..." into out[]; returns count parsed.
uint8_t parseFloats(const String &s, float *out, uint8_t maxN) {
  uint8_t n = 0;
  int start = 0;
  while (n < maxN) {
    int comma = s.indexOf(',', start);
    String tok = (comma == -1) ? s.substring(start)
                               : s.substring(start, comma);
    tok.trim();
    if (tok.length() == 0) break;
    out[n++] = tok.toFloat();
    if (comma == -1) break;
    start = comma + 1;
  }
  return n;
}

// ---------------- command handler (RPC) ---------------------
String handleCmd(String payload) {
  int colon = payload.indexOf(':');
  String cmd = (colon == -1) ? payload : payload.substring(0, colon);
  String arg = (colon == -1) ? ""      : payload.substring(colon + 1);
  cmd.trim(); cmd.toUpperCase();

  if (cmd == "PING")      return okReply(cmd);
  if (cmd == "STATUS")    return okReply(cmd);
  if (cmd == "GETANGLES") return okReply(cmd);

  if (cmd == "ESTOP") {
    estopActive  = true;
    motionActive = false;                       // freeze at current angles
    for (uint8_t i = 0; i < NUM_SERVOS; i++) targetAngle[i] = currentAngle[i];
    return okReply(cmd);
  }
  if (cmd == "CLEARESTOP") {
    if (motionActive) return errReply(cmd, "arm not stationary");
    estopActive = false;
    return okReply(cmd);
  }
  if (cmd == "STOP") {
    motionActive = false;                       // hold current position
    for (uint8_t i = 0; i < NUM_SERVOS; i++) targetAngle[i] = currentAngle[i];
    return okReply(cmd);
  }

  if (estopActive) return errReply(cmd, "emergency stop active");

  if (cmd == "HOME") {
    float h[NUM_SERVOS];
    for (uint8_t i = 0; i < NUM_SERVOS; i++) h[i] = HOME_ANGLE;
    for (uint8_t i = 0; i < NUM_SERVOS; i++)
      if (!angleValid(i, h[i]))
        return errReply(cmd, "home angle outside limits ch" + String(i));
    setTargets(h);
    return okReply(cmd);
  }

  if (cmd == "MOVEALL") {
    float a[NUM_SERVOS];
    if (parseFloats(arg, a, NUM_SERVOS) != NUM_SERVOS)
      return errReply(cmd, "need 6 comma-separated angles");
    for (uint8_t i = 0; i < NUM_SERVOS; i++)
      if (!angleValid(i, a[i]))
        return errReply(cmd, "angle " + String(a[i], 1) +
                        " outside limits on ch" + String(i));
    setTargets(a);
    return okReply(cmd);
  }

  if (cmd == "MOVEONE") {
    float v[2];
    if (parseFloats(arg, v, 2) != 2)
      return errReply(cmd, "need channel,angle");
    uint8_t ch = (uint8_t)v[0];
    if (!angleValid(ch, v[1]))
      return errReply(cmd, "invalid channel or angle outside limits");
    targetAngle[ch] = v[1];
    motionActive = true;
    return okReply(cmd);
  }

  if (cmd == "LIMITS") {
    float v[3];
    if (parseFloats(arg, v, 3) != 3)
      return errReply(cmd, "need channel,min,max");
    uint8_t ch = (uint8_t)v[0];
    if (ch >= NUM_SERVOS || v[1] < 0 || v[2] > 180 || v[1] >= v[2])
      return errReply(cmd, "invalid limits");
    limitMin[ch] = v[1];
    limitMax[ch] = v[2];
    return okReply(cmd);
  }

  if (cmd == "SPEED") {
    float v[2];
    if (parseFloats(arg, v, 2) != 2)
      return errReply(cmd, "need channel,deg_per_s");
    uint8_t ch = (uint8_t)v[0];
    if (ch >= NUM_SERVOS || v[1] <= 0 || v[1] > 300)
      return errReply(cmd, "invalid speed");
    maxSpeedDps[ch] = v[1];
    return okReply(cmd);
  }

  return errReply(cmd.length() ? cmd : String("EMPTY"), "unknown command");
}

// ---------------- setup / loop ------------------------------
void setup() {
  Bridge.begin();
  Monitor.begin(115200);

  Wire.begin();
  pwm.begin();
  pwm.setPWMFreq(PWM_FREQ_HZ);
  delay(10);

  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    currentAngle[i] = HOME_ANGLE;
    targetAngle[i]  = HOME_ANGLE;
    writeServo(i, HOME_ANGLE);   // gentle: everything centres at 90 deg
  }

  Bridge.provide("cmd", handleCmd);
  Monitor.println("Fruit sorter firmware ready.");
}

void loop() {
  // Non-blocking smooth interpolation, one small step every UPDATE_MS.
  unsigned long now = millis();
  if (now - lastStep < UPDATE_MS) return;
  float dt = (now - lastStep) / 1000.0f;
  lastStep = now;

  if (estopActive || !motionActive) return;

  bool anyMoving = false;
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    float diff = targetAngle[i] - currentAngle[i];
    if (fabs(diff) < 0.1f) { currentAngle[i] = targetAngle[i]; continue; }
    anyMoving = true;
    float step = maxSpeedDps[i] * dt;          // max degrees this tick
    if (fabs(diff) < step) step = fabs(diff);  // don't overshoot
    currentAngle[i] += (diff > 0 ? step : -step);
    // safety: clamp to limits at EVERY step, never trust accumulated math
    if (currentAngle[i] < limitMin[i]) currentAngle[i] = limitMin[i];
    if (currentAngle[i] > limitMax[i]) currentAngle[i] = limitMax[i];
    writeServo(i, currentAngle[i]);
  }
  if (!anyMoving) motionActive = false;
}
